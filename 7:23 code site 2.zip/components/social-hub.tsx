'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

interface Post {
  id: string
  author: {
    name: string
    avatar: string
    verified?: boolean
  }
  content: string
  image?: string
  timestamp: string
  likes: number
  comments: number
  shares: number
  tags: string[]
  type: 'experience' | 'review' | 'recommendation' | 'question' | 'update'
  experienceData?: {
    title: string
    platform: string
    rating: number
  }
}

const mockPosts: Post[] = [
  {
    id: '1',
    author: { name: 'VR Explorer', avatar: '🧑‍🚀', verified: true },
    content: 'Just experienced the most incredible virtual concert! The haptic feedback made me feel like I was right there on stage. Anyone else tried the new immersive audio tech?',
    image: 'https://images.pexels.com/photos/7241304/pexels-photo-7241304.jpeg?auto=compress&cs=tinysrgb&w=600',
    timestamp: '2 hours ago',
    likes: 42,
    comments: 8,
    shares: 3,
    tags: ['VirtualConcert', 'Haptics', 'Music'],
    type: 'experience',
    experienceData: {
      title: 'Billie Eilish Virtual World Tour',
      platform: 'Meta Horizon',
      rating: 5
    }
  },
  {
    id: '2',
    author: { name: 'AR Artist', avatar: '🎨' },
    content: 'Created my first AR sculpture today! The blend of digital and physical space is mind-blowing. Sharing the QR code for anyone who wants to experience it.',
    timestamp: '5 hours ago',
    likes: 28,
    comments: 12,
    shares: 7,
    tags: ['ARCreation', 'DigitalArt', 'Sculpture'],
    type: 'recommendation'
  },
  {
    id: '3',
    author: { name: 'Game Dev', avatar: '👨‍💻', verified: true },
    content: 'Working on a new VR puzzle game that adapts to your stress levels using biometric feedback. Beta testing starts next week - who\'s interested?',
    timestamp: '1 day ago',
    likes: 156,
    comments: 34,
    shares: 18,
    tags: ['GameDev', 'VRGaming', 'BetaTest', 'Innovation'],
    type: 'update'
  }
]

export default function SocialHub() {
  const [posts, setPosts] = useState<Post[]>(mockPosts)
  const [newPost, setNewPost] = useState({
    content: '',
    image: '',
    type: 'experience' as Post['type'],
    tags: [] as string[]
  })
  const [userProfile, setUserProfile] = useState({ name: 'Anonymous', avatar: '🧑‍💻' })

  useEffect(() => {
    const saved = localStorage.getItem('immersiveXProfile')
    if (saved) {
      try {
        const profile = JSON.parse(saved)
        setUserProfile({
          name: profile.name || 'Anonymous Explorer',
          avatar: profile.avatar || '🧑‍💻'
        })
      } catch (error) {
        console.error('Error loading profile:', error)
      }
    }
  }, [])

  const submitPost = () => {
    if (!newPost.content.trim()) return

    const post: Post = {
      id: Date.now().toString(),
      author: userProfile,
      content: newPost.content,
      image: newPost.image || undefined,
      timestamp: 'just now',
      likes: 0,
      comments: 0,
      shares: 0,
      tags: newPost.tags,
      type: newPost.type
    }

    setPosts([post, ...posts])
    setNewPost({ content: '', image: '', type: 'experience', tags: [] })
  }

  const likePost = (postId: string) => {
    setPosts(posts.map(post => 
      post.id === postId ? { ...post, likes: post.likes + 1 } : post
    ))
  }

  const getTypeIcon = (type: Post['type']) => {
    switch (type) {
      case 'experience': return '🎮'
      case 'review': return '⭐'
      case 'recommendation': return '💡'
      case 'question': return '❓'
      case 'update': return '📢'
      default: return '💬'
    }
  }

  const getTypeColor = (type: Post['type']) => {
    switch (type) {
      case 'experience': return 'bg-purple-600/40 text-purple-200 border-purple-500/30'
      case 'review': return 'bg-yellow-600/40 text-yellow-200 border-yellow-500/30'
      case 'recommendation': return 'bg-blue-600/40 text-blue-200 border-blue-500/30'
      case 'question': return 'bg-green-600/40 text-green-200 border-green-500/30'
      case 'update': return 'bg-pink-600/40 text-pink-200 border-pink-500/30'
      default: return 'bg-gray-600/40 text-gray-200 border-gray-500/30'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-purple-900/20 text-white p-6">
      <div className="max-w-4xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent" data-macaly="social-title">
            🌐 ImmersiveNet
          </h1>
          <p className="text-white/70" data-macaly="social-subtitle">
            Connect, share, and discover amazing immersive experiences with the community
          </p>
        </div>

        {/* Create Post */}
        <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 mb-8 shadow-2xl">
          <div className="flex items-start space-x-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-xl">
              {userProfile.avatar}
            </div>
            <div className="flex-1 space-y-4">
              <textarea
                placeholder="Share your immersive experience..."
                value={newPost.content}
                onChange={(e) => setNewPost(prev => ({ ...prev, content: e.target.value }))}
                rows={3}
                className="w-full p-4 bg-white/10 rounded-xl text-white placeholder-white/50 border border-white/20 focus:outline-none focus:ring-2 focus:ring-purple-500/50 resize-none"
              />
              
              <div className="flex flex-wrap gap-3 items-center">
                <input
                  type="url"
                  placeholder="Image URL (optional)"
                  value={newPost.image}
                  onChange={(e) => setNewPost(prev => ({ ...prev, image: e.target.value }))}
                  className="flex-1 min-w-64 p-2 bg-white/10 rounded-lg text-white placeholder-white/50 text-sm border border-white/20 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                />
                
                <select
                  value={newPost.type}
                  onChange={(e) => setNewPost(prev => ({ ...prev, type: e.target.value as Post['type'] }))}
                  className="p-2 bg-white/10 rounded-lg text-white border border-white/20 focus:outline-none focus:ring-2 focus:ring-purple-500/50 text-sm"
                >
                  <option value="experience">🎮 Experience</option>
                  <option value="review">⭐ Review</option>
                  <option value="recommendation">💡 Recommendation</option>
                  <option value="question">❓ Question</option>
                  <option value="update">📢 Update</option>
                </select>
                
                <Button
                  onClick={submitPost}
                  disabled={!newPost.content.trim()}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-6"
                >
                  Share
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Posts Feed */}
        <div className="space-y-6">
          {posts.map(post => (
            <div key={post.id} className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl hover:border-white/20 transition-all">
              
              {/* Post Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-xl">
                    {post.author.avatar}
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-semibold">{post.author.name}</span>
                      {post.author.verified && (
                        <Badge className="bg-blue-600/40 text-blue-200 border-blue-500/30 text-xs">
                          ✓ Verified
                        </Badge>
                      )}
                    </div>
                    <div className="text-white/50 text-sm">{post.timestamp}</div>
                  </div>
                </div>
                
                <Badge className={`${getTypeColor(post.type)} text-xs`}>
                  {getTypeIcon(post.type)} {post.type}
                </Badge>
              </div>

              {/* Experience Data (if applicable) */}
              {post.experienceData && (
                <div className="mb-4 p-3 bg-gradient-to-br from-purple-500/10 to-blue-500/10 rounded-xl border border-white/10">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-purple-300">{post.experienceData.title}</div>
                      <div className="text-white/60 text-sm">{post.experienceData.platform}</div>
                    </div>
                    <div className="flex items-center space-x-1 text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <span key={i} className={i < post.experienceData!.rating ? 'text-yellow-400' : 'text-gray-600'}>
                          ⭐
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Post Content */}
              <div className="mb-4">
                <p className="text-white/90 leading-relaxed">{post.content}</p>
              </div>

              {/* Post Image */}
              {post.image && (
                <div className="mb-4">
                  <img 
                    src={post.image} 
                    alt="Post image" 
                    className="w-full max-h-96 object-cover rounded-xl border border-white/10"
                  />
                </div>
              )}

              {/* Tags */}
              {post.tags.length > 0 && (
                <div className="mb-4 flex flex-wrap gap-2">
                  {post.tags.map(tag => (
                    <span 
                      key={tag}
                      className="px-2 py-1 bg-white/10 text-white/80 rounded-full text-xs border border-white/20 hover:bg-white/20 cursor-pointer transition-colors"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              )}

              {/* Post Actions */}
              <div className="flex items-center justify-between pt-4 border-t border-white/10">
                <div className="flex items-center space-x-6">
                  <button
                    onClick={() => likePost(post.id)}
                    className="flex items-center space-x-2 text-white/70 hover:text-red-400 transition-colors group"
                  >
                    <span className="group-hover:scale-125 transition-transform">❤️</span>
                    <span className="text-sm">{post.likes}</span>
                  </button>
                  
                  <button className="flex items-center space-x-2 text-white/70 hover:text-blue-400 transition-colors">
                    <span>💬</span>
                    <span className="text-sm">{post.comments}</span>
                  </button>
                  
                  <button className="flex items-center space-x-2 text-white/70 hover:text-green-400 transition-colors">
                    <span>🔄</span>
                    <span className="text-sm">{post.shares}</span>
                  </button>
                </div>
                
                <button className="text-white/50 hover:text-white transition-colors">
                  <span>🔗</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-8">
          <Button 
            variant="outline"
            className="border-white/20 text-white/80 hover:bg-white/10"
          >
            Load More Posts
          </Button>
        </div>
      </div>
    </div>
  )
}