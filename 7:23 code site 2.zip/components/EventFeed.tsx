'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Calendar, Clock, MapPin, Users, ExternalLink, Bell } from 'lucide-react'

interface Event {
  id: string
  name: string
  description: string
  date: string
  time: string
  link: string
  category: string
  capacity: string
  created: string
}

export default function EventFeed() {
  const [events, setEvents] = useState<Event[]>([])
  const [rsvps, setRsvps] = useState<string[]>([])

  console.log('EventFeed component rendered, events count:', events.length)

  useEffect(() => {
    const saved = localStorage.getItem('immersiveEvents')
    const savedRsvps = localStorage.getItem('eventRsvps')
    
    if (saved) {
      const parsedEvents = JSON.parse(saved)
      setEvents(parsedEvents)
      console.log('Loaded events for feed:', parsedEvents.length)
    }
    
    if (savedRsvps) {
      setRsvps(JSON.parse(savedRsvps))
    }
  }, [])

  const handleRsvp = (eventId: string) => {
    const updatedRsvps = rsvps.includes(eventId) 
      ? rsvps.filter(id => id !== eventId)
      : [...rsvps, eventId]
    
    setRsvps(updatedRsvps)
    localStorage.setItem('eventRsvps', JSON.stringify(updatedRsvps))
    console.log('RSVP updated for event:', eventId, 'RSVP status:', !rsvps.includes(eventId))
  }

  const isUpcoming = (dateString: string) => {
    const eventDate = new Date(dateString)
    const now = new Date()
    return eventDate > now
  }

  const getTimeUntil = (dateString: string) => {
    const eventDate = new Date(dateString)
    const now = new Date()
    const diff = eventDate.getTime() - now.getTime()
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24))
    
    if (days > 0) {
      return `${days} days to go`
    } else if (days === 0) {
      return "Today!"
    } else {
      return "Past Event"
    }
  }

  const getCategoryColor = (category: string) => {
    const colors = {
      'Concert': 'bg-neon-pink/90',
      'Movie': 'bg-electric-purple/90',
      'Education': 'bg-cyber-mint/90',
      'Indie': 'bg-gradient-to-r from-electric-purple to-cyber-mint',
      'Workshop': 'bg-yellow-500/90',
      'Exhibition': 'bg-blue-500/90'
    }
    return colors[category as keyof typeof colors] || 'bg-electric-purple/90'
  }

  // Sort events by date (upcoming first)
  const sortedEvents = [...events].sort((a, b) => {
    const dateA = new Date(a.date)
    const dateB = new Date(b.date)
    return dateA.getTime() - dateB.getTime()
  })

  if (events.length === 0) {
    return (
      <div className="max-w-2xl mx-auto p-6 text-white text-center">
        <div className="glass-dark rounded-2xl p-12 border-electric-purple/30">
          <Calendar className="w-16 h-16 mx-auto mb-6 text-electric-purple/50" />
          <h3 className="text-xl font-bold mb-4 text-glass-white/80">No Events Yet</h3>
          <p className="text-glass-white/60 mb-6">
            Be the first to create an immersive experience for the community!
          </p>
          <Button 
            className="bg-gradient-to-r from-electric-purple to-cyber-mint text-white"
            data-macaly="create-first-event-btn"
          >
            Create Your First Event
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto p-6 text-white">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold hologram-text mb-4" data-macaly="event-feed-title">
          🔮 Upcoming Events
        </h1>
        <p className="text-glass-white/70" data-macaly="event-feed-subtitle">
          Discover and join immersive experiences from the community
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {sortedEvents.map((event) => (
          <Card 
            key={event.id} 
            className={`glass-dark transition-all duration-500 group overflow-hidden ${
              isUpcoming(event.date) 
                ? 'border-electric-purple/50 hover:border-electric-purple shadow-neon' 
                : 'border-electric-purple/20 opacity-75'
            }`}
          >
            <CardContent className="p-6">
              {/* Event Header */}
              <div className="flex justify-between items-start mb-4">
                <Badge className={`${getCategoryColor(event.category)} text-white border-0`}>
                  {event.category}
                </Badge>
                <div className="text-xs text-cyber-mint font-semibold">
                  {getTimeUntil(event.date)}
                </div>
              </div>

              {/* Event Title */}
              <h3 
                className="text-xl font-bold text-white mb-2 group-hover:text-cyber-mint transition-colors duration-300"
                data-macaly={`event-${event.id}-title`}
              >
                {event.name}
              </h3>

              {/* Description */}
              {event.description && (
                <p 
                  className="text-glass-white/80 text-sm mb-4 leading-relaxed"
                  data-macaly={`event-${event.id}-description`}
                >
                  {event.description}
                </p>
              )}

              {/* Event Details */}
              <div className="space-y-2 mb-6 text-sm text-glass-white/70">
                <div className="flex items-center">
                  <Calendar className="w-4 h-4 mr-2 text-electric-purple" />
                  <span>{new Date(event.date).toLocaleDateString('en-US', { 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}</span>
                </div>
                <div className="flex items-center">
                  <Clock className="w-4 h-4 mr-2 text-cyber-mint" />
                  <span>{event.time}</span>
                </div>
                <div className="flex items-center">
                  <Users className="w-4 h-4 mr-2 text-neon-pink" />
                  <span>Capacity: {event.capacity}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2">
                <Button
                  onClick={() => handleRsvp(event.id)}
                  className={
                    rsvps.includes(event.id)
                      ? "bg-green-600 hover:bg-green-700 text-white"
                      : "bg-gradient-to-r from-electric-purple to-cyber-mint hover:from-electric-purple/80 hover:to-cyber-mint/80 text-white"
                  }
                  data-macaly={`event-${event.id}-rsvp-btn`}
                >
                  <Bell className="w-4 h-4 mr-2" />
                  {rsvps.includes(event.id) ? 'RSVP\'d' : 'RSVP'}
                </Button>
                
                {event.link && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-electric-purple/50 text-electric-purple hover:bg-electric-purple/10 hover:border-electric-purple"
                    onClick={() => window.open(event.link, '_blank')}
                    data-macaly={`event-${event.id}-join-btn`}
                  >
                    <ExternalLink className="w-4 h-4 mr-1" />
                    Join
                  </Button>
                )}
              </div>

              {/* RSVP Status */}
              {rsvps.includes(event.id) && (
                <div className="mt-3 text-xs text-green-400 font-semibold">
                  ✓ You're attending this event
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Stats */}
      <div className="mt-12 text-center">
        <Card className="glass-dark border-electric-purple/30 max-w-2xl mx-auto">
          <CardContent className="p-6">
            <div className="grid grid-cols-3 gap-6">
              <div>
                <div className="text-2xl font-bold text-cyber-mint">
                  {events.length}
                </div>
                <div className="text-sm text-glass-white/70">Total Events</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-electric-purple">
                  {events.filter(e => isUpcoming(e.date)).length}
                </div>
                <div className="text-sm text-glass-white/70">Upcoming</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-neon-pink">
                  {rsvps.length}
                </div>
                <div className="text-sm text-glass-white/70">Your RSVPs</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}