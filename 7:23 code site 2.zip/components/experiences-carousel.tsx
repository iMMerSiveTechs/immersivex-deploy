"use client"

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Music, Film, BookOpen, Gamepad2, ChevronLeft, ChevronRight, Play } from 'lucide-react'

const ExperiencesCarousel = () => {
  const [currentIndex, setCurrentIndex] = useState(0)

  console.log("ExperiencesCarousel rendered, currentIndex:", currentIndex)

  const experiences = [
    {
      id: 'concerts',
      title: 'Virtual Concerts',
      description: 'Front-row seats to live performances from your favorite artists in stunning virtual venues.',
      icon: Music,
      gradient: 'from-electric-purple to-neon-pink',
      image: 'https://images.pexels.com/photos/8041015/pexels-photo-8041015.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
      features: ['360° Live Streaming', 'Interactive Fan Zones', 'Backstage Access']
    },
    {
      id: 'vr-films',
      title: 'VR Movies',
      description: 'Immersive storytelling that places you inside the narrative with cinematic VR experiences.',
      icon: Film,
      gradient: 'from-cyber-mint to-electric-purple',
      image: 'https://images.pexels.com/photos/7241304/pexels-photo-7241304.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
      features: ['4K 360° Video', 'Spatial Audio', 'Interactive Scenes']
    },
    {
      id: 'ar-learning',
      title: 'AR Learning',
      description: 'Educational adventures that bring subjects to life through augmented reality.',
      icon: BookOpen,
      gradient: 'from-neon-pink to-cyber-mint',
      image: 'https://images.pexels.com/photos/3761262/pexels-photo-3761262.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
      features: ['Hands-on Learning', 'Real-world Overlay', 'Progress Tracking']
    },
    {
      id: 'indie-games',
      title: 'Indie Games',
      description: 'Discover innovative gaming experiences from independent developers worldwide.',
      icon: Gamepad2,
      gradient: 'from-electric-purple to-cyber-mint',
      image: 'https://images.pexels.com/photos/7199194/pexels-photo-7199194.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
      features: ['Unique Mechanics', 'Creative Worlds', 'Community Features']
    }
  ]

  const nextSlide = () => {
    const newIndex = (currentIndex + 1) % experiences.length
    console.log("Next slide clicked, new index:", newIndex)
    setCurrentIndex(newIndex)
  }

  const prevSlide = () => {
    const newIndex = (currentIndex - 1 + experiences.length) % experiences.length
    console.log("Previous slide clicked, new index:", newIndex)
    setCurrentIndex(newIndex)
  }

  return (
    <section className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-space-blue/50 to-transparent" />
      
      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6"
            data-macaly="experiences-title"
          >
            Immersive Content for{' '}
            <span className="bg-gradient-to-r from-electric-purple to-cyber-mint bg-clip-text text-transparent">
              Every Passion
            </span>
          </h2>
          <p 
            className="text-lg md:text-xl text-glass-white/70 max-w-3xl mx-auto"
            data-macaly="experiences-subtitle"
          >
            From heart-pounding concerts to mind-bending games, explore content that transcends traditional media
          </p>
        </div>

        {/* Carousel Container */}
        <div className="relative max-w-6xl mx-auto">
          {/* Navigation Buttons */}
          <Button
            variant="ghost"
            size="icon"
            className="absolute left-0 top-1/2 -translate-y-1/2 z-20 text-white hover:text-electric-purple hover:bg-glass-100 transition-all duration-300 w-12 h-12 rounded-full glass-dark"
            onClick={prevSlide}
            data-macaly="carousel-prev-btn"
          >
            <ChevronLeft className="w-6 h-6" />
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-0 top-1/2 -translate-y-1/2 z-20 text-white hover:text-electric-purple hover:bg-glass-100 transition-all duration-300 w-12 h-12 rounded-full glass-dark"
            onClick={nextSlide}
            data-macaly="carousel-next-btn"
          >
            <ChevronRight className="w-6 h-6" />
          </Button>

          {/* Carousel Content */}
          <div className="px-16">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              {/* Featured Card */}
              <Card className="glass-dark border-electric-purple/30 hover:border-electric-purple/50 transition-all duration-500 group">
                <CardContent className="p-8">
                  <div className="flex items-center mb-6">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${experiences[currentIndex].gradient} flex items-center justify-center mr-4 group-hover:animate-glow transition-all duration-300`}>
                      {(() => {
                        const IconComponent = experiences[currentIndex].icon;
                        return <IconComponent className="w-6 h-6 text-white" />;
                      })()}
                    </div>
                    <h3 
                      className="text-2xl md:text-3xl font-bold text-white"
                      data-macaly={`experience-${experiences[currentIndex].id}-title`}
                    >
                      {experiences[currentIndex].title}
                    </h3>
                  </div>
                  
                  <p 
                    className="text-glass-white/80 text-lg mb-6 leading-relaxed"
                    data-macaly={`experience-${experiences[currentIndex].id}-description`}
                  >
                    {experiences[currentIndex].description}
                  </p>
                  
                  <div className="space-y-3 mb-8">
                    {experiences[currentIndex].features.map((feature, index) => (
                      <div key={index} className="flex items-center text-glass-white/70">
                        <div className="w-2 h-2 bg-cyber-mint rounded-full mr-3" />
                        {feature}
                      </div>
                    ))}
                  </div>
                  
                  <Button 
                    className={`bg-gradient-to-r ${experiences[currentIndex].gradient} hover:opacity-90 text-white font-semibold px-6 py-3 rounded-lg transition-all duration-300 shadow-neon`}
                    data-macaly={`explore-${experiences[currentIndex].id}-btn`}
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Explore {experiences[currentIndex].title}
                  </Button>
                </CardContent>
              </Card>

              {/* Preview Image */}
              <div className="relative group overflow-hidden rounded-xl">
                <div 
                  className="aspect-video bg-cover bg-center bg-no-repeat transform group-hover:scale-105 transition-transform duration-700 ease-out"
                  style={{
                    backgroundImage: `linear-gradient(rgba(0, 4, 15, 0.4), rgba(36, 24, 68, 0.4)), url('${experiences[currentIndex].image}')`
                  }}
                />
                <div className={`absolute inset-0 bg-gradient-to-br ${experiences[currentIndex].gradient} opacity-10 group-hover:opacity-20 transition-opacity duration-500`} />
                
                <div className="absolute inset-0 flex items-center justify-center">
                  <Button
                    size="lg"
                    className="glass-dark text-white hover:bg-electric-purple/30 rounded-full w-20 h-20 p-0 shadow-neon transform group-hover:scale-110 transition-all duration-300 animate-bounce-subtle"
                    data-macaly={`play-${experiences[currentIndex].id}-preview`}
                  >
                    <Play className="w-8 h-8 ml-1" />
                  </Button>
                </div>
                
                <div className="absolute top-4 right-4">
                  <div className="glass-dark rounded-full px-3 py-1">
                    <div className="flex items-center text-xs text-cyber-mint font-medium">
                      <div className="w-2 h-2 bg-cyber-mint rounded-full mr-2 animate-pulse" />
                      LIVE PREVIEW
                    </div>
                  </div>
                </div>
                
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="glass-dark rounded-lg p-3 backdrop-blur-xl">
                    <p className="text-white text-sm font-medium mb-1">
                      Preview: {experiences[currentIndex].title}
                    </p>
                    <div className="flex items-center text-xs text-glass-white/60">
                      <div className="w-1 h-1 bg-electric-purple rounded-full mr-2 animate-pulse-slow" />
                      {experiences[currentIndex].features[0]}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Dot Indicators */}
          <div className="flex justify-center space-x-3 mt-12">
            {experiences.map((_, index) => (
              <button
                key={index}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index === currentIndex 
                    ? 'bg-electric-purple shadow-neon' 
                    : 'bg-glass-white/30 hover:bg-glass-white/50'
                }`}
                onClick={() => {
                  console.log("Dot indicator clicked, index:", index)
                  setCurrentIndex(index)
                }}
                data-macaly={`carousel-dot-${index}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default ExperiencesCarousel