"use client"

import { useState, useEffect } from "react"

export function DarkModeToggle() {
  const [isDark, setIsDark] = useState(false)

  useEffect(() => {
    // Check initial dark mode preference
    const stored = localStorage.getItem('darkMode')
    const initialDark = stored === 'true' || (stored === null && window.matchMedia('(prefers-color-scheme: dark)').matches)
    setIsDark(initialDark)
    
    if (initialDark) {
      document.body.classList.add('dark-mode')
    }
    
    console.log('DarkModeToggle initialized:', initialDark)
  }, [])

  const toggleDarkMode = () => {
    const newMode = !isDark
    setIsDark(newMode)
    
    if (newMode) {
      document.body.classList.add('dark-mode')
      localStorage.setItem('darkMode', 'true')
    } else {
      document.body.classList.remove('dark-mode')
      localStorage.setItem('darkMode', 'false')
    }
    
    console.log('Dark mode toggled:', newMode)
  }

  return (
    <button
      onClick={toggleDarkMode}
      className="fixed top-4 right-4 w-12 h-12 rounded-full z-50 flex items-center justify-center transition-all duration-500 hardware-accelerated hover:scale-105"
      style={{
        background: isDark 
          ? 'linear-gradient(135deg, rgba(255,255,255,0.15), rgba(99,102,241,0.1))'
          : 'linear-gradient(135deg, rgba(0,0,0,0.15), rgba(99,102,241,0.1))',
        backdropFilter: 'blur(20px) saturate(150%)',
        border: '1px solid rgba(255,255,255,0.2)',
        boxShadow: '0 8px 32px rgba(0,0,0,0.2), inset 0 1px 0 rgba(255,255,255,0.2)'
      }}
      data-macaly="dark-mode-toggle"
    >
      <div className="text-xl transition-transform duration-300 hover:rotate-180">
        {isDark ? '☀️' : '🌙'}
      </div>
    </button>
  )
}