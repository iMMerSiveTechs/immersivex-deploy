"use client"

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Menu, X, Play, Users, Sparkles } from 'lucide-react'

const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  console.log("Navigation mounted, isScrolled:", isScrolled)

  const navItems = [
    { href: '#about', label: 'About' },
    { href: '#creators', label: 'Creators' },
    { href: '#pricing', label: 'Pricing' },
    { href: '/gear', label: 'Gear' },
    { href: '/updates', label: 'Updates' },
    { href: '/events', label: 'Events' },
    { href: '/submit', label: 'Submit' },
    { href: '#contact', label: 'Contact' },
  ]

  return (
    <nav 
      className={`fixed top-0 w-full z-50 transition-all duration-500 ${
        isScrolled 
          ? 'glass-dark backdrop-blur-xl border-b border-electric-purple/20' 
          : 'bg-transparent'
      }`}
      data-macaly="main-navigation"
    >
      <div className="container mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link 
            href="/" 
            className="flex items-center space-x-2 group"
            data-macaly="logo-link"
          >
            <div className="w-8 h-8 bg-gradient-cyber rounded-lg flex items-center justify-center group-hover:animate-glow transition-all duration-300">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-electric-purple to-cyber-mint bg-clip-text text-transparent">
              ImmersiveX
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="text-glass-white hover:text-cyber-mint transition-colors duration-300 font-medium"
                data-macaly={`nav-${item.label.toLowerCase()}`}
              >
                {item.label}
              </Link>
            ))}
          </div>

          {/* Desktop CTA Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <Button 
              variant="ghost" 
              className="text-glass-white hover:text-electric-purple hover:bg-glass-100 transition-all duration-300 rounded-full px-6 py-2 backdrop-blur-md border border-white/10"
              data-macaly="creator-login-btn"
            >
              <Users className="w-4 h-4 mr-2" />
              Creator Login
            </Button>
            <Button 
              className="bg-gradient-to-r from-electric-purple to-cyber-mint hover:from-electric-purple/80 hover:to-cyber-mint/80 text-white font-semibold px-6 py-2 rounded-full transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105"
              data-macaly="join-now-nav-btn"
            >
              <Play className="w-4 h-4 mr-2" />
              Join Now
            </Button>
          </div>


        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden absolute top-full left-0 w-full glass-dark backdrop-blur-xl border-b border-electric-purple/20 animate-slide-up">
            <div className="px-4 py-6 space-y-4">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="block text-glass-white hover:text-cyber-mint transition-colors duration-300 font-medium py-2"
                  onClick={() => {
                    console.log("Mobile nav item clicked:", item.label)
                    setIsMobileMenuOpen(false)
                  }}
                  data-macaly={`mobile-nav-${item.label.toLowerCase()}`}
                >
                  {item.label}
                </Link>
              ))}
              <div className="flex flex-col space-y-3 pt-4 border-t border-electric-purple/20">
                <Button 
                  variant="ghost" 
                  className="text-glass-white hover:text-electric-purple hover:bg-glass-100 justify-start"
                  data-macaly="mobile-creator-login-btn"
                >
                  <Users className="w-4 h-4 mr-2" />
                  Creator Login
                </Button>
                <Button 
                  className="bg-gradient-to-r from-electric-purple to-cyber-mint hover:from-electric-purple/80 hover:to-cyber-mint/80 text-white font-semibold justify-start shadow-neon"
                  data-macaly="mobile-join-now-btn"
                >
                  <Play className="w-4 h-4 mr-2" />
                  Join Now
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}

export default Navigation