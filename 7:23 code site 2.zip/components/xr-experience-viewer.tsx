"use client"

import { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { 
  Play, 
  Maximize, 
  VolumeX, 
  Volume2, 
  Settings, 
  Monitor, 
  Smartphone,
  Headphones,
  Gamepad2,
  Expand,
  Shrink
} from 'lucide-react'

interface XRExperience {
  id: string
  title: string
  description: string
  type: 'unity-webgl' | 'unreal-stream' | 'webxr' | 'ar-web'
  thumbnail: string
  buildUrl?: string
  streamUrl?: string
  isVRReady: boolean
  isARReady: boolean
  supportedDevices: string[]
  resolution: '8K' | '4K' | '1080p'
  fileSize?: string
}

const XRExperienceViewer = () => {
  console.log("XRExperienceViewer component rendered")
  
  const [experiences] = useState<XRExperience[]>([
    {
      id: '1',
      title: 'Virtual Concert Hall',
      description: 'Immersive 3D concert experience built with Unity WebGL',
      type: 'unity-webgl',
      thumbnail: 'https://images.pexels.com/photos/8512644/pexels-photo-8512644.jpeg?auto=compress&cs=tinysrgb&w=800&h=600',
      buildUrl: '/unity-builds/concert-hall/index.html',
      isVRReady: true,
      isARReady: false,
      supportedDevices: ['Desktop', 'Mobile', 'Meta Quest', 'VR Headsets'],
      resolution: '4K',
      fileSize: '450MB'
    },
    {
      id: '2',
      title: 'Mars Exploration VR',
      description: 'Photorealistic Mars environment streamed from Unreal Engine',
      type: 'unreal-stream',
      thumbnail: 'https://images.pexels.com/photos/30547569/pexels-photo-30547569.jpeg?auto=compress&cs=tinysrgb&w=800&h=600',
      streamUrl: 'wss://pixel-stream.immersivex.com/mars-vr',
      isVRReady: true,
      isARReady: false,
      supportedDevices: ['High-end Desktop', 'Meta Quest Pro', 'Apple Vision Pro'],
      resolution: '8K',
      fileSize: 'Streamed'
    },
    {
      id: '3',
      title: 'AR Chemistry Lab',
      description: 'Interactive chemistry experiments in augmented reality',
      type: 'ar-web',
      thumbnail: 'https://images.pexels.com/photos/3761262/pexels-photo-3761262.jpeg?auto=compress&cs=tinysrgb&w=800&h=600',
      buildUrl: '/ar-experiences/chemistry-lab',
      isVRReady: false,
      isARReady: true,
      supportedDevices: ['iPhone', 'Android', 'iPad', 'Apple Vision Pro'],
      resolution: '4K',
      fileSize: '120MB'
    },
    {
      id: '4',
      title: 'Quantum Dreams Game',
      description: 'Next-gen puzzle game with WebXR support',
      type: 'webxr',
      thumbnail: 'https://images.pexels.com/photos/18545023/pexels-photo-18545023.jpeg?auto=compress&cs=tinysrgb&w=800&h=600',
      buildUrl: '/webxr/quantum-dreams',
      isVRReady: true,
      isARReady: true,
      supportedDevices: ['All XR Devices', 'Desktop', 'Mobile'],
      resolution: '4K',
      fileSize: '280MB'
    }
  ])

  const [selectedExperience, setSelectedExperience] = useState<XRExperience | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [currentDevice, setCurrentDevice] = useState<'desktop' | 'mobile' | 'vr'>('desktop')
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [isSafari, setIsSafari] = useState(false)
  const [isMobile, setIsMobile] = useState(false)
  
  const iframeRef = useRef<HTMLIFrameElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  const handlePlayExperience = (experience: XRExperience) => {
    console.log("Playing XR experience:", experience.title)
    setSelectedExperience(experience)
    setIsPlaying(true)
  }

  const handleFullscreen = () => {
    if (!isFullscreen && containerRef.current) {
      containerRef.current.requestFullscreen()
      setIsFullscreen(true)
    } else if (document.fullscreenElement) {
      document.exitFullscreen()
      setIsFullscreen(false)
    }
  }

  const getTypeIcon = (type: XRExperience['type']) => {
    switch (type) {
      case 'unity-webgl':
        return '🎮'
      case 'unreal-stream':
        return '🎬'
      case 'webxr':
        return '🥽'
      case 'ar-web':
        return '📱'
      default:
        return '🌐'
    }
  }

  const getTypeLabel = (type: XRExperience['type']) => {
    switch (type) {
      case 'unity-webgl':
        return 'Unity WebGL'
      case 'unreal-stream':
        return 'Unreal Stream'
      case 'webxr':
        return 'WebXR'
      case 'ar-web':
        return 'Web AR'
      default:
        return 'Web Experience'
    }
  }

  useEffect(() => {
    // Safari and mobile detection
    const userAgent = navigator.userAgent
    setIsSafari(userAgent.includes("Safari") && !userAgent.includes("Chrome"))
    setIsMobile(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent))
    
    // Dark mode detection
    const checkDarkMode = () => {
      setIsDarkMode(window.matchMedia('(prefers-color-scheme: dark)').matches)
    }
    
    checkDarkMode()
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')
    mediaQuery.addEventListener('change', checkDarkMode)
    
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener('fullscreenchange', handleFullscreenChange)
    
    // Log device optimization info
    console.log('XR Viewer initialized:', {
      isSafari: userAgent.includes("Safari") && !userAgent.includes("Chrome"),
      isMobile: /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent),
      isDarkMode: window.matchMedia('(prefers-color-scheme: dark)').matches
    })
    
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange)
      mediaQuery.removeEventListener('change', checkDarkMode)
    }
  }, [])

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-4">
          XR Experience{' '}
          <span className="bg-gradient-to-r from-electric-purple to-cyber-mint bg-clip-text text-transparent">
            Viewer
          </span>
        </h2>
        <p className="text-glass-white/70 max-w-2xl mx-auto">
          Immersive Unity WebGL, Unreal Engine streaming, and WebXR experiences optimized for 8K-12K displays
        </p>
      </div>

      {/* Device Selector */}
      <div className="flex justify-center gap-3">
        <Button
          variant={currentDevice === 'desktop' ? 'default' : 'outline'}
          onClick={() => setCurrentDevice('desktop')}
          className={currentDevice === 'desktop' 
            ? 'bg-gradient-to-r from-electric-purple to-cyber-mint text-white'
            : 'border-electric-purple/50 text-electric-purple hover:bg-electric-purple/10'
          }
        >
          <Monitor className="w-4 h-4 mr-2" />
          Desktop
        </Button>
        <Button
          variant={currentDevice === 'mobile' ? 'default' : 'outline'}
          onClick={() => setCurrentDevice('mobile')}
          className={currentDevice === 'mobile' 
            ? 'bg-gradient-to-r from-electric-purple to-cyber-mint text-white'
            : 'border-electric-purple/50 text-electric-purple hover:bg-electric-purple/10'
          }
        >
          <Smartphone className="w-4 h-4 mr-2" />
          Mobile
        </Button>
        <Button
          variant={currentDevice === 'vr' ? 'default' : 'outline'}
          onClick={() => setCurrentDevice('vr')}
          className={currentDevice === 'vr' 
            ? 'bg-gradient-to-r from-electric-purple to-cyber-mint text-white'
            : 'border-electric-purple/50 text-electric-purple hover:bg-electric-purple/10'
          }
        >
          <Headphones className="w-4 h-4 mr-2" />
          VR/AR
        </Button>
      </div>

      {/* Experiences Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {experiences.map((experience) => (
          <Card 
            key={experience.id}
            className="glass-dark border-electric-purple/30 hover:border-electric-purple/50 transition-all duration-500 group overflow-hidden"
          >
            <div className="relative">
              <div className="aspect-video relative overflow-hidden">
                <img 
                  src={experience.thumbnail}
                  alt={experience.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                
                {/* Resolution Badge */}
                <Badge className="absolute top-3 left-3 bg-gradient-to-r from-neon-pink to-electric-purple text-white border-0">
                  {experience.resolution}
                </Badge>
                
                {/* Type Badge */}
                <Badge className="absolute top-3 right-3 glass border-cyber-mint/50 text-cyber-mint">
                  {getTypeIcon(experience.type)} {getTypeLabel(experience.type)}
                </Badge>

                {/* XR and Compatibility Badges */}
                <div className="absolute bottom-3 left-3 flex gap-2 flex-wrap">
                  {experience.isVRReady && (
                    <Badge className="bg-electric-purple/80 text-white text-xs">VR</Badge>
                  )}
                  {experience.isARReady && (
                    <Badge className="bg-cyber-mint/80 text-black text-xs">AR</Badge>
                  )}
                  {isSafari && (
                    <Badge className="bg-cyan-500/80 text-white text-xs">Safari ✓</Badge>
                  )}
                  {isMobile && (
                    <Badge className="bg-green-500/80 text-white text-xs">Mobile ✓</Badge>
                  )}
                </div>

                {/* Play Button Overlay */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/50">
                  <Button
                    onClick={() => handlePlayExperience(experience)}
                    className="bg-gradient-to-r from-electric-purple to-cyber-mint hover:from-electric-purple/80 hover:to-cyber-mint/80 text-white rounded-full w-16 h-16 shadow-2xl shadow-electric-purple/50"
                  >
                    <Play className="w-6 h-6" />
                  </Button>
                </div>
              </div>

              <CardContent className="p-4">
                <h3 className="text-lg font-bold text-white mb-2 group-hover:text-cyber-mint transition-colors duration-300">
                  {experience.title}
                </h3>
                
                <p className="text-glass-white/70 text-sm mb-3 leading-relaxed line-clamp-2">
                  {experience.description}
                </p>

                <div className="flex items-center justify-between text-xs text-glass-white/60 mb-4">
                  <div className="flex items-center gap-2">
                    <span>{experience.fileSize}</span>
                    {isSafari && <span className="text-cyan-400">Safari ✓</span>}
                    {isMobile && <span className="text-green-400">Mobile ✓</span>}
                  </div>
                  <span>{experience.supportedDevices.length} devices</span>
                </div>

                <Button 
                  onClick={() => handlePlayExperience(experience)}
                  className="w-full bg-gradient-to-r from-electric-purple to-cyber-mint hover:from-electric-purple/80 hover:to-cyber-mint/80 text-white font-semibold transition-all duration-300"
                >
                  <Gamepad2 className="w-4 h-4 mr-2" />
                  Launch Experience
                </Button>
              </CardContent>
            </div>
          </Card>
        ))}
      </div>

      {/* Experience Player Dialog */}
      <Dialog open={isPlaying} onOpenChange={setIsPlaying}>
        <DialogContent className="max-w-6xl w-full h-[80vh] glass-dark border-electric-purple/50 p-0">
          <DialogHeader className="p-6 pb-0">
            <DialogTitle className="text-white flex items-center justify-between">
              <span>{selectedExperience?.title}</span>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsMuted(!isMuted)}
                  className="text-glass-white hover:text-white"
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleFullscreen}
                  className="text-glass-white hover:text-white"
                >
                  {isFullscreen ? <Shrink className="w-4 h-4" /> : <Expand className="w-4 h-4" />}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-glass-white hover:text-white"
                >
                  <Settings className="w-4 h-4" />
                </Button>
              </div>
            </DialogTitle>
          </DialogHeader>

          <div ref={containerRef} className="flex-1 p-6 pt-0">
            {selectedExperience && (
              <div className="w-full h-full bg-black rounded-lg overflow-hidden">
                {selectedExperience.type === 'unity-webgl' && (
                  <iframe
                    ref={iframeRef}
                    src={`${selectedExperience.buildUrl}${
                      selectedExperience.buildUrl?.includes('?') ? '&' : '?'
                    }${isSafari ? 'safari=true&' : ''}${isMobile ? 'mobile=true&' : ''}quality=${isSafari ? 'medium' : 'high'}`}
                    className="w-full h-full border-0"
                    title={selectedExperience.title}
                    allowFullScreen
                    allow="xr-spatial-tracking; gyroscope; accelerometer; microphone; camera"
                    onLoad={() => {
                      console.log('Unity WebGL loaded with optimizations:', {
                        safari: isSafari,
                        mobile: isMobile,
                        quality: isSafari ? 'medium' : 'high'
                      })
                    }}
                  />
                )}
                
                {selectedExperience.type === 'unreal-stream' && (
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-electric-purple/20 to-cyber-mint/20">
                    <div className="text-center text-white space-y-4">
                      <div className="w-16 h-16 mx-auto bg-gradient-to-r from-electric-purple to-cyber-mint rounded-full flex items-center justify-center">
                        <Monitor className="w-8 h-8" />
                      </div>
                      <h3 className="text-lg font-semibold">Unreal Engine Streaming</h3>
                      <p className="text-glass-white/70">
                        Connecting to high-performance GPU server...
                      </p>
                      <Button className="bg-gradient-to-r from-electric-purple to-cyber-mint text-white">
                        Start Stream
                      </Button>
                    </div>
                  </div>
                )}

                {(selectedExperience.type === 'webxr' || selectedExperience.type === 'ar-web') && (
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-electric-purple/20 to-cyber-mint/20">
                    <div className="text-center text-white space-y-4">
                      <div className="w-16 h-16 mx-auto bg-gradient-to-r from-electric-purple to-cyber-mint rounded-full flex items-center justify-center">
                        <Headphones className="w-8 h-8" />
                      </div>
                      <h3 className="text-lg font-semibold">
                        {selectedExperience.type === 'webxr' ? 'WebXR Ready' : 'AR Experience'}
                      </h3>
                      <p className="text-glass-white/70">
                        Put on your headset or use your mobile device for AR
                      </p>
                      <Button className="bg-gradient-to-r from-electric-purple to-cyber-mint text-white">
                        Enter {selectedExperience.isVRReady ? 'VR' : 'AR'}
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default XRExperienceViewer