"use client"

import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Upload, DollarSign, TrendingUp, Users, Palette, Code, Camera, Music } from 'lucide-react'

const CreatorsSection = () => {
  console.log("CreatorsSection component rendered")

  const creatorTypes = [
    {
      title: 'Visual Artists',
      description: 'Create stunning VR galleries and immersive art installations',
      icon: Palette,
      gradient: 'from-electric-purple to-neon-pink'
    },
    {
      title: 'Developers',
      description: 'Build innovative games and interactive experiences',
      icon: Code,
      gradient: 'from-cyber-mint to-electric-purple'
    },
    {
      title: 'Filmmakers',
      description: 'Craft cinematic VR stories and 360° documentaries',
      icon: Camera,
      gradient: 'from-neon-pink to-cyber-mint'
    },
    {
      title: 'Musicians',
      description: 'Host virtual concerts and create spatial audio experiences',
      icon: Music,
      gradient: 'from-electric-purple to-cyber-mint'
    }
  ]

  const benefits = [
    {
      title: 'Revenue Sharing',
      description: 'Keep 80% of your earnings with transparent payouts',
      icon: DollarSign,
      color: 'text-cyber-mint'
    },
    {
      title: 'Global Reach',
      description: 'Access millions of users across all platforms',
      icon: TrendingUp,
      color: 'text-electric-purple'
    },
    {
      title: 'Community Support',
      description: 'Connect with fellow creators and collaborate',
      icon: Users,
      color: 'text-neon-pink'
    }
  ]

  return (
    <section id="creators" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-electric-purple/10 to-transparent" />
        {/* Floating Elements */}
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-cyber-mint/40 rounded-full animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 8}s`,
              animationDuration: `${6 + Math.random() * 6}s`
            }}
          />
        ))}
      </div>

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6"
            data-macaly="creators-title"
          >
            Built for{' '}
            <span className="bg-gradient-to-r from-electric-purple to-cyber-mint bg-clip-text text-transparent">
              Creators
            </span>
          </h2>
          <p 
            className="text-lg md:text-xl text-glass-white/70 max-w-4xl mx-auto leading-relaxed"
            data-macaly="creators-subtitle"
          >
            Join thousands of artists, developers, and storytellers who are shaping the future of immersive entertainment. 
            Turn your creative vision into reality with our powerful tools and global platform.
          </p>
        </div>

        {/* Creator Types Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {creatorTypes.map((type, index) => (
            <Card key={type.title} className="glass-dark border-electric-purple/20 hover:border-electric-purple/40 transition-all duration-500 group">
              <CardContent className="p-6 text-center">
                <div className={`w-12 h-12 mx-auto mb-4 rounded-lg bg-gradient-to-r ${type.gradient} flex items-center justify-center group-hover:animate-glow transition-all duration-300`}>
                  <type.icon className="w-6 h-6 text-white" />
                </div>
                <h3 
                  className="text-lg font-bold text-white mb-2"
                  data-macaly={`creator-type-${type.title.toLowerCase().replace(' ', '-')}-title`}
                >
                  {type.title}
                </h3>
                <p 
                  className="text-sm text-glass-white/70 leading-relaxed"
                  data-macaly={`creator-type-${type.title.toLowerCase().replace(' ', '-')}-description`}
                >
                  {type.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
          {/* Left Content - Benefits */}
          <div>
            <h3 
              className="text-2xl md:text-3xl font-bold text-white mb-8"
              data-macaly="creator-benefits-title"
            >
              Why Choose ImmersiveX?
            </h3>
            
            <div className="space-y-8">
              {benefits.map((benefit, index) => (
                <div key={benefit.title} className="flex items-start space-x-4 group">
                  <div className="w-12 h-12 rounded-lg glass-dark border border-electric-purple/30 flex items-center justify-center group-hover:border-electric-purple/50 transition-all duration-300">
                    <benefit.icon className={`w-6 h-6 ${benefit.color}`} />
                  </div>
                  <div>
                    <h4 
                      className="text-lg font-semibold text-white mb-2"
                      data-macaly={`benefit-${benefit.title.toLowerCase().replace(' ', '-')}-title`}
                    >
                      {benefit.title}
                    </h4>
                    <p 
                      className="text-glass-white/80 leading-relaxed"
                      data-macaly={`benefit-${benefit.title.toLowerCase().replace(' ', '-')}-description`}
                    >
                      {benefit.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Content - CTA Card */}
          <Card className="glass-dark border-electric-purple/30 hover:border-electric-purple/50 transition-all duration-500">
            <CardContent className="p-8 text-center">
              <div className="w-20 h-20 mx-auto mb-6 rounded-xl bg-gradient-cyber flex items-center justify-center animate-pulse-slow">
                <Upload className="w-10 h-10 text-white" />
              </div>
              
              <h3 
                className="text-2xl font-bold text-white mb-4"
                data-macaly="upload-content-title"
              >
                Start Creating Today
              </h3>
              
              <p 
                className="text-glass-white/80 mb-8 leading-relaxed"
                data-macaly="upload-content-description"
              >
                Upload your first immersive experience and reach a global audience. 
                Our intuitive tools make it easy to publish VR, AR, and interactive content.
              </p>
              
              <div className="space-y-4">
                <Button 
                  size="lg"
                  className="w-full bg-gradient-to-r from-electric-purple to-cyber-mint hover:from-electric-purple/80 hover:to-cyber-mint/80 text-white font-semibold py-3 rounded-lg transition-all duration-300 shadow-neon"
                  data-macaly="upload-content-btn"
                >
                  <Upload className="w-5 h-5 mr-2" />
                  Upload Content
                </Button>
                
                <Button 
                  variant="outline"
                  size="lg"
                  className="w-full border-electric-purple/50 text-electric-purple hover:bg-electric-purple/10 hover:border-electric-purple font-semibold py-3 rounded-lg transition-all duration-300"
                  data-macaly="creator-resources-btn"
                >
                  View Creator Resources
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Success Stories Testimonial */}
        <div className="text-center">
          <Card className="glass-dark border-electric-purple/20 max-w-4xl mx-auto">
            <CardContent className="p-8 md:p-12">
              <div className="mb-6">
                <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-r from-neon-pink to-cyber-mint flex items-center justify-center mb-4">
                  <span className="text-2xl font-bold text-white">AZ</span>
                </div>
                <h4 className="text-lg font-semibold text-white">Alex Zhang</h4>
                <p className="text-glass-white/60 text-sm">VR Artist & Developer</p>
              </div>
              
              <blockquote 
                className="text-lg md:text-xl text-glass-white/90 italic leading-relaxed mb-6"
                data-macaly="creator-testimonial-quote"
              >
                "ImmersiveX gave me the platform to turn my wildest creative ideas into reality. 
                In just 6 months, I've reached over 100K users and built a sustainable creative business."
              </blockquote>
              
              <div className="flex justify-center items-center space-x-8 text-sm text-glass-white/60">
                <div className="flex items-center">
                  <Users className="w-4 h-4 mr-1 text-cyber-mint" />
                  <span>120K+ Viewers</span>
                </div>
                <div className="flex items-center">
                  <TrendingUp className="w-4 h-4 mr-1 text-electric-purple" />
                  <span>$50K+ Revenue</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}

export default CreatorsSection