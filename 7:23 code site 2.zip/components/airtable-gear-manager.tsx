"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Star, ShoppingCart, ExternalLink, Zap, Plus, Edit, Trash2, Save, X } from 'lucide-react'

interface AirtableProduct {
  id: string
  title: string
  description: string
  price: string
  originalPrice?: string
  image: string
  affiliateUrl: string
  isEditorsPick: boolean
  rating: number
  category: string
  isActive: boolean
}

const AirtableGearManager = () => {
  console.log("AirtableGearManager component rendered")
  
  const [products, setProducts] = useState<AirtableProduct[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [editingProduct, setEditingProduct] = useState<string | null>(null)
  const [newProduct, setNewProduct] = useState<Partial<AirtableProduct>>({})
  const [showAddForm, setShowAddForm] = useState(false)
  const [filterCategory, setFilterCategory] = useState('All')

  // Mock Airtable data - replace with actual API call
  const mockProducts: AirtableProduct[] = [
    {
      id: '1',
      title: "Meta Quest 3 128GB",
      description: "The most advanced mixed reality headset with breakthrough technology and hand tracking",
      price: "$499.99",
      originalPrice: "$599.99",
      image: "https://images.pexels.com/photos/7241304/pexels-photo-7241304.jpeg?auto=compress&cs=tinysrgb&w=400&h=300",
      affiliateUrl: "https://amazon.com/dp/B0C8VKH1ZH?tag=immersivex-20",
      isEditorsPick: true,
      rating: 4.8,
      category: "VR Headsets",
      isActive: true
    },
    {
      id: '2',
      title: "Apple Vision Pro",
      description: "Revolutionary spatial computing with infinite canvas for apps and immersive experiences",
      price: "$3,499.00",
      image: "https://images.pexels.com/photos/7886853/pexels-photo-7886853.jpeg?auto=compress&cs=tinysrgb&w=400&h=300",
      affiliateUrl: "https://apple.com/apple-vision-pro/?afid=p238%7CsX5wq2ym5-dc_mtid_1870765e38482_pcrid_",
      isEditorsPick: true,
      rating: 4.9,
      category: "AR/MR Headsets",
      isActive: true
    },
    {
      id: '3',
      title: "Unity Pro License",
      description: "Professional game development platform for creating immersive XR experiences",
      price: "$185.00",
      originalPrice: "$250.00",
      image: "https://via.placeholder.com/400x300/6366F1/FFFFFF?text=Unity+Pro",
      affiliateUrl: "https://unity.com/products/unity-pro?ref=immersivex",
      isEditorsPick: false,
      rating: 4.7,
      category: "Software",
      isActive: true
    },
    {
      id: '4',
      title: "Unreal Engine Enterprise",
      description: "Industry-leading real-time 3D creation tool for immersive experiences and games",
      price: "Free",
      image: "https://via.placeholder.com/400x300/10FFF0/000000?text=Unreal+Engine",
      affiliateUrl: "https://unrealengine.com/enterprise?ref=immersivex",
      isEditorsPick: true,
      rating: 4.9,
      category: "Software",
      isActive: true
    }
  ]

  const categories = ["All", "VR Headsets", "AR/MR Headsets", "Software", "Accessories", "Complete Setups"]

  // Load products (simulate Airtable API call)
  useEffect(() => {
    const loadProducts = async () => {
      setIsLoading(true)
      console.log("Loading products from Airtable...")
      
      // Simulate API delay
      setTimeout(() => {
        setProducts(mockProducts)
        setIsLoading(false)
        console.log("Products loaded successfully")
      }, 1000)
    }

    loadProducts()
  }, [])

  // Filter products by category
  const filteredProducts = products.filter(product => 
    filterCategory === 'All' || product.category === filterCategory
  )

  const handleAddProduct = () => {
    console.log("Adding new product:", newProduct)
    
    const product: AirtableProduct = {
      id: Date.now().toString(),
      title: newProduct.title || '',
      description: newProduct.description || '',
      price: newProduct.price || '',
      originalPrice: newProduct.originalPrice,
      image: newProduct.image || 'https://via.placeholder.com/400x300/6366F1/FFFFFF?text=New+Product',
      affiliateUrl: newProduct.affiliateUrl || '#',
      isEditorsPick: newProduct.isEditorsPick || false,
      rating: newProduct.rating || 4.5,
      category: newProduct.category || 'Accessories',
      isActive: true
    }
    
    setProducts(prev => [...prev, product])
    setNewProduct({})
    setShowAddForm(false)
  }

  const handleUpdateProduct = (productId: string, updates: Partial<AirtableProduct>) => {
    console.log("Updating product:", productId, updates)
    
    setProducts(prev => 
      prev.map(product => 
        product.id === productId 
          ? { ...product, ...updates }
          : product
      )
    )
    setEditingProduct(null)
  }

  const handleDeleteProduct = (productId: string) => {
    console.log("Deleting product:", productId)
    setProducts(prev => prev.filter(product => product.id !== productId))
  }

  return (
    <div className="space-y-8">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">Gear Vault Manager</h2>
          <p className="text-glass-white/70">Manage affiliate products via Airtable integration</p>
        </div>
        
        <div className="flex gap-3">
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="w-40 glass-dark border-electric-purple/30">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {categories.map(category => (
                <SelectItem key={category} value={category}>{category}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Button
            onClick={() => setShowAddForm(!showAddForm)}
            className="bg-gradient-to-r from-electric-purple to-cyber-mint text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Product
          </Button>
        </div>
      </div>

      {/* Add New Product Form */}
      {showAddForm && (
        <Card className="glass-dark border-electric-purple/30">
          <CardHeader>
            <h3 className="text-lg font-semibold text-white">Add New Product</h3>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <Input
                placeholder="Product Title"
                value={newProduct.title || ''}
                onChange={(e) => setNewProduct(prev => ({...prev, title: e.target.value}))}
                className="glass-dark border-electric-purple/30"
              />
              <Select
                value={newProduct.category || ''}
                onValueChange={(value) => setNewProduct(prev => ({...prev, category: value}))}
              >
                <SelectTrigger className="glass-dark border-electric-purple/30">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.slice(1).map(category => (
                    <SelectItem key={category} value={category}>{category}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                placeholder="Price (e.g., $99.99)"
                value={newProduct.price || ''}
                onChange={(e) => setNewProduct(prev => ({...prev, price: e.target.value}))}
                className="glass-dark border-electric-purple/30"
              />
              <Input
                placeholder="Affiliate URL"
                value={newProduct.affiliateUrl || ''}
                onChange={(e) => setNewProduct(prev => ({...prev, affiliateUrl: e.target.value}))}
                className="glass-dark border-electric-purple/30"
              />
            </div>
            <Input
              placeholder="Product Description"
              value={newProduct.description || ''}
              onChange={(e) => setNewProduct(prev => ({...prev, description: e.target.value}))}
              className="glass-dark border-electric-purple/30"
            />
            <Input
              placeholder="Image URL"
              value={newProduct.image || ''}
              onChange={(e) => setNewProduct(prev => ({...prev, image: e.target.value}))}
              className="glass-dark border-electric-purple/30"
            />
            
            <div className="flex justify-end gap-3">
              <Button
                variant="outline"
                onClick={() => setShowAddForm(false)}
                className="border-electric-purple/50 text-electric-purple"
              >
                <X className="w-4 h-4 mr-2" />
                Cancel
              </Button>
              <Button
                onClick={handleAddProduct}
                className="bg-gradient-to-r from-electric-purple to-cyber-mint text-white"
              >
                <Save className="w-4 h-4 mr-2" />
                Add Product
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Products Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {isLoading ? (
          Array.from({ length: 8 }).map((_, i) => (
            <Card key={i} className="glass-dark border-electric-purple/30 animate-pulse">
              <div className="aspect-video bg-electric-purple/20" />
              <CardContent className="p-4 space-y-3">
                <div className="h-4 bg-electric-purple/20 rounded" />
                <div className="h-3 bg-electric-purple/10 rounded" />
                <div className="h-8 bg-electric-purple/20 rounded" />
              </CardContent>
            </Card>
          ))
        ) : (
          filteredProducts.map((product) => (
            <Card 
              key={product.id} 
              className="glass-dark border-electric-purple/30 hover:border-electric-purple/50 transition-all duration-500 group"
            >
              <div className="relative">
                <div className="aspect-video bg-gradient-to-br from-electric-purple/20 to-cyber-mint/20 relative overflow-hidden">
                  <img 
                    src={product.image} 
                    alt={product.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  {product.isEditorsPick && (
                    <Badge className="absolute top-3 left-3 bg-gradient-to-r from-neon-pink to-electric-purple text-white border-0">
                      <Star className="w-3 h-3 mr-1" />
                      Editor's Pick
                    </Badge>
                  )}
                  {product.originalPrice && (
                    <Badge className="absolute top-3 right-3 bg-red-500/90 text-white border-0">
                      Sale
                    </Badge>
                  )}
                </div>

                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-cyber-mint font-medium">{product.category}</span>
                    <div className="flex items-center text-xs text-glass-white/60">
                      <Star className="w-3 h-3 text-yellow-400 mr-1" />
                      {product.rating}
                    </div>
                  </div>

                  <h3 className="text-sm font-bold text-white mb-2 group-hover:text-cyber-mint transition-colors duration-300">
                    {product.title}
                  </h3>

                  <p className="text-glass-white/70 text-xs mb-3 leading-relaxed line-clamp-2">
                    {product.description}
                  </p>

                  <div className="flex items-center gap-2 mb-4">
                    <span className="text-lg font-bold text-white">{product.price}</span>
                    {product.originalPrice && (
                      <span className="text-xs text-glass-white/50 line-through">
                        {product.originalPrice}
                      </span>
                    )}
                  </div>

                  <div className="flex gap-2">
                    <Button 
                      size="sm"
                      className="flex-1 bg-gradient-to-r from-electric-purple to-cyber-mint hover:from-electric-purple/80 hover:to-cyber-mint/80 text-white text-xs"
                      asChild
                    >
                      <a href={product.affiliateUrl} target="_blank" rel="noopener noreferrer">
                        <ShoppingCart className="w-3 h-3 mr-1" />
                        Buy
                        <ExternalLink className="w-3 h-3 ml-1" />
                      </a>
                    </Button>
                    
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-electric-purple/50 text-electric-purple hover:bg-electric-purple/10"
                      onClick={() => setEditingProduct(product.id)}
                    >
                      <Edit className="w-3 h-3" />
                    </Button>
                    
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-red-500/50 text-red-400 hover:bg-red-500/10"
                      onClick={() => handleDeleteProduct(product.id)}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </CardContent>
              </div>
            </Card>
          ))
        )}
      </div>

      {/* Airtable Integration Info */}
      <Card className="glass-dark border-electric-purple/30">
        <CardContent className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <Zap className="w-6 h-6 text-cyber-mint" />
            <h3 className="text-lg font-semibold text-white">Airtable Integration</h3>
          </div>
          <p className="text-glass-white/70 mb-4">
            Connect your Airtable base to automatically sync affiliate products. Update pricing, add new items, or modify descriptions directly in Airtable and see changes reflected instantly.
          </p>
          <div className="flex gap-3">
            <Button className="bg-gradient-to-r from-electric-purple to-cyber-mint text-white">
              Connect Airtable
            </Button>
            <Button variant="outline" className="border-electric-purple/50 text-electric-purple">
              View API Docs
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default AirtableGearManager