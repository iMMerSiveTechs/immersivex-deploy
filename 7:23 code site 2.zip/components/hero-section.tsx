"use client"

import { Button } from '@/components/ui/button'
import { Play, Sparkles, Zap } from 'lucide-react'

const HeroSection = () => {
  console.log("HeroSection component rendered")

  return (
    <section className="spatial-container relative min-h-screen flex items-center justify-center overflow-hidden xr-enhanced">
      {/* Enhanced 3D Immersive Background */}
      <div className="absolute inset-0 z-0 animate-holographic-shimmer">
        {/* Hero Background Image with 3D depth */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat scale-105 animate-ken-burns animate-spatial-depth"
          style={{
            backgroundImage: `url('https://images.pexels.com/photos/7886853/pexels-photo-7886853.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940')`
          }}
        />
        
        {/* Multi-layered Gradient Overlay with spatial depth */}
        <div className="absolute inset-0 bg-gradient-to-br from-space-blue/95 via-deep-black/85 to-electric-purple/30 animate-spatial-gradient" />
        <div className="absolute inset-0 bg-gradient-to-t from-deep-black/80 via-transparent to-transparent" />
        
        {/* Quantum Data Streams */}
        <div className="absolute top-0 left-1/4 w-px h-full bg-gradient-to-b from-transparent via-cyber-mint/30 to-transparent animate-data-stream" style={{ animationDelay: '0s' }} />
        <div className="absolute top-0 left-2/4 w-px h-full bg-gradient-to-b from-transparent via-electric-purple/30 to-transparent animate-data-stream" style={{ animationDelay: '1s' }} />
        <div className="absolute top-0 left-3/4 w-px h-full bg-gradient-to-b from-transparent via-neon-pink/30 to-transparent animate-data-stream" style={{ animationDelay: '2s' }} />
        
        {/* Enhanced 3D Floating Particles */}
        <div className="absolute inset-0">
          {[...Array(25)].map((_, i) => (
            <div
              key={i}
              className={`absolute rounded-full animate-float-3d ${
                i % 3 === 0 ? 'w-3 h-3 bg-cyber-mint/40 animate-neural-network' : 
                i % 3 === 1 ? 'w-2 h-2 bg-electric-purple/30 animate-hologram' : 
                'w-1 h-1 bg-neon-pink/50 animate-quantum-tunnel'
              }`}
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 8}s`,
                animationDuration: `${6 + Math.random() * 6}s`
              }}
            />
          ))}
        </div>

        {/* 3D Floating Orbs */}
        <div className="absolute top-1/4 left-1/6 w-8 h-8 rounded-full bg-gradient-radial from-cyber-mint/40 to-transparent animate-float-3d" style={{ animationDelay: '0.5s' }} />
        <div className="absolute top-2/3 right-1/4 w-12 h-12 rounded-full bg-gradient-radial from-electric-purple/30 to-transparent animate-float-3d" style={{ animationDelay: '1.5s' }} />
        <div className="absolute top-1/2 right-1/6 w-6 h-6 rounded-full bg-gradient-radial from-neon-pink/35 to-transparent animate-float-3d" style={{ animationDelay: '2.5s' }} />

        {/* Advanced 3D Grid Pattern */}
        <div 
          className="absolute inset-0 opacity-20 animate-neural-network"
          style={{
            backgroundImage: `
              linear-gradient(rgba(16, 255, 240, 0.2) 1px, transparent 1px),
              linear-gradient(90deg, rgba(99, 102, 241, 0.2) 1px, transparent 1px)
            `,
            backgroundSize: '80px 80px'
          }}
        />
        
        {/* Enhanced Noise Texture with holographic effect */}
        <div className="absolute inset-0 opacity-5 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48ZmlsdGVyIGlkPSJub2lzZSI+PGZlVHVyYnVsZW5jZSBiYXNlRnJlcXVlbmN5PSIwLjkiIG51bU9jdGF2ZXM9IjQiIHJlc3VsdD0ibm9pc2UiLz48ZmVDb2xvck1hdHJpeCBpbj0ibm9pc2UiIHR5cGU9InNhdHVyYXRlIiB2YWx1ZXM9IjAiLz48L2ZpbHRlcj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsdGVyPSJ1cmwoI25vaXNlKSIgb3BhY2l0eT0iMC4xIi8+PC9zdmc+')] animate-hologram" />
      </div>

      {/* Enhanced 3D Content */}
      <div className="relative z-10 text-center px-4 max-w-6xl mx-auto spatial-card">
        {/* Security Indicator */}
        <div className="security-indicator mb-6 inline-block">
          <span className="text-xs">Secure Platform</span>
        </div>

        {/* Main Heading with Holographic Effects */}
        <div className="mb-8 animate-fade-in-up">
          <h1 
            className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight ultra-hd-text animate-float-3d"
            data-macaly="hero-title"
          >
            <span className="block mb-2 hologram-text">Experience Everything.</span>
            <span className="block mb-2 hologram-text">Everywhere.</span>
            <span className="block hologram-text animate-hologram-glow">
              Immersively.
            </span>
          </h1>
          
          <p 
            className="text-lg md:text-xl lg:text-2xl text-glass-white/80 max-w-3xl mx-auto leading-relaxed font-light ultra-hd-text animate-fade-in-up"
            data-macaly="hero-subtitle"
            style={{ animationDelay: '0.3s' }}
          >
            Step into the future of entertainment. Virtual concerts, VR films, AR learning adventures, 
            and indie games that transport you beyond reality.
          </p>
        </div>

        {/* Enhanced 3D CTAs */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12 animate-fade-in-up" style={{ animationDelay: '0.6s' }}>
          <Button 
            size="lg"
            className="btn-3d-enhanced bg-gradient-to-r from-electric-purple to-cyber-mint hover:from-electric-purple/80 hover:to-cyber-mint/80 text-white font-semibold px-8 py-4 text-lg rounded-full transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105"
            data-macaly="explore-experiences-btn"
          >
            <Sparkles className="w-5 h-5 mr-2 animate-pulse-spatial" />
            Explore Experiences
          </Button>
          
          <Button 
            variant="outline"
            size="lg"
            className="btn-3d-enhanced glass-3d-enhanced border-2 border-electric-purple/50 text-electric-purple hover:bg-electric-purple/10 hover:border-electric-purple font-semibold px-8 py-4 text-lg rounded-full transition-all duration-300 backdrop-blur-sm hover:scale-105"
            data-macaly="watch-demo-btn"
          >
            <Play className="w-5 h-5 mr-2 animate-bounce-subtle" />
            Watch Demo
          </Button>
        </div>

        {/* Enhanced 3D Platform Badges */}
        <div className="flex flex-wrap justify-center items-center gap-8 text-sm animate-fade-in-up" style={{ animationDelay: '0.9s' }}>
          <div className="glass-3d-enhanced spatial-card rounded-full px-4 py-2 border border-cyber-mint/30 hover:border-cyber-mint/50 transition-all duration-300 group animate-neural-network">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-cyber-mint rounded-full animate-pulse-spatial group-hover:animate-glow" />
              <span className="text-glass-white/80 group-hover:text-white transition-colors duration-300">Meta Quest</span>
            </div>
          </div>
          <div className="glass-3d-enhanced spatial-card rounded-full px-4 py-2 border border-electric-purple/30 hover:border-electric-purple/50 transition-all duration-300 group animate-neural-network" style={{ animationDelay: '0.5s' }}>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-electric-purple rounded-full animate-pulse-spatial group-hover:animate-glow" />
              <span className="text-glass-white/80 group-hover:text-white transition-colors duration-300">Vision Pro</span>
            </div>
          </div>
          <div className="glass-3d-enhanced spatial-card rounded-full px-4 py-2 border border-neon-pink/30 hover:border-neon-pink/50 transition-all duration-300 group animate-neural-network" style={{ animationDelay: '1s' }}>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-neon-pink rounded-full animate-pulse-spatial group-hover:animate-glow" />
              <span className="text-glass-white/80 group-hover:text-white transition-colors duration-300">Desktop & Mobile</span>
            </div>
          </div>
          <div className="glass-3d-enhanced spatial-card rounded-full px-4 py-2 border border-cyber-mint/30 hover:border-cyber-mint/50 transition-all duration-300 group animate-neural-network" style={{ animationDelay: '1.5s' }}>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-cyber-mint rounded-full animate-pulse-spatial group-hover:animate-glow" />
              <span className="text-glass-white/80 group-hover:text-white transition-colors duration-300">iPhone AR</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <div className="flex flex-col items-center text-glass-white/50 animate-bounce">
          <Zap className="w-6 h-6 mb-2" />
          <span className="text-xs">Scroll to explore</span>
        </div>
      </div>
    </section>
  )
}

export default HeroSection