"use client"

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import { Send, MessageCircle, HelpCircle, Zap } from 'lucide-react'

const ContactSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  })

  console.log("ContactSection rendered, formData:", formData)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    console.log(`Form field ${name} changed to:`, value)
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Form submitted with data:", formData)
    // Here you would typically send the form data to your backend
    alert('Thank you for your message! We\'ll get back to you soon.')
  }

  const faqs = [
    {
      question: 'What devices are supported?',
      answer: 'ImmersiveX works on Meta Quest 2/3/Pro, Apple Vision Pro, HTC Vive, iPhone/iPad AR, Android AR, desktop web browsers, smart TVs, and gaming consoles. We continuously add support for new devices.'
    },
    {
      question: 'How do I upload my own content?',
      answer: 'Creators can upload content through our Creator Portal. Simply create a creator account, upload your VR/AR experiences, add descriptions and metadata, and submit for review. Approved content goes live within 24-48 hours.'
    },
    {
      question: 'What file formats do you accept?',
      answer: 'We support most common immersive media formats including 360° videos (MP4, MOV), VR experiences (Unity WebGL, WebXR), AR content (USDZ, GLB), and spatial audio (Ambisonic, binaural).'
    },
    {
      question: 'How does revenue sharing work?',
      answer: 'Creators keep 80% of revenue from their content. We handle payment processing, distribution, and platform maintenance. Payouts are processed monthly via PayPal, Stripe, or bank transfer.'
    },
    {
      question: 'Can I use ImmersiveX for business/education?',
      answer: 'Absolutely! Our Enterprise plan includes white-label solutions, custom branding, analytics, team management, and dedicated support perfect for businesses and educational institutions.'
    },
    {
      question: 'Is there a free trial for Premium?',
      answer: 'Yes! We offer a 7-day free trial of Premium features. No credit card required. You can cancel anytime during the trial period without charges.'
    }
  ]

  return (
    <section id="contact" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-electric-purple/5 to-transparent" />
        {/* Animated Elements */}
        {[...Array(10)].map((_, i) => (
          <div
            key={i}
            className="absolute w-3 h-3 bg-cyber-mint/20 rounded-full animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 10}s`,
              animationDuration: `${8 + Math.random() * 8}s`
            }}
          />
        ))}
      </div>

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6"
            data-macaly="contact-title"
          >
            Get in{' '}
            <span className="bg-gradient-to-r from-electric-purple to-cyber-mint bg-clip-text text-transparent">
              Touch
            </span>
          </h2>
          <p 
            className="text-lg md:text-xl text-glass-white/70 max-w-3xl mx-auto leading-relaxed"
            data-macaly="contact-subtitle"
          >
            Have questions about our platform? Need technical support? Want to partner with us? 
            We're here to help you on your immersive journey.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Form */}
          <Card className="glass-dark border-electric-purple/30 hover:border-electric-purple/50 transition-all duration-500">
            <CardHeader>
              <CardTitle className="flex items-center text-white text-xl">
                <MessageCircle className="w-5 h-5 mr-2 text-cyber-mint" />
                Send us a Message
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Input
                      name="name"
                      placeholder="Your Name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="bg-glass-100 border-electric-purple/30 text-white placeholder:text-glass-white/60 focus:border-electric-purple"
                      data-macaly="contact-name-input"
                      required
                    />
                  </div>
                  <div>
                    <Input
                      name="email"
                      type="email"
                      placeholder="Your Email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="bg-glass-100 border-electric-purple/30 text-white placeholder:text-glass-white/60 focus:border-electric-purple"
                      data-macaly="contact-email-input"
                      required
                    />
                  </div>
                </div>
                
                <Input
                  name="subject"
                  placeholder="Subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  className="bg-glass-100 border-electric-purple/30 text-white placeholder:text-glass-white/60 focus:border-electric-purple"
                  data-macaly="contact-subject-input"
                  required
                />
                
                <Textarea
                  name="message"
                  placeholder="Your message..."
                  value={formData.message}
                  onChange={handleInputChange}
                  rows={6}
                  className="bg-glass-100 border-electric-purple/30 text-white placeholder:text-glass-white/60 focus:border-electric-purple resize-none"
                  data-macaly="contact-message-input"
                  required
                />
                
                <Button 
                  type="submit"
                  size="lg"
                  className="w-full bg-gradient-to-r from-electric-purple to-cyber-mint hover:from-electric-purple/80 hover:to-cyber-mint/80 text-white font-semibold py-3 rounded-lg transition-all duration-300 shadow-neon"
                  data-macaly="contact-submit-btn"
                >
                  <Send className="w-5 h-5 mr-2" />
                  Send Message
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* FAQ Section */}
          <Card className="glass-dark border-electric-purple/30">
            <CardHeader>
              <CardTitle className="flex items-center text-white text-xl">
                <HelpCircle className="w-5 h-5 mr-2 text-electric-purple" />
                Frequently Asked Questions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="space-y-4">
                {faqs.map((faq, index) => (
                  <AccordionItem 
                    key={index} 
                    value={`item-${index}`}
                    className="border-electric-purple/20 hover:border-electric-purple/40 transition-colors duration-300"
                    data-macaly={`faq-item-${index}`}
                  >
                    <AccordionTrigger className="text-white hover:text-cyber-mint transition-colors duration-300 text-left">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-glass-white/80 leading-relaxed">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </div>

        {/* Quick Contact Options */}
        <div className="mt-16 text-center">
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <Card className="glass-dark border-electric-purple/20 hover:border-electric-purple/40 transition-all duration-300 group">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 mx-auto mb-4 rounded-lg bg-gradient-to-r from-cyber-mint to-electric-purple flex items-center justify-center group-hover:animate-glow transition-all duration-300">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Live Chat</h3>
                <p className="text-glass-white/70 text-sm mb-4">
                  Get instant help from our support team
                </p>
                <Button 
                  variant="outline"
                  size="sm"
                  className="border-cyber-mint/50 text-cyber-mint hover:bg-cyber-mint/10 hover:border-cyber-mint"
                  data-macaly="live-chat-btn"
                >
                  Start Chat
                </Button>
              </CardContent>
            </Card>

            <Card className="glass-dark border-electric-purple/20 hover:border-electric-purple/40 transition-all duration-300 group">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 mx-auto mb-4 rounded-lg bg-gradient-to-r from-electric-purple to-neon-pink flex items-center justify-center group-hover:animate-glow transition-all duration-300">
                  <MessageCircle className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Email Support</h3>
                <p className="text-glass-white/70 text-sm mb-4">
                  Detailed help via email within 24h
                </p>
                <Button 
                  variant="outline"
                  size="sm"
                  className="border-electric-purple/50 text-electric-purple hover:bg-electric-purple/10 hover:border-electric-purple"
                  data-macaly="email-support-btn"
                >
                  Email Us
                </Button>
              </CardContent>
            </Card>

            <Card className="glass-dark border-electric-purple/20 hover:border-electric-purple/40 transition-all duration-300 group">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 mx-auto mb-4 rounded-lg bg-gradient-to-r from-neon-pink to-cyber-mint flex items-center justify-center group-hover:animate-glow transition-all duration-300">
                  <HelpCircle className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Help Center</h3>
                <p className="text-glass-white/70 text-sm mb-4">
                  Browse our comprehensive guides
                </p>
                <Button 
                  variant="outline"
                  size="sm"
                  className="border-neon-pink/50 text-neon-pink hover:bg-neon-pink/10 hover:border-neon-pink"
                  data-macaly="help-center-btn"
                >
                  Browse Docs
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}

export default ContactSection