'use client'

import { useEffect, useState } from 'react'

export default function ThemeSwitcher() {
  const [isDark, setIsDark] = useState(true)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    
    // Load theme preference
    const savedTheme = localStorage.getItem('immersiveX-theme')
    if (savedTheme) {
      const isDarkMode = savedTheme === 'dark'
      setIsDark(isDarkMode)
      document.documentElement.classList.toggle('dark', isDarkMode)
    } else {
      // Default to dark theme for immersive experience
      document.documentElement.classList.add('dark')
    }
  }, [])

  const toggleTheme = () => {
    console.log('Theme toggle clicked, current:', isDark)
    const newTheme = !isDark
    setIsDark(newTheme)
    
    // Update document class
    document.documentElement.classList.toggle('dark', newTheme)
    
    // Save preference
    localStorage.setItem('immersiveX-theme', newTheme ? 'dark' : 'light')
    
    console.log('Theme switched to:', newTheme ? 'dark' : 'light')
  }

  // Don't render until mounted to avoid hydration mismatch
  if (!mounted) {
    return null
  }

  return (
    <button
      onClick={toggleTheme}
      className="fixed bottom-6 left-6 w-14 h-14 rounded-full backdrop-blur-xl border border-white/20 hover:scale-110 transition-all duration-300 z-50 group flex items-center justify-center"
      style={{
        background: isDark 
          ? 'linear-gradient(135deg, rgba(30, 30, 60, 0.9), rgba(10, 10, 30, 0.8))'
          : 'linear-gradient(135deg, rgba(255, 255, 255, 0.9), rgba(240, 240, 255, 0.8))',
        boxShadow: isDark
          ? '0 8px 32px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
          : '0 8px 32px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.8)'
      }}
      title={`Switch to ${isDark ? 'light' : 'dark'} mode`}
      data-macaly="theme-switcher"
    >
      <div className="relative">
        <div className={`transition-all duration-500 ${isDark ? 'opacity-100 scale-100' : 'opacity-0 scale-75'} absolute inset-0 flex items-center justify-center`}>
          🌙
        </div>
        <div className={`transition-all duration-500 ${!isDark ? 'opacity-100 scale-100' : 'opacity-0 scale-75'} absolute inset-0 flex items-center justify-center`}>
          ☀️
        </div>
      </div>
      
      {/* Subtle glow effect */}
      <div className="absolute inset-0 rounded-full bg-gradient-to-br from-purple-400/20 to-cyan-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
    </button>
  )
}