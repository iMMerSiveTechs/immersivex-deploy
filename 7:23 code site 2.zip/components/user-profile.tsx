'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

interface UserProfile {
  name: string
  bio: string
  interests: string[]
  avatar: string
  location: string
  experienceLevel: string
  favoriteGenres: string[]
  devices: string[]
  createdAt: string
}

const defaultProfile: UserProfile = {
  name: '',
  bio: '',
  interests: [],
  avatar: '',
  location: '',
  experienceLevel: 'Beginner',
  favoriteGenres: [],
  devices: [],
  createdAt: new Date().toISOString()
}

const interestOptions = [
  'VR Gaming', 'AR Experiences', 'Virtual Concerts', 'Education', 'Social VR', 
  'Creative Tools', 'Fitness', 'Travel', 'Art & Design', 'Technology',
  'Music', 'Movies', 'Sports', 'Science', 'History', 'Languages'
]

const genreOptions = [
  'Action', 'Adventure', 'Puzzle', 'Simulation', 'Social', 'Educational',
  'Horror', 'Racing', 'Strategy', 'Music', 'Art', 'Documentary'
]

const deviceOptions = [
  'Meta Quest 2', 'Meta Quest 3', 'Meta Quest Pro', 'Apple Vision Pro',
  'HTC Vive', 'Valve Index', 'PICO 4', 'PlayStation VR2', 'Smartphone AR'
]

export default function UserProfile() {
  const [profile, setProfile] = useState<UserProfile>(defaultProfile)
  const [isEditing, setIsEditing] = useState(false)
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')

  useEffect(() => {
    const saved = localStorage.getItem('immersiveXProfile')
    if (saved) {
      try {
        const parsedProfile = JSON.parse(saved)
        setProfile({ ...defaultProfile, ...parsedProfile })
      } catch (error) {
        console.error('Error parsing saved profile:', error)
      }
    }
  }, [])

  const saveProfile = async () => {
    setLoading(true)
    try {
      const updatedProfile = {
        ...profile,
        updatedAt: new Date().toISOString()
      }
      localStorage.setItem('immersiveXProfile', JSON.stringify(updatedProfile))
      setProfile(updatedProfile)
      setMessage('✅ Profile saved successfully!')
      setIsEditing(false)
      
      // Clear message after 3 seconds
      setTimeout(() => setMessage(''), 3000)
    } catch (error) {
      setMessage('❌ Error saving profile')
      console.error('Save error:', error)
    } finally {
      setLoading(false)
    }
  }

  const toggleInterest = (interest: string) => {
    setProfile(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }))
  }

  const toggleGenre = (genre: string) => {
    setProfile(prev => ({
      ...prev,
      favoriteGenres: prev.favoriteGenres.includes(genre)
        ? prev.favoriteGenres.filter(g => g !== genre)
        : [...prev.favoriteGenres, genre]
    }))
  }

  const toggleDevice = (device: string) => {
    setProfile(prev => ({
      ...prev,
      devices: prev.devices.includes(device)
        ? prev.devices.filter(d => d !== device)
        : [...prev.devices, device]
    }))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-purple-900/20 text-white p-6">
      <div className="max-w-4xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent" data-macaly="profile-title">
            Your Immersive Profile
          </h1>
          <p className="text-white/70" data-macaly="profile-subtitle">
            Customize your experience and let Cerebra provide personalized recommendations
          </p>
        </div>

        {/* Profile Card */}
        <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-3xl p-8 shadow-2xl">
          
          {/* Avatar and Basic Info */}
          <div className="flex flex-col md:flex-row gap-8 mb-8">
            <div className="flex flex-col items-center">
              <div className="w-32 h-32 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-4xl mb-4">
                {profile.avatar || '🧑‍🚀'}
              </div>
              {isEditing && (
                <input
                  type="text"
                  placeholder="Avatar emoji"
                  value={profile.avatar}
                  onChange={(e) => setProfile(prev => ({ ...prev, avatar: e.target.value }))}
                  className="w-20 text-center p-2 bg-white/10 rounded-lg text-white placeholder-white/50 text-sm"
                />
              )}
            </div>
            
            <div className="flex-1 space-y-4">
              {/* Name */}
              <div>
                <label className="block text-sm font-medium text-white/80 mb-2">Display Name</label>
                {isEditing ? (
                  <input
                    type="text"
                    placeholder="Your name"
                    value={profile.name}
                    onChange={(e) => setProfile(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full p-3 bg-white/10 rounded-xl text-white placeholder-white/50 border border-white/20 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                  />
                ) : (
                  <p className="text-lg font-semibold">{profile.name || 'Anonymous Explorer'}</p>
                )}
              </div>

              {/* Bio */}
              <div>
                <label className="block text-sm font-medium text-white/80 mb-2">Bio</label>
                {isEditing ? (
                  <textarea
                    placeholder="Tell us about yourself..."
                    value={profile.bio}
                    onChange={(e) => setProfile(prev => ({ ...prev, bio: e.target.value }))}
                    rows={3}
                    className="w-full p-3 bg-white/10 rounded-xl text-white placeholder-white/50 border border-white/20 focus:outline-none focus:ring-2 focus:ring-purple-500/50 resize-none"
                  />
                ) : (
                  <p className="text-white/80">{profile.bio || 'Exploring the immersive web...'}</p>
                )}
              </div>

              {/* Location & Experience Level */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-white/80 mb-2">Location</label>
                  {isEditing ? (
                    <input
                      type="text"
                      placeholder="City, Country"
                      value={profile.location}
                      onChange={(e) => setProfile(prev => ({ ...prev, location: e.target.value }))}
                      className="w-full p-3 bg-white/10 rounded-xl text-white placeholder-white/50 border border-white/20 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                    />
                  ) : (
                    <p className="text-white/80">{profile.location || '🌍 Global'}</p>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-white/80 mb-2">Experience Level</label>
                  {isEditing ? (
                    <select
                      value={profile.experienceLevel}
                      onChange={(e) => setProfile(prev => ({ ...prev, experienceLevel: e.target.value }))}
                      className="w-full p-3 bg-white/10 rounded-xl text-white border border-white/20 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                    >
                      <option value="Beginner">🌱 Beginner</option>
                      <option value="Intermediate">🚀 Intermediate</option>
                      <option value="Advanced">⭐ Advanced</option>
                      <option value="Expert">👑 Expert</option>
                    </select>
                  ) : (
                    <Badge className="bg-purple-600/40 text-purple-200 border-purple-500/30">
                      {profile.experienceLevel}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Interests */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-3">🎯 Interests</h3>
            <div className="flex flex-wrap gap-2">
              {interestOptions.map(interest => (
                <button
                  key={interest}
                  onClick={() => isEditing && toggleInterest(interest)}
                  disabled={!isEditing}
                  className={`px-3 py-1 rounded-full text-sm transition-all ${
                    profile.interests.includes(interest)
                      ? 'bg-purple-600/60 text-white border border-purple-500/30'
                      : 'bg-white/10 text-white/70 border border-white/20 hover:bg-white/20'
                  } ${isEditing ? 'cursor-pointer' : 'cursor-default'}`}
                >
                  {interest}
                </button>
              ))}
            </div>
          </div>

          {/* Favorite Genres */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-3">🎮 Favorite Genres</h3>
            <div className="flex flex-wrap gap-2">
              {genreOptions.map(genre => (
                <button
                  key={genre}
                  onClick={() => isEditing && toggleGenre(genre)}
                  disabled={!isEditing}
                  className={`px-3 py-1 rounded-full text-sm transition-all ${
                    profile.favoriteGenres.includes(genre)
                      ? 'bg-pink-600/60 text-white border border-pink-500/30'
                      : 'bg-white/10 text-white/70 border border-white/20 hover:bg-white/20'
                  } ${isEditing ? 'cursor-pointer' : 'cursor-default'}`}
                >
                  {genre}
                </button>
              ))}
            </div>
          </div>

          {/* Devices */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-3">🥽 Your Devices</h3>
            <div className="flex flex-wrap gap-2">
              {deviceOptions.map(device => (
                <button
                  key={device}
                  onClick={() => isEditing && toggleDevice(device)}
                  disabled={!isEditing}
                  className={`px-3 py-1 rounded-full text-sm transition-all ${
                    profile.devices.includes(device)
                      ? 'bg-cyan-600/60 text-white border border-cyan-500/30'
                      : 'bg-white/10 text-white/70 border border-white/20 hover:bg-white/20'
                  } ${isEditing ? 'cursor-pointer' : 'cursor-default'}`}
                >
                  {device}
                </button>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 justify-end">
            {isEditing ? (
              <>
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsEditing(false)
                    // Reset to saved profile
                    const saved = localStorage.getItem('immersiveXProfile')
                    if (saved) {
                      setProfile(JSON.parse(saved))
                    }
                  }}
                  className="border-white/20 text-white/80 hover:bg-white/10"
                >
                  Cancel
                </Button>
                <Button
                  onClick={saveProfile}
                  disabled={loading}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
                >
                  {loading ? 'Saving...' : 'Save Profile'}
                </Button>
              </>
            ) : (
              <Button
                onClick={() => setIsEditing(true)}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
              >
                Edit Profile
              </Button>
            )}
          </div>

          {/* Success/Error Message */}
          {message && (
            <div className={`mt-4 p-3 rounded-xl text-center font-medium ${
              message.startsWith('✅') 
                ? 'bg-green-500/20 border border-green-500/30 text-green-300'
                : 'bg-red-500/20 border border-red-500/30 text-red-300'
            }`}>
              {message}
            </div>
          )}
        </div>

        {/* AI Recommendations Preview */}
        <div className="mt-8 bg-gradient-to-br from-blue-500/10 to-purple-500/10 backdrop-blur-md border border-white/10 rounded-2xl p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            🤖 Cerebra's Recommendations for You
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="bg-white/5 rounded-xl p-4">
              <div className="text-purple-400 mb-2">Based on your interests:</div>
              <div className="text-white/80">
                {profile.interests.slice(0, 2).map(interest => `${interest} experiences`).join(', ') || 'Complete your profile for personalized suggestions'}
              </div>
            </div>
            <div className="bg-white/5 rounded-xl p-4">
              <div className="text-pink-400 mb-2">Recommended genres:</div>
              <div className="text-white/80">
                {profile.favoriteGenres.length > 0 ? 'Similar to your favorites' : 'Tell us your favorite genres'}
              </div>
            </div>
            <div className="bg-white/5 rounded-xl p-4">
              <div className="text-cyan-400 mb-2">Device-optimized content:</div>
              <div className="text-white/80">
                {profile.devices.length > 0 ? `Optimized for ${profile.devices[0]}` : 'Add your devices for better recommendations'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}