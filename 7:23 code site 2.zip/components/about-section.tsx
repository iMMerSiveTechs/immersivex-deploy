"use client"

import { Card, CardContent } from '@/components/ui/card'
import { Smartphone, Monitor, Headphones, Zap, Users, Globe } from 'lucide-react'

const AboutSection = () => {
  console.log("AboutSection component rendered")

  const technologies = [
    {
      name: 'VR/XR',
      description: 'Virtual and Extended Reality experiences that transport you to new dimensions',
      icon: Headphones,
      color: 'from-electric-purple to-neon-pink'
    },
    {
      name: 'AR/MR',
      description: 'Augmented and Mixed Reality that blends digital content with your world',
      icon: Smartphone,
      color: 'from-cyber-mint to-electric-purple'
    },
    {
      name: 'Cross-Platform',
      description: 'Seamless experiences across all your devices and platforms',
      icon: Monitor,
      color: 'from-neon-pink to-cyber-mint'
    }
  ]

  const devices = [
    'Meta Quest 2/3/Pro',
    'Apple Vision Pro',
    'HTC Vive',
    'iPhone/iPad AR',
    'Android AR',
    'Desktop Web',
    'Smart TVs',
    'Gaming Consoles'
  ]

  return (
    <section id="about" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Enhanced Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-electric-purple/5 to-transparent animate-gradient-shift" />
        
        {/* Floating Orbs */}
        <div className="absolute top-20 left-10 w-64 h-64 bg-electric-purple/10 rounded-full blur-3xl animate-parallax-float" />
        <div className="absolute bottom-20 right-10 w-48 h-48 bg-cyber-mint/10 rounded-full blur-2xl animate-parallax-float" style={{animationDelay: '3s'}} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-neon-pink/5 rounded-full blur-3xl animate-pulse-slow" />
        
        {/* Enhanced Animated Grid */}
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `
              linear-gradient(rgba(16, 255, 240, 0.4) 1px, transparent 1px),
              linear-gradient(90deg, rgba(99, 102, 241, 0.3) 1px, transparent 1px)
            `,
            backgroundSize: '80px 80px',
            animation: 'ken-burns 30s linear infinite'
          }}
        />
        
        {/* Floating Tech Particles */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(8)].map((_, i) => (
            <div
              key={i}
              className={`absolute rounded-full animate-float ${
                i % 3 === 0 ? 'w-2 h-2 bg-cyber-mint/30' : 
                i % 3 === 1 ? 'w-1 h-1 bg-electric-purple/40' : 
                'w-3 h-3 bg-neon-pink/20'
              }`}
              style={{
                left: `${15 + Math.random() * 70}%`,
                top: `${15 + Math.random() * 70}%`,
                animationDelay: `${Math.random() * 8}s`,
                animationDuration: `${10 + Math.random() * 6}s`
              }}
            />
          ))}
        </div>
      </div>

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6"
            data-macaly="about-title"
          >
            The Future of{' '}
            <span className="bg-gradient-to-r from-electric-purple to-cyber-mint bg-clip-text text-transparent">
              Immersive Entertainment
            </span>
          </h2>
          <p 
            className="text-lg md:text-xl text-glass-white/70 max-w-4xl mx-auto leading-relaxed"
            data-macaly="about-subtitle"
          >
            ImmersiveX is pioneering the next generation of digital experiences. We're building a platform where 
            cutting-edge XR technologies meet creative storytelling, accessible on any device, anywhere in the world.
          </p>
        </div>

        {/* Technology Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-20">
          {technologies.map((tech, index) => (
            <Card key={tech.name} className="glass-dark border-electric-purple/20 hover:border-electric-purple/40 transition-all duration-500 group">
              <CardContent className="p-8 text-center">
                <div className={`w-16 h-16 mx-auto mb-6 rounded-xl bg-gradient-to-r ${tech.color} flex items-center justify-center group-hover:animate-glow transition-all duration-300`}>
                  <tech.icon className="w-8 h-8 text-white" />
                </div>
                <h3 
                  className="text-xl md:text-2xl font-bold text-white mb-4"
                  data-macaly={`tech-${tech.name.toLowerCase().replace('/', '-')}-title`}
                >
                  {tech.name}
                </h3>
                <p 
                  className="text-glass-white/80 leading-relaxed"
                  data-macaly={`tech-${tech.name.toLowerCase().replace('/', '-')}-description`}
                >
                  {tech.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Platform Compatibility */}
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div>
            <h3 
              className="text-2xl md:text-3xl font-bold text-white mb-6"
              data-macaly="compatibility-title"
            >
              Universal Compatibility
            </h3>
            <p 
              className="text-lg text-glass-white/80 mb-8 leading-relaxed"
              data-macaly="compatibility-description"
            >
              Experience immersive content on any device you own. Our platform adapts to your hardware, 
              delivering the best possible experience whether you're using the latest VR headset or your smartphone.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-center text-glass-white/70">
                <Zap className="w-5 h-5 text-cyber-mint mr-3" />
                <span>Optimized for each platform's capabilities</span>
              </div>
              <div className="flex items-center text-glass-white/70">
                <Users className="w-5 h-5 text-electric-purple mr-3" />
                <span>Cross-device social features</span>
              </div>
              <div className="flex items-center text-glass-white/70">
                <Globe className="w-5 h-5 text-neon-pink mr-3" />
                <span>Global accessibility and localization</span>
              </div>
            </div>
          </div>

          {/* Right Content - Device Grid */}
          <div className="grid grid-cols-2 gap-4">
            {devices.map((device, index) => (
              <div
                key={device}
                className="glass-dark rounded-lg p-4 text-center border border-electric-purple/20 hover:border-electric-purple/40 transition-all duration-300 group"
                data-macaly={`device-${device.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
              >
                <div className="w-8 h-8 mx-auto mb-2 bg-gradient-cyber rounded-lg flex items-center justify-center group-hover:animate-pulse-slow">
                  {index % 3 === 0 ? (
                    <Headphones className="w-4 h-4 text-white" />
                  ) : index % 3 === 1 ? (
                    <Smartphone className="w-4 h-4 text-white" />
                  ) : (
                    <Monitor className="w-4 h-4 text-white" />
                  )}
                </div>
                <p className="text-sm text-glass-white/80 font-medium">{device}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Stats Section */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { number: '10M+', label: 'Experiences Delivered' },
            { number: '150+', label: 'Partner Creators' },
            { number: '50+', label: 'Supported Devices' },
            { number: '25+', label: 'Countries Served' }
          ].map((stat, index) => (
            <div key={stat.label} className="text-center group">
              <div 
                className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-electric-purple to-cyber-mint bg-clip-text text-transparent mb-2 group-hover:animate-glow"
                data-macaly={`stat-${stat.label.toLowerCase().replace(/[^a-z0-9]/g, '-')}-number`}
              >
                {stat.number}
              </div>
              <div 
                className="text-glass-white/60 text-sm md:text-base"
                data-macaly={`stat-${stat.label.toLowerCase().replace(/[^a-z0-9]/g, '-')}-label`}
              >
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default AboutSection