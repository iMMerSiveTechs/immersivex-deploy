"use client"

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { X, Mail } from 'lucide-react'

const NewsletterCTABar = () => {
  const [email, setEmail] = useState('')
  const [isVisible, setIsVisible] = useState(true)
  const [isSubscribed, setIsSubscribed] = useState(false)

  console.log("NewsletterCTABar rendered, isVisible:", isVisible, "email:", email)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Newsletter subscription submitted with email:", email)
    setIsSubscribed(true)
    setTimeout(() => {
      setIsVisible(false)
    }, 2000)
  }

  const handleClose = () => {
    console.log("Newsletter bar closed")
    setIsVisible(false)
  }

  if (!isVisible) return null

  return (
    <div className="fixed bottom-6 left-6 right-6 z-40 mx-auto max-w-4xl">
      <div className="glass-dark backdrop-blur-xl border border-electric-purple/30 rounded-xl p-6 shadow-neon animate-slide-up relative overflow-hidden">
        {/* Background gradient animation */}
        <div className="absolute inset-0 bg-gradient-to-r from-electric-purple/10 via-cyber-mint/10 to-neon-pink/10 animate-gradient-shift opacity-50" />
        
        {/* Content */}
        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center space-x-4 flex-1">
            <div className="relative">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-electric-purple to-cyber-mint flex items-center justify-center animate-glow">
                <Mail className="w-6 h-6 text-white" />
              </div>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-neon-pink rounded-full animate-bounce-subtle border-2 border-space-blue" />
            </div>
            
            <div className="flex-1">
              <p 
                className="text-white font-semibold text-sm md:text-base mb-1"
                data-macaly="newsletter-cta-text"
              >
                📬 Get early access to drops, creator tools, and immersive shows
              </p>
              <p className="text-glass-white/60 text-xs">
                Join 50,000+ creators and enthusiasts
              </p>
              
              {!isSubscribed ? (
                <form onSubmit={handleSubmit} className="flex gap-3 mt-3">
                  <div className="relative flex-1 max-w-xs">
                    <Input
                      type="email"
                      placeholder="Enter your email"
                      value={email}
                      onChange={(e) => {
                        console.log("Email input changed:", e.target.value)
                        setEmail(e.target.value)
                      }}
                      className="bg-glass-100 border-electric-purple/30 text-white placeholder:text-glass-white/60 focus:border-electric-purple text-sm h-10 pr-10 rounded-lg"
                      data-macaly="newsletter-cta-email-input"
                      required
                    />
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 w-2 h-2 bg-cyber-mint rounded-full animate-pulse-slow" />
                  </div>
                  <Button 
                    type="submit"
                    size="sm"
                    className="bg-gradient-to-r from-electric-purple to-cyber-mint hover:from-electric-purple/80 hover:to-cyber-mint/80 text-white font-semibold px-6 h-10 rounded-lg transition-all duration-300 shadow-neon whitespace-nowrap animate-shimmer relative overflow-hidden"
                    data-macaly="newsletter-cta-join-btn"
                  >
                    <span className="relative z-10">Join Now</span>
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                  </Button>
                </form>
              ) : (
                <div className="mt-3 p-3 glass-dark rounded-lg border border-cyber-mint/30">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-cyber-mint rounded-full mr-2 animate-pulse" />
                    <p className="text-cyber-mint text-sm font-medium">
                      ✨ Thanks! Check your inbox for exclusive updates.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>

          <Button
            variant="ghost"
            size="sm"
            className="text-glass-white/60 hover:text-white hover:bg-glass-100/50 p-2 ml-4 rounded-lg transition-all duration-300"
            onClick={handleClose}
            data-macaly="newsletter-cta-close-btn"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}

export default NewsletterCTABar