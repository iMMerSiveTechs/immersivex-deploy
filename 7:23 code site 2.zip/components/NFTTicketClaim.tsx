'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Ticket, Mail, Sparkles, Download, Share2 } from 'lucide-react'

export default function NFTTicketClaim() {
  const [form, setForm] = useState({
    email: '',
    eventId: '',
    walletAddress: ''
  })
  const [loading, setLoading] = useState(false)
  const [confirmed, setConfirmed] = useState(false)
  const [ticketData, setTicketData] = useState<any>(null)

  console.log('NFTTicketClaim component rendered, confirmed:', confirmed)

  const claim = async () => {
    if (!form.email) {
      alert('Please enter your email address')
      return
    }

    console.log('Claiming NFT ticket:', form)
    setLoading(true)
    
    try {
      const response = await fetch('/api/event/claim', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(form),
      })
      
      const data = await response.json()
      console.log('Claim response:', data)
      
      if (data.success) {
        setTicketData(data.ticket)
        setConfirmed(true)
      } else {
        alert(data.message || 'Failed to claim ticket')
      }
    } catch (error) {
      console.error('Claim error:', error)
      alert('Failed to claim NFT ticket')
    } finally {
      setLoading(false)
    }
  }

  const downloadTicket = () => {
    if (!ticketData) return
    
    const ticketInfo = `
ImmersiveX Event Ticket (NFT)
============================
Event: ${ticketData.eventName || 'Immersive Experience'}
Date: ${ticketData.date || 'TBD'}
Ticket ID: ${ticketData.tokenId}
Owner: ${form.email}
Blockchain: Polygon
Contract: ${ticketData.contractAddress || '0x...'}

This NFT ticket grants you access to the event.
Keep this safe - it's your proof of ownership!
    `.trim()
    
    const blob = new Blob([ticketInfo], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `immersivex-ticket-${ticketData.tokenId}.txt`
    a.click()
    URL.revokeObjectURL(url)
  }

  if (confirmed) {
    return (
      <div className="max-w-md mx-auto text-white p-6">
        <Card className="glass-dark border-green-500/50 shadow-neon">
          <CardContent className="p-6 text-center">
            <div className="mb-6">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-green-400 to-cyan-400 rounded-full flex items-center justify-center animate-pulse-slow">
                <Ticket className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-green-400 mb-2" data-macaly="ticket-claimed-title">
                🎟 NFT Ticket Claimed!
              </h2>
              <p className="text-glass-white/80 text-sm" data-macaly="ticket-claimed-description">
                Your event NFT has been minted and sent to your email
              </p>
            </div>

            {ticketData && (
              <div className="space-y-4">
                <div className="glass-dark border border-electric-purple/30 rounded-lg p-4">
                  <div className="text-sm text-glass-white/70 mb-2">Ticket Details</div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Token ID:</span>
                      <span className="text-cyber-mint font-mono">#{ticketData.tokenId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Network:</span>
                      <span className="text-electric-purple">Polygon</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Status:</span>
                      <span className="text-green-400">✓ Verified</span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={downloadTicket}
                    className="flex-1 bg-gradient-to-r from-electric-purple to-cyber-mint text-white"
                    data-macaly="download-ticket-btn"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1 border-electric-purple/50 text-electric-purple hover:bg-electric-purple/10"
                    data-macaly="share-ticket-btn"
                  >
                    <Share2 className="w-4 h-4 mr-2" />
                    Share
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="max-w-md mx-auto text-white p-6">
      <Card className="glass-dark border-electric-purple/30">
        <CardContent className="p-6">
          <div className="text-center mb-6">
            <div className="flex items-center justify-center mb-4">
              <Sparkles className="w-8 h-8 text-cyber-mint mr-2" />
              <h1 className="text-2xl font-bold hologram-text" data-macaly="ticket-claim-title">
                Claim Event NFT
              </h1>
            </div>
            <p className="text-glass-white/70 text-sm" data-macaly="ticket-claim-description">
              Get your proof-of-attendance NFT ticket for the event
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-electric-purple mb-2">
                <Mail className="w-4 h-4 inline mr-1" />
                Email Address *
              </label>
              <Input
                type="email"
                placeholder="your@email.com"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="bg-black/30 border-electric-purple/30 text-white"
                data-macaly="claim-email-input"
              />
              <p className="text-xs text-glass-white/50 mt-1">
                We'll send your NFT ticket details here
              </p>
            </div>

            <div>
              <label className="block text-sm font-semibold text-electric-purple mb-2">
                Event ID (Optional)
              </label>
              <Input
                placeholder="Leave blank for general admission"
                value={form.eventId}
                onChange={(e) => setForm({ ...form, eventId: e.target.value })}
                className="bg-black/30 border-electric-purple/30 text-white"
                data-macaly="claim-event-id-input"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-electric-purple mb-2">
                Wallet Address (Optional)
              </label>
              <Input
                placeholder="0x... for direct NFT transfer"
                value={form.walletAddress}
                onChange={(e) => setForm({ ...form, walletAddress: e.target.value })}
                className="bg-black/30 border-electric-purple/30 text-white font-mono text-xs"
                data-macaly="claim-wallet-input"
              />
            </div>

            <Button
              onClick={claim}
              disabled={loading}
              className="w-full bg-gradient-to-r from-electric-purple to-cyber-mint text-white font-semibold py-3 shadow-neon hover:shadow-neon-strong transition-all duration-300"
              data-macaly="claim-ticket-btn"
            >
              <Ticket className="w-5 h-5 mr-2" />
              {loading ? 'Minting NFT Ticket...' : 'Claim NFT Ticket'}
            </Button>

            <div className="text-center text-xs text-glass-white/50">
              Free to claim • Gas fees covered by ImmersiveX
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}