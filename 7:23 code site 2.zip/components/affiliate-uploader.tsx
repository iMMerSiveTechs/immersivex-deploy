'use client'

import { useState } from 'react'

type GearItem = {
  fields: {
    Name: string
    LINK: string
    CATAGORY: string
    IMAGE?: { url: string }[]
  }
}

export default function AffiliateLinkUploader() {
  const [form, setForm] = useState({
    name: '',
    url: '',
    category: '',
    image: ''
  })
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')

  async function handleSubmit(e: any) {
    e.preventDefault()
    setLoading(true)
    setMessage('')
    console.log('Submitting affiliate link:', form)
    
    try {
      const res = await fetch('/api/affiliate/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(form)
      })
      
      const data = await res.json()
      console.log('Submit response:', data)
      
      if (data.success) {
        setMessage('✅ Link submitted successfully!')
        setForm({ name: '', url: '', category: '', image: '' })
      } else {
        throw new Error(data.message || 'Submission failed')
      }
    } catch (err: any) {
      console.error('Submit error:', err)
      setMessage('❌ ' + err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-purple-900/20 text-white">
      {/* Glass Back Button */}
      <div className="p-6">
        <button 
          onClick={() => window.history.back()}
          className="mb-6 px-4 py-2 bg-black/40 backdrop-blur-md border border-white/10 rounded-xl text-white/80 hover:text-white hover:bg-black/60 transition-all duration-300"
          data-macaly="back-button"
        >
          ← Back to ImmersiveX
        </button>
        
        <div className="max-w-2xl mx-auto">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent" data-macaly="gear-vault-title">
            🧰 Gear Vault - Add Product
          </h1>
          <p className="text-white/70 mb-8" data-macaly="gear-vault-subtitle">
            Share amazing XR gear, accessories, and immersive tech with the community
          </p>

          {/* Affiliate Link Upload Form */}
          <form onSubmit={handleSubmit} className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl p-8 shadow-2xl">
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-white/80 mb-2">Product Name</label>
                <input
                  type="text"
                  placeholder="e.g., Meta Quest 3 Elite Strap"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full p-4 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-transparent transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-white/80 mb-2">Product URL</label>
                <input
                  type="url"
                  placeholder="https://example.com/product"
                  value={form.url}
                  onChange={(e) => setForm({ ...form, url: e.target.value })}
                  className="w-full p-4 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-transparent transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-white/80 mb-2">Category</label>
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="w-full p-4 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-transparent transition-all"
                  required
                >
                  <option value="">Select category...</option>
                  <option value="VR Headsets">VR Headsets</option>
                  <option value="AR Glasses">AR Glasses</option>
                  <option value="Controllers">Controllers</option>
                  <option value="Accessories">Accessories</option>
                  <option value="Audio">Audio</option>
                  <option value="Haptics">Haptics</option>
                  <option value="Computing">Computing</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-white/80 mb-2">Image URL (Optional)</label>
                <input
                  type="url"
                  placeholder="https://example.com/image.jpg"
                  value={form.image}
                  onChange={(e) => setForm({ ...form, image: e.target.value })}
                  className="w-full p-4 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-transparent transition-all"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full p-4 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold rounded-xl transition-all duration-300 transform hover:scale-[1.02] disabled:opacity-50 disabled:hover:scale-100 shadow-lg"
              >
                {loading ? (
                  <span className="flex items-center justify-center">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                    Submitting...
                  </span>
                ) : (
                  'Submit Product'
                )}
              </button>

              {message && (
                <div className={`p-4 rounded-xl text-center font-medium ${
                  message.startsWith('✅') 
                    ? 'bg-green-500/20 border border-green-500/30 text-green-300'
                    : 'bg-red-500/20 border border-red-500/30 text-red-300'
                }`}>
                  {message}
                </div>
              )}
            </div>
          </form>

          {/* Info Card */}
          <div className="mt-8 bg-gradient-to-br from-blue-500/10 to-purple-500/10 backdrop-blur-md border border-white/10 rounded-2xl p-6">
            <h3 className="text-lg font-semibold mb-2 text-blue-300">💡 Why Share Gear?</h3>
            <ul className="text-white/70 space-y-1 text-sm">
              <li>• Help others discover amazing XR products</li>
              <li>• Earn affiliate commissions on sales</li>
              <li>• Build your reputation in the community</li>
              <li>• Get featured on our homepage</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}