"use client"

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Check, Zap, Star, Crown } from 'lucide-react'

const PricingSection = () => {
  console.log("PricingSection component rendered")

  const plans = [
    {
      name: 'Free Tier',
      price: '$0',
      period: 'forever',
      description: 'Perfect for casual exploration',
      icon: Zap,
      gradient: 'from-gray-500 to-gray-600',
      popular: false,
      features: [
        'Ad-supported access',
        'Limited library',
        'Preview-only content'
      ]
    },
    {
      name: 'Premium',
      price: '$9.99',
      period: 'per month',
      description: 'For immersive enthusiasts',
      icon: Star,
      gradient: 'from-electric-purple to-cyber-mint',
      popular: true,
      features: [
        'Full content library',
        'Ads skippable after 20 sec',
        'Weekly immersive drops'
      ]
    },
    {
      name: 'Max Access',
      price: '$49.99',
      period: 'per month',
      description: 'Ultimate immersive experience',
      icon: Crown,
      gradient: 'from-neon-pink to-electric-purple',
      popular: false,
      features: [
        'Ad-free everything',
        'VIP shows & backstage content',
        'AI tools + Creator perks'
      ]
    },
    {
      name: 'Enterprise Studio',
      price: '$199.99',
      period: 'per month',
      description: 'For organizations and teams',
      icon: Crown,
      gradient: 'from-purple-600 to-pink-600',
      popular: false,
      features: [
        'Up to 5 seats',
        'Custom event spaces',
        'White-glove onboarding'
      ]
    }
  ]

  return (
    <section id="pricing" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-space-blue/30 to-transparent" />
        {/* Radial Gradient */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-electric-purple/20 rounded-full blur-3xl animate-pulse-slow" />
      </div>

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6"
            data-macaly="pricing-title"
          >
            Choose Your{' '}
            <span className="bg-gradient-to-r from-electric-purple to-cyber-mint bg-clip-text text-transparent">
              Adventure
            </span>
          </h2>
          <p 
            className="text-lg md:text-xl text-glass-white/70 max-w-3xl mx-auto leading-relaxed"
            data-macaly="pricing-subtitle"
          >
            From casual exploration to enterprise solutions, find the perfect plan for your immersive journey
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <Card 
              key={plan.name}
              className={`relative glass-dark transition-all duration-500 group ${
                plan.popular 
                  ? 'border-electric-purple/50 hover:border-electric-purple shadow-neon scale-105' 
                  : 'border-electric-purple/20 hover:border-electric-purple/40'
              }`}
            >
              {/* Popular Badge */}
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-to-r from-electric-purple to-cyber-mint text-white text-sm font-semibold px-4 py-2 rounded-full shadow-neon">
                    Most Popular
                  </div>
                </div>
              )}

              <CardHeader className="text-center pb-4">
                <div className={`w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-r ${plan.gradient} flex items-center justify-center group-hover:animate-glow transition-all duration-300`}>
                  <plan.icon className="w-8 h-8 text-white" />
                </div>
                
                <h3 
                  className="text-2xl font-bold text-white mb-2"
                  data-macaly={`plan-${plan.name.toLowerCase()}-title`}
                >
                  {plan.name}
                </h3>
                
                <div className="mb-4">
                  <span 
                    className="text-3xl md:text-4xl font-bold text-white"
                    data-macaly={`plan-${plan.name.toLowerCase()}-price`}
                  >
                    {plan.price}
                  </span>
                  <span className="text-glass-white/60 text-lg ml-1">
                    /{plan.period}
                  </span>
                </div>
                
                <p 
                  className="text-glass-white/70"
                  data-macaly={`plan-${plan.name.toLowerCase()}-description`}
                >
                  {plan.description}
                </p>
              </CardHeader>

              <CardContent className="pt-0">
                {/* Features List */}
                <div className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-start space-x-3">
                      <Check className="w-5 h-5 text-cyber-mint mt-0.5 flex-shrink-0" />
                      <span 
                        className="text-glass-white/80 text-sm leading-relaxed"
                        data-macaly={`plan-${plan.name.toLowerCase()}-feature-${featureIndex}`}
                      >
                        {feature}
                      </span>
                    </div>
                  ))}
                </div>

                {/* CTA Button */}
                <Button 
                  size="lg"
                  className={`w-full font-semibold py-3 rounded-full transition-all duration-300 hover:scale-105 ${
                    plan.popular
                      ? 'bg-gradient-to-r from-electric-purple to-cyber-mint hover:from-electric-purple/80 hover:to-cyber-mint/80 text-white shadow-lg hover:shadow-xl'
                      : plan.name === 'Enterprise'
                      ? 'bg-gradient-to-r from-neon-pink to-electric-purple hover:from-neon-pink/80 hover:to-electric-purple/80 text-white shadow-lg hover:shadow-xl'
                      : 'border-2 border-electric-purple/50 text-electric-purple hover:bg-electric-purple/10 hover:border-electric-purple'
                  }`}
                  variant={plan.popular || plan.name === 'Enterprise' ? 'default' : 'outline'}
                  data-macaly={`plan-${plan.name.toLowerCase()}-cta-btn`}
                >
                  {plan.name === 'Enterprise' ? 'Contact Sales' : 
                   plan.name === 'Free' ? 'Get Started Free' : 
                   'Start Premium'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Info */}
        <div className="text-center mt-16">
          <p className="text-glass-white/60 mb-6">
            All plans include access to our growing library of immersive content
          </p>
          
          <div className="flex flex-wrap justify-center items-center gap-8 text-sm text-glass-white/60">
            <div className="flex items-center">
              <Check className="w-4 h-4 text-cyber-mint mr-2" />
              <span>Cancel anytime</span>
            </div>
            <div className="flex items-center">
              <Check className="w-4 h-4 text-electric-purple mr-2" />
              <span>30-day money back</span>
            </div>
            <div className="flex items-center">
              <Check className="w-4 h-4 text-neon-pink mr-2" />
              <span>24/7 support</span>
            </div>
          </div>
        </div>

        {/* Enterprise Contact */}
        <div className="mt-16 text-center">
          <Card className="glass-dark border-electric-purple/20 max-w-2xl mx-auto">
            <CardContent className="p-8">
              <h3 
                className="text-xl font-bold text-white mb-4"
                data-macaly="enterprise-contact-title"
              >
                Need a Custom Solution?
              </h3>
              <p 
                className="text-glass-white/80 mb-6"
                data-macaly="enterprise-contact-description"
              >
                Our enterprise team can create a tailored solution for your organization's unique needs.
              </p>
              <Button 
                variant="outline"
                className="border-electric-purple/50 text-electric-purple hover:bg-electric-purple/10 hover:border-electric-purple font-semibold rounded-full px-8 py-3 hover:scale-105 transition-all duration-300"
                data-macaly="enterprise-contact-btn"
              >
                Schedule a Demo
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}

export default PricingSection