"use client"

import { useState, useRef } from "react"
import { useChat } from 'ai/react'
import Draggable from 'react-draggable'

export function CerebraOrb() {
  const [open, setOpen] = useState(false)
  const dragRef = useRef<HTMLDivElement>(null)

  const {
    messages,
    input,
    handleInputChange,
    handleSubmit,
    isLoading,
    error
  } = useChat({
    api: '/api/chat',
    onError: (error) => {
      console.error('Cerebra AI error:', error)
    },
    onResponse: (response) => {
      console.log('Cerebra AI response started:', response.status)
    },
    onFinish: (message) => {
      console.log('Cerebra AI response completed:', message.content)
    }
  })

  console.log('CerebraOrb rendered, open:', open, 'messages:', messages.length)

  return (
    <>
      {/* 🧠 Draggable Obsidian Glass Orb */}
      <Draggable nodeRef={dragRef} bounds="parent">
        <div
          ref={dragRef}
          className="fixed top-20 left-20 w-16 h-16 rounded-full cursor-move z-50 group"
          style={{
            background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.6), rgba(59, 130, 246, 0.5), rgba(16, 185, 129, 0.4))',
            backdropFilter: 'blur(20px)',
            boxShadow: `
              0 0 40px rgba(139, 92, 246, 0.4),
              0 8px 32px rgba(0, 0, 0, 0.3),
              inset 0 1px 0 rgba(255, 255, 255, 0.2),
              inset 0 -1px 0 rgba(0, 0, 0, 0.1)
            `,
            border: '1px solid rgba(255, 255, 255, 0.1)'
          }}
          onClick={() => setOpen(!open)}
          data-macaly="cerebra-orb"
        >
          <div className="w-full h-full flex items-center justify-center text-2xl relative overflow-hidden rounded-full">
            <div className="relative z-10 transition-transform group-hover:scale-110">
              🧠
            </div>
            
            {/* Animated Background Rings */}
            <div className="absolute inset-0 rounded-full">
              <div className="absolute inset-2 rounded-full border border-white/20 animate-spin" style={{ animationDuration: '8s' }}></div>
              <div className="absolute inset-4 rounded-full border border-purple-400/30 animate-spin" style={{ animationDuration: '12s', animationDirection: 'reverse' }}></div>
            </div>
            
            {/* Loading Indicator */}
            {isLoading && (
              <div className="absolute -inset-1 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin"></div>
            )}
            
            {/* Hover Glow Effect */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-purple-400/20 to-cyan-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </div>
        </div>
      </Draggable>

      {/* 💬 Enhanced Obsidian Glass Assistant Panel */}
      {open && (
        <div 
          className="fixed top-24 left-24 w-[450px] max-w-[95vw] text-white p-6 z-40 animate-fadeIn"
          style={{
            background: `
              linear-gradient(135deg, 
                rgba(0, 0, 0, 0.85) 0%, 
                rgba(30, 30, 60, 0.9) 25%,
                rgba(20, 20, 40, 0.9) 50%,
                rgba(10, 10, 30, 0.9) 75%,
                rgba(0, 0, 0, 0.85) 100%
              )
            `,
            backdropFilter: 'blur(25px) saturate(180%)',
            boxShadow: `
              0 25px 50px -12px rgba(0, 0, 0, 0.8),
              0 0 0 1px rgba(255, 255, 255, 0.05),
              inset 0 1px 0 rgba(255, 255, 255, 0.1),
              inset 0 -1px 0 rgba(0, 0, 0, 0.2)
            `,
            borderRadius: '24px',
            border: '1px solid rgba(255, 255, 255, 0.08)'
          }}
        >
          
          {/* Enhanced Header with Neural Network Aesthetic */}
          <div className="flex justify-between items-center mb-6 pb-4 border-b border-white/10">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <div 
                  className="w-10 h-10 rounded-full flex items-center justify-center text-lg"
                  style={{
                    background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.8), rgba(59, 130, 246, 0.6))',
                    boxShadow: '0 0 20px rgba(139, 92, 246, 0.3)'
                  }}
                >
                  🧠
                </div>
                <div className="absolute -inset-1 rounded-full border border-purple-400/30 animate-pulse"></div>
              </div>
              <div>
                <h3 className="text-xl font-bold text-transparent bg-gradient-to-r from-purple-300 via-pink-300 to-cyan-300 bg-clip-text">
                  Cerebra Assistant
                </h3>
                <div className="flex items-center space-x-2 text-xs">
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div>
                  <span className="text-green-300">GPT-4 Connected</span>
                  <span className="text-white/40">•</span>
                  <span className="text-cyan-300">ImmersiveX Context</span>
                </div>
              </div>
            </div>
            <button 
              onClick={() => setOpen(false)} 
              className="text-white/50 hover:text-white transition-all p-2 hover:bg-white/10 rounded-full group"
            >
              <div className="transform group-hover:rotate-90 transition-transform">✕</div>
            </button>
          </div>

          {/* Enhanced Chat Messages with Glass Morphism */}
          <div className="max-h-80 overflow-y-auto mb-5 space-y-4 scrollbar-thin scrollbar-thumb-white/20 scrollbar-track-transparent pr-2">
            {messages.length === 0 && (
              <div className="text-center py-8 px-4 rounded-2xl"
                   style={{
                     background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(59, 130, 246, 0.05))',
                     border: '1px solid rgba(255, 255, 255, 0.05)'
                   }}>
                <div className="text-3xl mb-3 animate-bounce">👋</div>
                <p className="text-white/90 font-semibold text-lg mb-2">Welcome to Cerebra</p>
                <p className="text-white/60 text-sm mb-4">Your advanced AI assistant for the immersive web</p>
                <div className="flex flex-wrap gap-2 justify-center">
                  <span className="px-3 py-1 bg-white/10 rounded-full text-xs border border-white/10">🎮 Discover VR experiences</span>
                  <span className="px-3 py-1 bg-white/10 rounded-full text-xs border border-white/10">🎵 Find virtual concerts</span>
                  <span className="px-3 py-1 bg-white/10 rounded-full text-xs border border-white/10">🛒 Get gear recommendations</span>
                </div>
              </div>
            )}
            
            {messages.map((message, index) => (
              <div key={index} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div 
                  className={`max-w-[85%] p-4 rounded-2xl backdrop-blur-sm ${
                    message.role === 'user' 
                      ? 'text-white' 
                      : 'text-white/95'
                  } shadow-lg relative overflow-hidden`}
                  style={{
                    background: message.role === 'user'
                      ? 'linear-gradient(135deg, rgba(139, 92, 246, 0.7), rgba(236, 72, 153, 0.6))'
                      : 'linear-gradient(135deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.05))',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    boxShadow: message.role === 'user' 
                      ? '0 8px 32px rgba(139, 92, 246, 0.3)' 
                      : '0 8px 32px rgba(0, 0, 0, 0.2)'
                  }}
                >
                  <div className="relative z-10">
                    <div className="text-xs font-medium mb-2 opacity-80">
                      {message.role === 'user' ? '🧑‍💻 You' : '🧠 Cerebra'}
                    </div>
                    <div className="whitespace-pre-wrap leading-relaxed text-sm">
                      {message.content}
                    </div>
                  </div>
                </div>
              </div>
            ))}
            
            {isLoading && (
              <div className="flex justify-start">
                <div 
                  className="p-4 rounded-2xl backdrop-blur-sm border border-white/10 shadow-lg"
                  style={{
                    background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.05))'
                  }}
                >
                  <div className="flex items-center space-x-3">
                    <div className="flex space-x-1">
                      <div className="w-3 h-3 bg-purple-400 rounded-full animate-bounce"></div>
                      <div className="w-3 h-3 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0.15s' }}></div>
                      <div className="w-3 h-3 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0.3s' }}></div>
                    </div>
                    <span className="text-white/60 text-sm">Cerebra is processing...</span>
                  </div>
                </div>
              </div>
            )}
            
            {error && (
              <div className="flex justify-start">
                <div 
                  className="p-4 rounded-2xl backdrop-blur-sm border border-red-500/30 shadow-lg"
                  style={{
                    background: 'linear-gradient(135deg, rgba(239, 68, 68, 0.2), rgba(239, 68, 68, 0.1))'
                  }}
                >
                  <div className="flex items-center space-x-2 text-red-300">
                    <span>⚠️</span>
                    <span className="text-sm">Connection issue - using fallback response</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Enhanced Input Form with Neural Design */}
          <form onSubmit={handleSubmit} className="relative mb-4">
            <div className="relative">
              <input
                type="text"
                value={input}
                onChange={handleInputChange}
                placeholder="Ask about immersive experiences, VR gear, or anything else..."
                className="w-full px-6 py-4 rounded-2xl text-white placeholder-white/50 focus:outline-none text-sm border transition-all"
                style={{
                  background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.05))',
                  backdropFilter: 'blur(10px)',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  boxShadow: 'inset 0 1px 0 rgba(255, 255, 255, 0.1)'
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = 'rgba(139, 92, 246, 0.5)'
                  e.target.style.boxShadow = '0 0 0 3px rgba(139, 92, 246, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = 'rgba(255, 255, 255, 0.1)'
                  e.target.style.boxShadow = 'inset 0 1px 0 rgba(255, 255, 255, 0.1)'
                }}
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={isLoading || !input.trim()}
                className="absolute right-2 top-1/2 -translate-y-1/2 px-6 py-2 rounded-xl text-white text-sm font-medium shadow-lg disabled:cursor-not-allowed transition-all hover:scale-105 active:scale-95"
                style={{
                  background: isLoading || !input.trim() 
                    ? 'rgba(107, 114, 128, 0.5)' 
                    : 'linear-gradient(135deg, rgba(139, 92, 246, 0.8), rgba(59, 130, 246, 0.7))',
                  boxShadow: '0 4px 12px rgba(139, 92, 246, 0.3)'
                }}
              >
                {isLoading ? '⚡' : '→'}
              </button>
            </div>
          </form>

          {/* Enhanced Neural Status Footer */}
          <div className="pt-4 border-t border-white/10">
            <div className="grid grid-cols-4 gap-4 text-xs">
              <div className="text-center text-white/40">
                <div className="text-cyan-400 text-sm mb-1">🎯</div>
                <div>Context</div>
              </div>
              <div className="text-center text-white/40">
                <div className="text-purple-400 text-sm mb-1">💬</div>
                <div>{messages.length} msgs</div>
              </div>
              <div className="text-center text-white/40">
                <div className="text-pink-400 text-sm mb-1">🧠</div>
                <div>AI Ready</div>
              </div>
              <div className="text-center text-white/40">
                <div className="text-green-400 text-sm mb-1">🔋</div>
                <div>Online</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}