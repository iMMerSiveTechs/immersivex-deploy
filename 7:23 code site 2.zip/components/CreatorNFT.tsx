'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Upload, Sparkles, Share2 } from 'lucide-react'

export default function CreatorNFT() {
  const [avatarUrl, setAvatarUrl] = useState('')
  const [minted, setMinted] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  console.log('CreatorNFT component rendered, avatarUrl:', avatarUrl, 'minted:', minted)

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    console.log('File selected for upload:', file.name)
    setLoading(true)
    setError('')
    
    try {
      const form = new FormData()
      form.append('file', file)

      const res = await fetch('/api/nft/mint', {
        method: 'POST',
        body: form,
      })
      
      const data = await res.json()
      console.log('NFT mint response:', data)
      
      if (data.success) {
        setAvatarUrl(data.ipfsUrl)
        setMinted(true)
      } else {
        setError(data.message || 'Failed to mint NFT')
      }
    } catch (err) {
      console.error('NFT upload error:', err)
      setError('Failed to upload and mint NFT')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-lg mx-auto text-white p-6">
      <Card className="glass-dark border-electric-purple/30">
        <CardContent className="p-6">
          <div className="text-center mb-6">
            <div className="flex items-center justify-center mb-4">
              <Sparkles className="w-8 h-8 text-cyber-mint mr-2" />
              <h1 className="text-2xl font-bold hologram-text" data-macaly="nft-creator-title">
                Your Persona NFT
              </h1>
            </div>
            <p className="text-glass-white/70 text-sm" data-macaly="nft-creator-description">
              Create your unique digital identity for the immersive web
            </p>
          </div>

          {!avatarUrl && (
            <div className="space-y-4">
              <div className="border-2 border-dashed border-electric-purple/50 rounded-xl p-8 text-center hover:border-electric-purple transition-colors">
                <Upload className="w-12 h-12 mx-auto mb-4 text-electric-purple/50" />
                <label htmlFor="avatar-upload" className="cursor-pointer">
                  <span className="text-electric-purple hover:text-cyber-mint font-semibold">
                    Choose your avatar image
                  </span>
                  <p className="text-xs text-glass-white/50 mt-2">
                    PNG, JPG up to 10MB
                  </p>
                </label>
                <input
                  id="avatar-upload"
                  type="file"
                  accept="image/*"
                  onChange={handleUpload}
                  className="hidden"
                  disabled={loading}
                />
              </div>
              
              {loading && (
                <div className="text-center">
                  <div className="animate-pulse text-cyber-mint">
                    ⚡ Minting your NFT to IPFS...
                  </div>
                </div>
              )}
              
              {error && (
                <div className="text-center text-red-400 text-sm">
                  ✗ {error}
                </div>
              )}
            </div>
          )}

          {avatarUrl && (
            <div className="space-y-4">
              <div className="relative">
                <img
                  src={avatarUrl.startsWith('http') ? avatarUrl : `https://ipfs.io/ipfs/${avatarUrl}`}
                  alt="Your Avatar NFT"
                  className="w-full rounded-xl border border-electric-purple/30 shadow-neon"
                  data-macaly="user-avatar-nft"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-deep-black/60 via-transparent to-transparent rounded-xl" />
              </div>
              
              {minted && (
                <div className="text-center space-y-3">
                  <div className="text-green-400 font-semibold animate-pulse-slow">
                    ✅ Successfully minted to IPFS!
                  </div>
                  <div className="flex gap-2 justify-center">
                    <Button
                      size="sm"
                      className="bg-gradient-to-r from-electric-purple to-cyber-mint text-white"
                      data-macaly="share-nft-btn"
                    >
                      <Share2 className="w-4 h-4 mr-2" />
                      Share NFT
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-electric-purple/50 text-electric-purple hover:bg-electric-purple/10"
                      onClick={() => {
                        setAvatarUrl('')
                        setMinted(false)
                      }}
                      data-macaly="create-new-nft-btn"
                    >
                      Create New
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}