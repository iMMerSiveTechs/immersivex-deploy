"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"

export function FloatingMenu() {
  const [open, setOpen] = useState(false)
  const [darkMode, setDarkMode] = useState(false)
  const [isDragging, setIsDragging] = useState(false)
  const [position, setPosition] = useState({ x: 16, y: 16 })
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })
  const orbRef = useRef<HTMLDivElement>(null)
  const pathname = usePathname()

  // Dark mode detection and toggle
  useEffect(() => {
    const isDark = document.body.classList.contains('dark-mode') || 
                   window.matchMedia('(prefers-color-scheme: dark)').matches
    setDarkMode(isDark)
  }, [])

  // Dragging functionality
  const handleMouseDown = (e: React.MouseEvent) => {
    if (open) return // Disable dragging when menu is open
    setIsDragging(true)
    const rect = orbRef.current?.getBoundingClientRect()
    if (rect) {
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      })
    }
    console.log('Menu orb drag started')
    e.preventDefault()
  }

  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging || open) return
    
    const newX = e.clientX - dragOffset.x
    const newY = e.clientY - dragOffset.y
    
    // Keep orb within viewport bounds
    const maxX = window.innerWidth - 40
    const maxY = window.innerHeight - 40
    
    setPosition({
      x: Math.max(0, Math.min(maxX, newX)),
      y: Math.max(0, Math.min(maxY, newY))
    })
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  // Global mouse event listeners for dragging
  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove)
      document.addEventListener('mouseup', handleMouseUp)
      return () => {
        document.removeEventListener('mousemove', handleMouseMove)
        document.removeEventListener('mouseup', handleMouseUp)
      }
    }
  }, [isDragging, dragOffset])

  const toggleDarkMode = () => {
    const newDarkMode = !darkMode
    setDarkMode(newDarkMode)
    
    if (newDarkMode) {
      document.body.classList.add('dark-mode')
      localStorage.setItem('darkMode', 'true')
    } else {
      document.body.classList.remove('dark-mode')
      localStorage.setItem('darkMode', 'false')
    }
    
    console.log('Dark mode toggled:', newDarkMode)
  }

  const handleOrbClick = (e: React.MouseEvent) => {
    if (!isDragging) {
      setOpen(!open)
    }
  }

  const menuItems = [
    { href: "/", label: "Home", icon: "🏠" },
    { href: "/events", label: "Experiences", icon: "🎬" },
    { href: "/gear", label: "Gear Vault", icon: "⚡" },
    { href: "/submit", label: "Submit", icon: "📝" },
    { href: "/updates", label: "Updates", icon: "📢" },
  ]

  return (
    <>
      {/* ULTRA-GLASSY NAV ORB - DRAGGABLE */}
      <div
        ref={orbRef}
        onMouseDown={handleMouseDown}
        onClick={handleOrbClick}
        className={`fixed w-10 h-10 rounded-full z-50 flex items-center justify-center text-white text-base transition-all duration-500 hardware-accelerated select-none ${
          isDragging ? 'cursor-grabbing scale-110' : 'cursor-grab'
        } ${
          open ? 'scale-110 rotate-180' : 'hover:scale-105 hover:rotate-12'
        }`}
        style={{
          left: position.x,
          top: position.y,
          background: 'linear-gradient(135deg, rgba(255,255,255,0.15), rgba(255,255,255,0.05))',
          backdropFilter: 'blur(25px) saturate(180%)',
          border: '1px solid rgba(255,255,255,0.25)',
          boxShadow: '0 8px 32px rgba(0,0,0,0.4), 0 2px 16px rgba(99,102,241,0.2), inset 0 1px 0 rgba(255,255,255,0.3)'
        }}
      >
        <div className={`transition-all duration-500 ${open ? 'rotate-90 scale-90' : 'scale-100'}`}>
          ☰
        </div>
      </div>

      {/* ULTRA-SLEEK FLOATING MENU */}
      {open && (
        <>
          {/* Backdrop with blur */}
          <div 
            className="fixed inset-0 bg-black/30 backdrop-blur-md z-40 transition-all duration-300"
            onClick={() => setOpen(false)}
          />
          
          {/* Menu Panel - Pure Glass */}
          <div 
            className="fixed w-72 text-white rounded-3xl z-50 overflow-hidden animate-in slide-in-from-left-2 duration-500 hardware-accelerated"
            style={{
              left: Math.min(position.x, window.innerWidth - 288), // 288px = w-72 width
              top: position.y + 48, // 48px below the orb
              background: `
                linear-gradient(135deg, 
                  rgba(255,255,255,0.08) 0%,
                  rgba(255,255,255,0.03) 25%,
                  rgba(99,102,241,0.05) 50%,
                  rgba(16,255,240,0.03) 75%,
                  rgba(255,255,255,0.02) 100%)
              `,
              backdropFilter: 'blur(30px) saturate(200%) brightness(120%)',
              border: '1px solid rgba(255,255,255,0.15)',
              boxShadow: `
                0 20px 60px rgba(0,0,0,0.6),
                0 4px 20px rgba(99,102,241,0.3),
                inset 0 1px 0 rgba(255,255,255,0.2),
                inset 0 -1px 0 rgba(255,255,255,0.05)
              `
            }}
          >
            {/* Holographic Header */}
            <div className="p-5 border-b border-white/10">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-cyan-400 rounded-full animate-pulse"></div>
                  <h3 className="font-semibold text-lg tracking-wide">Menu</h3>
                </div>
                <button
                  onClick={() => setOpen(false)}
                  className="text-white/60 hover:text-white transition-all duration-300 w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/10 hover:scale-110"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Menu Items - Ultra Smooth */}
            <div className="p-3 space-y-1">
              {menuItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className={`flex items-center gap-4 px-4 py-3 rounded-2xl transition-all duration-300 group relative overflow-hidden ${
                    pathname === item.href
                      ? 'bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-300 border border-cyan-400/40 shadow-lg scale-105'
                      : 'hover:bg-white/10 text-white/80 hover:text-white hover:scale-102 hover:shadow-md'
                  }`}
                >
                  <span className="text-xl filter drop-shadow-lg">{item.icon}</span>
                  <span className="font-medium tracking-wide">{item.label}</span>
                  {pathname === item.href && (
                    <div className="ml-auto w-2 h-2 bg-cyan-400 rounded-full animate-pulse shadow-lg"></div>
                  )}
                  
                  {/* Hover shimmer effect */}
                  <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
                </Link>
              ))}
            </div>

            {/* Glassy Controls Section */}
            <div className="border-t border-white/10 p-4 space-y-4">
              {/* Dark Mode Toggle - Improved */}
              <div className="flex items-center justify-between">
                <span className="text-white/90 font-medium flex items-center gap-3">
                  <span className="text-lg">{darkMode ? '🌙' : '☀️'}</span> 
                  <span className="tracking-wide">{darkMode ? 'Dark' : 'Light'}</span>
                </span>
                <button
                  onClick={toggleDarkMode}
                  className={`relative w-14 h-7 rounded-full transition-all duration-500 shadow-inner ${
                    darkMode 
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600 shadow-cyan-500/30' 
                      : 'bg-white/20 shadow-white/10'
                  }`}
                >
                  <div
                    className={`absolute w-6 h-6 bg-white rounded-full top-0.5 transition-all duration-500 shadow-lg ${
                      darkMode ? 'left-7 scale-95' : 'left-0.5 scale-100'
                    }`}
                    style={{
                      background: darkMode 
                        ? 'linear-gradient(135deg, #ffffff, #e0f7ff)' 
                        : 'linear-gradient(135deg, #ffffff, #f8fafc)'
                    }}
                  />
                </button>
              </div>

              {/* Platform Status - Enhanced */}
              <div className="flex items-center gap-3 text-sm text-white/70 p-2 rounded-xl bg-white/5">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse shadow-green-400/50 shadow-sm"></div>
                <span className="tracking-wide">Platform Online</span>
              </div>
            </div>

            {/* Footer with Branding */}
            <div className="border-t border-white/10 p-4">
              <div className="text-center text-white/60">
                <div className="font-semibold text-sm tracking-wider bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                  ImmersiveX
                </div>
                <div className="text-xs mt-1 opacity-75">Experience Everything</div>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  )
}