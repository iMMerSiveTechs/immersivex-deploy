'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Calendar, Clock, Link2, Users, Sparkles } from 'lucide-react'

interface Event {
  id: string
  name: string
  description: string
  date: string
  time: string
  link: string
  category: string
  capacity: string
  created: string
}

export default function EventCreator() {
  const [form, setForm] = useState({
    name: '',
    description: '',
    date: '',
    time: '',
    link: '',
    category: 'Concert',
    capacity: '1000'
  })
  const [events, setEvents] = useState<Event[]>([])
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  console.log('EventCreator component rendered, form:', form, 'events count:', events.length)

  useEffect(() => {
    const saved = localStorage.getItem('immersiveEvents')
    if (saved) {
      const parsedEvents = JSON.parse(saved)
      setEvents(parsedEvents)
      console.log('Loaded events from storage:', parsedEvents.length)
    }
  }, [])

  const saveEvent = async () => {
    if (!form.name || !form.date || !form.time) {
      alert('Please fill in required fields (name, date, time)')
      return
    }

    console.log('Creating new event:', form)
    setLoading(true)
    
    try {
      const newEvent: Event = {
        id: Date.now().toString(),
        ...form,
        created: new Date().toISOString()
      }
      
      const updatedEvents = [...events, newEvent]
      localStorage.setItem('immersiveEvents', JSON.stringify(updatedEvents))
      setEvents(updatedEvents)
      
      // Reset form
      setForm({
        name: '',
        description: '',
        date: '',
        time: '',
        link: '',
        category: 'Concert',
        capacity: '1000'
      })
      
      setSuccess(true)
      setTimeout(() => setSuccess(false), 3000)
      
      console.log('Event created successfully:', newEvent)
    } catch (error) {
      console.error('Error creating event:', error)
    } finally {
      setLoading(false)
    }
  }

  const categories = ['Concert', 'Movie', 'Education', 'Indie', 'Workshop', 'Exhibition']

  return (
    <div className="max-w-2xl mx-auto p-6 text-white">
      <Card className="glass-dark border-electric-purple/30">
        <CardContent className="p-6">
          <div className="text-center mb-6">
            <div className="flex items-center justify-center mb-4">
              <Sparkles className="w-8 h-8 text-cyber-mint mr-2" />
              <h2 className="text-2xl font-bold hologram-text" data-macaly="event-creator-title">
                Create Immersive Event
              </h2>
            </div>
            <p className="text-glass-white/70 text-sm" data-macaly="event-creator-subtitle">
              Launch your own virtual concert, AR workshop, or VR experience
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-electric-purple mb-2">
                Event Name *
              </label>
              <Input
                placeholder="e.g. Virtual Concert in the Metaverse"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="bg-black/30 border-electric-purple/30 text-white"
                data-macaly="event-name-input"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-electric-purple mb-2">
                Description
              </label>
              <Textarea
                placeholder="Describe your immersive experience..."
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="bg-black/30 border-electric-purple/30 text-white min-h-[80px]"
                data-macaly="event-description-input"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-electric-purple mb-2">
                  <Calendar className="w-4 h-4 inline mr-1" />
                  Date *
                </label>
                <Input
                  type="date"
                  value={form.date}
                  onChange={(e) => setForm({ ...form, date: e.target.value })}
                  className="bg-black/30 border-electric-purple/30 text-white"
                  data-macaly="event-date-input"
                />
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-electric-purple mb-2">
                  <Clock className="w-4 h-4 inline mr-1" />
                  Time *
                </label>
                <Input
                  type="time"
                  value={form.time}
                  onChange={(e) => setForm({ ...form, time: e.target.value })}
                  className="bg-black/30 border-electric-purple/30 text-white"
                  data-macaly="event-time-input"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-electric-purple mb-2">
                <Link2 className="w-4 h-4 inline mr-1" />
                Experience Link
              </label>
              <Input
                placeholder="https://your-vr-experience.com"
                value={form.link}
                onChange={(e) => setForm({ ...form, link: e.target.value })}
                className="bg-black/30 border-electric-purple/30 text-white"
                data-macaly="event-link-input"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-electric-purple mb-2">
                  Category
                </label>
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="w-full p-2 rounded-md bg-black/30 border border-electric-purple/30 text-white"
                  data-macaly="event-category-select"
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-electric-purple mb-2">
                  <Users className="w-4 h-4 inline mr-1" />
                  Capacity
                </label>
                <Input
                  placeholder="1000"
                  value={form.capacity}
                  onChange={(e) => setForm({ ...form, capacity: e.target.value })}
                  className="bg-black/30 border-electric-purple/30 text-white"
                  data-macaly="event-capacity-input"
                />
              </div>
            </div>

            <Button
              onClick={saveEvent}
              disabled={loading}
              className="w-full bg-gradient-to-r from-electric-purple to-cyber-mint text-white font-semibold py-3 shadow-neon hover:shadow-neon-strong transition-all duration-300"
              data-macaly="create-event-btn"
            >
              {loading ? 'Creating Event...' : 'Create Event'}
            </Button>

            {success && (
              <div className="text-center text-green-400 font-semibold animate-pulse-slow">
                ✅ Event created successfully!
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recent Events */}
      {events.length > 0 && (
        <div className="mt-8">
          <h3 className="text-xl font-bold mb-4 text-cyber-mint">Your Recent Events</h3>
          <div className="space-y-3">
            {events.slice(-3).reverse().map((event) => (
              <Card key={event.id} className="glass-dark border-electric-purple/20">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-semibold text-white">{event.name}</h4>
                      <p className="text-sm text-glass-white/70">
                        {new Date(event.date).toLocaleDateString()} at {event.time}
                      </p>
                    </div>
                    <span className="text-xs bg-cyber-mint/20 text-cyber-mint px-2 py-1 rounded">
                      {event.category}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}