"use client"

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Sparkles, Twitter, Instagram, Users } from 'lucide-react'

const Footer = () => {
  console.log("Footer component rendered")

  const footerLinks = {
    platform: [
      { label: 'About', href: '#about' },
      { label: 'Creators', href: '#creators' },
      { label: 'Pricing', href: '#pricing' },
      { label: 'Contact', href: '#contact' }
    ],
    support: [
      { label: 'Help Center', href: '#' },
      { label: 'Community', href: '#' },
      { label: 'Status', href: '#' },
      { label: 'API Docs', href: '#' }
    ],
    legal: [
      { label: 'Terms of Service', href: '#' },
      { label: 'Privacy Policy', href: '#' },
      { label: 'Cookie Policy', href: '#' },
      { label: 'Content Guidelines', href: '#' }
    ]
  }

  const socialLinks = [
    { 
      name: 'Twitter/X', 
      href: '#', 
      icon: Twitter,
      color: 'hover:text-cyber-mint'
    },
    { 
      name: 'Instagram', 
      href: '#', 
      icon: Instagram,
      color: 'hover:text-neon-pink'
    },
    { 
      name: 'Discord', 
      href: '#', 
      icon: Users,
      color: 'hover:text-electric-purple'
    }
  ]

  return (
    <footer className="relative bg-gradient-to-b from-transparent to-deep-black border-t border-electric-purple/20">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-r from-electric-purple/5 via-transparent to-cyber-mint/5" />
        {/* Subtle Grid */}
        <div 
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: `
              linear-gradient(rgba(99, 102, 241, 0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(99, 102, 241, 0.3) 1px, transparent 1px)
            `,
            backgroundSize: '40px 40px'
          }}
        />
      </div>

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        {/* Main Footer Content */}
        <div className="py-16">
          <div className="grid lg:grid-cols-5 gap-8">
            {/* Brand Section */}
            <div className="lg:col-span-2">
              <Link 
                href="/" 
                className="flex items-center space-x-2 group mb-6"
                data-macaly="footer-logo"
              >
                <div className="w-10 h-10 bg-gradient-cyber rounded-lg flex items-center justify-center group-hover:animate-glow transition-all duration-300">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <span className="text-2xl font-bold bg-gradient-to-r from-electric-purple to-cyber-mint bg-clip-text text-transparent">
                  ImmersiveX
                </span>
              </Link>
              
              <p 
                className="text-glass-white/70 leading-relaxed mb-6 max-w-md"
                data-macaly="footer-description"
              >
                Experience the future of entertainment through immersive VR, AR, and interactive content. 
                Join millions of users exploring new dimensions of digital experience.
              </p>
              
              <div className="flex items-center space-x-4">
                {socialLinks.map((social) => (
                  <Link
                    key={social.name}
                    href={social.href}
                    className={`w-10 h-10 rounded-lg glass-dark border border-electric-purple/30 flex items-center justify-center text-glass-white/60 ${social.color} hover:border-electric-purple/50 transition-all duration-300 group`}
                    data-macaly={`social-${social.name.toLowerCase().replace('/', '-')}`}
                  >
                    <social.icon className="w-5 h-5 group-hover:animate-pulse-slow" />
                  </Link>
                ))}
              </div>
            </div>

            {/* Links Sections */}
            <div className="grid grid-cols-1 md:grid-cols-3 lg:col-span-3 gap-8">
              {/* Platform Links */}
              <div>
                <h3 
                  className="text-white font-semibold text-lg mb-4"
                  data-macaly="footer-platform-title"
                >
                  Platform
                </h3>
                <ul className="space-y-3">
                  {footerLinks.platform.map((link) => (
                    <li key={link.label}>
                      <Link
                        href={link.href}
                        className="text-glass-white/60 hover:text-cyber-mint transition-colors duration-300"
                        data-macaly={`footer-platform-${link.label.toLowerCase().replace(' ', '-')}`}
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Support Links */}
              <div>
                <h3 
                  className="text-white font-semibold text-lg mb-4"
                  data-macaly="footer-support-title"
                >
                  Support
                </h3>
                <ul className="space-y-3">
                  {footerLinks.support.map((link) => (
                    <li key={link.label}>
                      <Link
                        href={link.href}
                        className="text-glass-white/60 hover:text-electric-purple transition-colors duration-300"
                        data-macaly={`footer-support-${link.label.toLowerCase().replace(' ', '-')}`}
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Legal Links */}
              <div>
                <h3 
                  className="text-white font-semibold text-lg mb-4"
                  data-macaly="footer-legal-title"
                >
                  Legal
                </h3>
                <ul className="space-y-3">
                  {footerLinks.legal.map((link) => (
                    <li key={link.label}>
                      <Link
                        href={link.href}
                        className="text-glass-white/60 hover:text-neon-pink transition-colors duration-300"
                        data-macaly={`footer-legal-${link.label.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Creator Login CTA */}
        <div className="py-8 border-t border-electric-purple/20">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-4 md:mb-0">
              <h3 
                className="text-white font-semibold text-lg mb-2"
                data-macaly="footer-creator-cta-title"
              >
                Ready to Create?
              </h3>
              <p 
                className="text-glass-white/70"
                data-macaly="footer-creator-cta-description"
              >
                Join thousands of creators building the future of immersive content
              </p>
            </div>
            <Button 
              className="bg-gradient-to-r from-electric-purple to-cyber-mint hover:from-electric-purple/80 hover:to-cyber-mint/80 text-white font-semibold px-6 py-3 rounded-lg transition-all duration-300 shadow-neon"
              data-macaly="footer-creator-login-btn"
            >
              <Users className="w-4 h-4 mr-2" />
              Creator Login
            </Button>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="py-6 border-t border-electric-purple/20">
          <div className="flex flex-col md:flex-row items-center justify-between text-sm">
            <p 
              className="text-glass-white/60 mb-4 md:mb-0"
              data-macaly="footer-copyright"
            >
              © 2025 ImmersiveX. All rights reserved. Built for the future of entertainment.
            </p>
            
            <div className="flex items-center space-x-6">
              <Link
                href="#"
                className="text-glass-white/60 hover:text-white transition-colors duration-300"
                data-macaly="footer-terms-link"
              >
                Terms
              </Link>
              <Link
                href="#"
                className="text-glass-white/60 hover:text-white transition-colors duration-300"
                data-macaly="footer-privacy-link"
              >
                Privacy
              </Link>
              <div className="flex items-center space-x-2 text-glass-white/60">
                <div className="w-2 h-2 bg-cyber-mint rounded-full animate-pulse-slow"></div>
                <span>All systems operational</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer