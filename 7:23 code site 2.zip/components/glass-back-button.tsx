"use client"

import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { ArrowLeft, Home, ChevronLeft } from 'lucide-react'

interface GlassBackButtonProps {
  variant?: 'default' | 'home' | 'minimal'
  className?: string
  label?: string
  href?: string
}

const GlassBackButton = ({ 
  variant = 'default', 
  className = '', 
  label, 
  href 
}: GlassBackButtonProps) => {
  const router = useRouter()

  const handleBack = () => {
    if (href) {
      router.push(href)
    } else {
      router.back()
    }
  }

  const getIcon = () => {
    switch (variant) {
      case 'home':
        return <Home className="w-4 h-4" />
      case 'minimal':
        return <ChevronLeft className="w-4 h-4" />
      default:
        return <ArrowLeft className="w-4 h-4" />
    }
  }

  const getLabel = () => {
    if (label) return label
    switch (variant) {
      case 'home':
        return 'Home'
      case 'minimal':
        return ''
      default:
        return 'Back'
    }
  }

  return (
    <Button
      onClick={handleBack}
      variant="ghost"
      className={`
        glass-back-btn group transition-all duration-300 hover:scale-105
        bg-white/5 backdrop-blur-xl border border-white/10 
        hover:bg-white/10 hover:border-electric-purple/50 hover:shadow-lg hover:shadow-electric-purple/20
        text-white/80 hover:text-white
        ${className}
      `}
      data-macaly="glass-back-button"
    >
      <span className="mr-2 group-hover:transform group-hover:-translate-x-1 transition-transform duration-300">
        {getIcon()}
      </span>
      {getLabel() && (
        <span className="font-medium text-sm">
          {getLabel()}
        </span>
      )}
    </Button>
  )
}

export default GlassBackButton