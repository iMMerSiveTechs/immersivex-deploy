/**
 * ImmersiveX Security Utilities
 * High-end security functions for protecting sensitive data and preventing attacks
 */

// Content Security Policy headers
export const CSP_HEADERS = {
  'Content-Security-Policy': `
    default-src 'self';
    script-src 'self' 'unsafe-inline' 'unsafe-eval' https://mlc.ai https://cdn.jsdelivr.net;
    style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;
    font-src 'self' https://fonts.gstatic.com;
    img-src 'self' data: https: blob:;
    media-src 'self' https: blob:;
    connect-src 'self' https: wss:;
    frame-src 'self' https:;
    worker-src 'self' blob:;
    object-src 'none';
    base-uri 'self';
    form-action 'self';
    frame-ancestors 'none';
    upgrade-insecure-requests;
  `.replace(/\s+/g, ' ').trim()
}

// Security Headers
export const SECURITY_HEADERS = {
  'X-Frame-Options': 'DENY',
  'X-Content-Type-Options': 'nosniff',
  'X-XSS-Protection': '1; mode=block',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains; preload',
  ...CSP_HEADERS
}

// Input sanitization
export function sanitizeInput(input: string): string {
  console.log("Sanitizing input:", input?.substring(0, 50) + "...")
  
  return input
    .replace(/[<>]/g, '') // Remove HTML tags
    .replace(/javascript:/gi, '') // Remove javascript: protocols
    .replace(/on\w+=/gi, '') // Remove event handlers
    .replace(/data:/gi, '') // Remove data: URLs
    .trim()
    .substring(0, 10000) // Limit length
}

// Email validation with advanced security
export function validateEmail(email: string): boolean {
  console.log("Validating email:", email)
  
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  const isValid = emailRegex.test(email) && 
                  email.length <= 254 && 
                  !email.includes('..') &&
                  !email.startsWith('.') &&
                  !email.endsWith('.')
  
  console.log("Email validation result:", isValid)
  return isValid
}

// URL validation for affiliate links
export function validateURL(url: string): boolean {
  console.log("Validating URL:", url)
  
  try {
    const parsed = new URL(url)
    const isValid = ['http:', 'https:'].includes(parsed.protocol) &&
                    parsed.hostname.length > 0 &&
                    !parsed.hostname.includes('localhost') &&
                    !parsed.hostname.includes('127.0.0.1') &&
                    !parsed.hostname.includes('0.0.0.0')
    
    console.log("URL validation result:", isValid)
    return isValid
  } catch {
    console.log("URL validation failed: Invalid URL format")
    return false
  }
}

// Generate secure random tokens
export function generateSecureToken(length: number = 32): string {
  console.log("Generating secure token of length:", length)
  
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  let result = ''
  
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  
  console.log("Secure token generated successfully")
  return result
}

// Rate limiting simulation (in production, use Redis or similar)
const rateLimitMap = new Map<string, { count: number; resetTime: number }>()

export function checkRateLimit(identifier: string, maxRequests: number = 10, windowMs: number = 60000): boolean {
  console.log("Checking rate limit for:", identifier)
  
  const now = Date.now()
  const record = rateLimitMap.get(identifier)
  
  if (!record || now > record.resetTime) {
    rateLimitMap.set(identifier, { count: 1, resetTime: now + windowMs })
    console.log("Rate limit check passed - new window")
    return true
  }
  
  if (record.count >= maxRequests) {
    console.log("Rate limit exceeded for:", identifier)
    return false
  }
  
  record.count++
  console.log("Rate limit check passed - count:", record.count)
  return true
}

// Content filtering for submissions
export function filterContent(content: string): { filtered: string; flagged: boolean } {
  console.log("Filtering content, length:", content.length)
  
  const flaggedWords = [
    'malware', 'virus', 'hack', 'exploit', 'phishing', 'scam',
    'cryptocurrency', 'bitcoin', 'nft', 'investment', 'trading'
  ]
  
  let filtered = sanitizeInput(content)
  let flagged = false
  
  for (const word of flaggedWords) {
    if (filtered.toLowerCase().includes(word.toLowerCase())) {
      flagged = true
      console.log("Content flagged for word:", word)
      break
    }
  }
  
  console.log("Content filtering complete, flagged:", flagged)
  return { filtered, flagged }
}

// Encrypt sensitive data (basic implementation)
export function encryptData(data: string, key: string = 'immersivex-secure'): string {
  console.log("Encrypting data")
  
  let encrypted = ''
  for (let i = 0; i < data.length; i++) {
    const char = data.charCodeAt(i)
    const keyChar = key.charCodeAt(i % key.length)
    encrypted += String.fromCharCode(char ^ keyChar)
  }
  
  return btoa(encrypted)
}

// Decrypt sensitive data
export function decryptData(encryptedData: string, key: string = 'immersivex-secure'): string {
  console.log("Decrypting data")
  
  try {
    const encrypted = atob(encryptedData)
    let decrypted = ''
    
    for (let i = 0; i < encrypted.length; i++) {
      const char = encrypted.charCodeAt(i)
      const keyChar = key.charCodeAt(i % key.length)
      decrypted += String.fromCharCode(char ^ keyChar)
    }
    
    return decrypted
  } catch (error) {
    console.error("Decryption failed:", error)
    return ''
  }
}

// Session security
export function generateSessionId(): string {
  console.log("Generating secure session ID")
  
  const timestamp = Date.now().toString(36)
  const randomPart = generateSecureToken(16)
  const sessionId = `${timestamp}-${randomPart}`
  
  console.log("Session ID generated")
  return sessionId
}

// Input validation for forms
export function validateFormData(data: Record<string, any>): { isValid: boolean; errors: string[] } {
  console.log("Validating form data with keys:", Object.keys(data))
  
  const errors: string[] = []
  
  // Check for required fields
  const requiredFields = ['projectTitle', 'projectType', 'description', 'contactEmail']
  for (const field of requiredFields) {
    if (!data[field] || typeof data[field] !== 'string' || data[field].trim().length === 0) {
      errors.push(`${field} is required`)
    }
  }
  
  // Validate email
  if (data.contactEmail && !validateEmail(data.contactEmail)) {
    errors.push('Invalid email format')
  }
  
  // Validate URL if provided
  if (data.experienceLink && data.experienceLink.trim() && !validateURL(data.experienceLink)) {
    errors.push('Invalid experience link URL')
  }
  
  // Check content length limits
  if (data.description && data.description.length > 5000) {
    errors.push('Description too long (max 5000 characters)')
  }
  
  if (data.projectTitle && data.projectTitle.length > 200) {
    errors.push('Project title too long (max 200 characters)')
  }
  
  console.log("Form validation complete, errors:", errors.length)
  return { isValid: errors.length === 0, errors }
}

// Anti-bot protection
export function verifyHuman(timestamp: number, mouseMovements: number = 0): boolean {
  console.log("Verifying human interaction")
  
  const now = Date.now()
  const timeDiff = now - timestamp
  
  // Too fast (likely bot)
  if (timeDiff < 3000) {
    console.log("Interaction too fast, likely bot")
    return false
  }
  
  // Too slow (suspicious)
  if (timeDiff > 1800000) { // 30 minutes
    console.log("Interaction too slow, session expired")
    return false
  }
  
  console.log("Human verification passed")
  return true
}

// IP address validation and blocking
const blockedIPs = new Set(['127.0.0.1', '0.0.0.0'])

export function validateIP(ip: string): boolean {
  console.log("Validating IP address:", ip)
  
  if (blockedIPs.has(ip)) {
    console.log("IP address is blocked")
    return false
  }
  
  // Basic IP format validation
  const ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/
  const isValid = ipRegex.test(ip)
  
  console.log("IP validation result:", isValid)
  return isValid
}

// Security event logging
export function logSecurityEvent(event: string, details: Record<string, any> = {}): void {
  const timestamp = new Date().toISOString()
  const logEntry = {
    timestamp,
    event,
    details,
    userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'server',
    url: typeof window !== 'undefined' ? window.location.href : 'server'
  }
  
  console.log("Security Event:", logEntry)
  
  // In production, send to security monitoring service
  // Example: sendToSecurityMonitoring(logEntry)
}

export default {
  sanitizeInput,
  validateEmail,
  validateURL,
  generateSecureToken,
  checkRateLimit,
  filterContent,
  encryptData,
  decryptData,
  generateSessionId,
  validateFormData,
  verifyHuman,
  validateIP,
  logSecurityEvent,
  SECURITY_HEADERS
}