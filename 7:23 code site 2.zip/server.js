const http = require('http');
const fs = require('fs');
const path = require('path');

const server = http.createServer((req, res) => {
  console.log('Request:', req.url);
  
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(`<!DOCTYPE html>
<html>
<head>
    <title>ImmersiveX - WORKING</title>
    <style>
        body { 
            margin: 0; 
            font-family: system-ui; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-align: center;
        }
        h1 { font-size: 4rem; margin: 0; }
        p { font-size: 1.5rem; }
    </style>
</head>
<body>
    <div>
        <h1>🚀 ImmersiveX</h1>
        <p>SITE IS LIVE & WORKING!</p>
        <p>✅ Infrastructure FIXED</p>
        <p>AI-Powered Immersive Entertainment Network</p>
    </div>
</body>
</html>`);
});

server.listen(3000, () => {
  console.log('Server running on port 3000');
});