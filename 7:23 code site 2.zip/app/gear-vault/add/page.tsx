import AffiliateLinkUploader from '@/components/affiliate-uploader'

export default function AddGearPage() {
  console.log('AddGearPage component rendered')
  
  return <AffiliateLinkUploader />
}