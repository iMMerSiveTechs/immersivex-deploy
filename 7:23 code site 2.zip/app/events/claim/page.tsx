'use client'

import { useState } from 'react'
import Link from 'next/link'

export default function ClaimTicketPage() {
  const [email, setEmail] = useState('')
  const [eventId, setEventId] = useState('')
  const [claimed, setClaimed] = useState(false)
  const [claiming, setClaiming] = useState(false)

  const claimTicket = async () => {
    if (!email || !eventId) return
    
    setClaiming(true)
    // Simulate NFT ticket claim process
    setTimeout(() => {
      setClaimed(true)
      setClaiming(false)
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-purple-900 to-blue-900 pt-20">
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <div className="mb-8">
          <Link href="/events" className="inline-flex items-center px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-all">
            ← Back to Events
          </Link>
        </div>

        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-pink-500 to-cyan-500 bg-clip-text text-transparent">
            Claim Your NFT Ticket
          </h1>
          <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Get your proof-of-attendance NFT ticket and be part of the immersive revolution
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-purple-500/30">
            {!claimed ? (
              <div className="space-y-6">
                <div className="text-center mb-8">
                  <div className="text-6xl mb-4">🎟️</div>
                  <h3 className="text-2xl font-semibold text-white mb-2">Claim Your Digital Ticket</h3>
                  <p className="text-gray-400">Provide your details to receive your NFT proof-of-attendance</p>
                </div>

                <div>
                  <label className="block text-white font-semibold mb-2">Email Address</label>
                  <input
                    type="email"
                    placeholder="your.email@example.com"
                    className="w-full p-3 bg-white/10 border border-purple-500/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-purple-500"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-white font-semibold mb-2">Event ID or Name</label>
                  <input
                    type="text"
                    placeholder="Billie Eilish Virtual Tour or Event #123"
                    className="w-full p-3 bg-white/10 border border-purple-500/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-purple-500"
                    value={eventId}
                    onChange={(e) => setEventId(e.target.value)}
                  />
                </div>

                <div className="bg-blue-500/20 border border-blue-500/50 rounded-lg p-4">
                  <p className="text-blue-300 text-sm">
                    <strong>💡 How it works:</strong> After attending an event, use this form to claim your NFT ticket. 
                    This serves as proof of attendance and can unlock exclusive content or future event access.
                  </p>
                </div>

                <button
                  onClick={claimTicket}
                  disabled={!email || !eventId || claiming}
                  className="w-full bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-300 disabled:opacity-50"
                >
                  {claiming ? '🔄 Processing Claim...' : '🎟️ Claim NFT Ticket'}
                </button>
              </div>
            ) : (
              <div className="text-center space-y-6">
                <div className="text-8xl mb-4">🎉</div>
                <h3 className="text-3xl font-bold text-white mb-4">Ticket Claimed Successfully!</h3>
                
                <div className="bg-green-500/20 border border-green-500/50 rounded-lg p-6">
                  <div className="text-green-300 space-y-2">
                    <p className="font-semibold">Your NFT ticket has been minted!</p>
                    <p className="text-sm">Event: {eventId}</p>
                    <p className="text-sm">Sent to: {email}</p>
                    <p className="text-sm">Blockchain: Ethereum (testnet)</p>
                    <p className="text-sm">Token ID: #{Math.floor(Math.random() * 10000)}</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <p className="text-gray-400">
                    Check your email for the NFT details and wallet instructions.
                  </p>
                  
                  <div className="flex gap-4 justify-center">
                    <button
                      onClick={() => {
                        setClaimed(false)
                        setEmail('')
                        setEventId('')
                      }}
                      className="border border-purple-500/50 text-purple-400 hover:bg-purple-500/10 font-semibold py-2 px-6 rounded-lg transition-all"
                    >
                      Claim Another
                    </button>
                    <Link
                      href="/events"
                      className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 text-white font-semibold py-2 px-6 rounded-lg transition-all"
                    >
                      Browse Events
                    </Link>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}