'use client'

import { useState } from 'react'
import Link from 'next/link'

export default function CreateEventPage() {
  const [form, setForm] = useState({ name: '', date: '', link: '', description: '' })
  const [saved, setSaved] = useState(false)

  const saveEvent = () => {
    const newEvent = { ...form, created: new Date().toISOString() }
    const existingEvents = JSON.parse(localStorage.getItem('immersiveEvents') || '[]')
    localStorage.setItem('immersiveEvents', JSON.stringify([...existingEvents, newEvent]))
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
    setForm({ name: '', date: '', link: '', description: '' })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-purple-900 to-blue-900 pt-20">
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <div className="mb-8">
          <Link href="/events" className="inline-flex items-center px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-all">
            ← Back to Events
          </Link>
        </div>

        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-pink-500 to-cyan-500 bg-clip-text text-transparent">
            Create Your Immersive Event
          </h1>
          <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Launch your own virtual concert, AR workshop, VR experience, or indie showcase for the community
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-purple-500/30">
            <div className="space-y-6">
              <div>
                <label className="block text-white font-semibold mb-2">Event Name</label>
                <input
                  type="text"
                  placeholder="Amazing VR Concert Experience"
                  className="w-full p-3 bg-white/10 border border-purple-500/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-purple-500"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-white font-semibold mb-2">Event Date & Time</label>
                <input
                  type="datetime-local"
                  className="w-full p-3 bg-white/10 border border-purple-500/30 rounded-lg text-white focus:outline-none focus:border-purple-500"
                  value={form.date}
                  onChange={(e) => setForm({ ...form, date: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-white font-semibold mb-2">Experience Link</label>
                <input
                  type="url"
                  placeholder="https://your-vr-world.com/join"
                  className="w-full p-3 bg-white/10 border border-purple-500/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-purple-500"
                  value={form.link}
                  onChange={(e) => setForm({ ...form, link: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-white font-semibold mb-2">Description</label>
                <textarea
                  placeholder="Describe your immersive experience..."
                  className="w-full p-3 bg-white/10 border border-purple-500/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-purple-500 h-24"
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                />
              </div>

              <button
                onClick={saveEvent}
                className="w-full bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-300"
              >
                Create Event
              </button>

              {saved && (
                <div className="text-center text-green-400 font-semibold">
                  ✅ Event created successfully!
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}