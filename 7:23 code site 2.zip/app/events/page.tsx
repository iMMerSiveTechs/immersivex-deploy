export default function EventsPage() {
  return (
    <div style={{ 
      fontFamily: 'system-ui, -apple-system, sans-serif',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      minHeight: '100vh',
      color: 'white',
      padding: '2rem'
    }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <h1 style={{ fontSize: '3rem', fontWeight: 'bold', marginBottom: '1rem' }}>
            🎮 VR/AR Events
          </h1>
          <p style={{ fontSize: '1.2rem', opacity: 0.9 }}>
            Immersive experiences powered by AI
          </p>
        </div>

        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', 
          gap: '2rem' 
        }}>
          {[
            { title: "VR Concert Experience", time: "Tonight 8PM EST", type: "🎵 Music" },
            { title: "AI Art Gallery", time: "Tomorrow 6PM EST", type: "🎨 Art" },
            { title: "Virtual Racing Tournament", time: "Friday 7PM EST", type: "🏎️ Gaming" },
            { title: "Metaverse Meetup", time: "Saturday 5PM EST", type: "🤝 Social" }
          ].map((event, i) => (
            <div key={i} style={{
              background: 'rgba(255,255,255,0.1)',
              backdropFilter: 'blur(10px)',
              borderRadius: '15px',
              padding: '1.5rem',
              border: '1px solid rgba(255,255,255,0.2)'
            }}>
              <h3 style={{ fontSize: '1.3rem', marginBottom: '0.5rem', fontWeight: 'bold' }}>
                {event.title}
              </h3>
              <p style={{ opacity: 0.8, marginBottom: '0.5rem' }}>{event.time}</p>
              <div style={{ 
                padding: '0.5rem 1rem',
                background: 'rgba(255,255,255,0.2)',
                borderRadius: '25px',
                display: 'inline-block',
                fontSize: '0.9rem'
              }}>
                {event.type}
              </div>
            </div>
          ))}
        </div>

        <div style={{ textAlign: 'center', marginTop: '3rem' }}>
          <div style={{
            padding: '1rem 2rem',
            background: 'rgba(255,255,255,0.2)',
            borderRadius: '30px',
            display: 'inline-block',
            fontSize: '1.1rem',
            fontWeight: 'bold'
          }}>
            ✅ Events System Active
          </div>
        </div>
      </div>
    </div>
  )
}