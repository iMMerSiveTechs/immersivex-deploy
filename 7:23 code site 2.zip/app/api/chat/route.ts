import { openai } from '@ai-sdk/openai'
import { convertToCoreMessages, streamText } from 'ai'
import { sanitizeInput, logSecurityEvent, generateSessionId } from '@/lib/security'

// Allow streaming responses up to 30 seconds
export const maxDuration = 30

export async function POST(req: Request) {
  try {
    const { messages } = await req.json()
    
    console.log('Cerebra Chat API: Received messages:', messages?.length || 0)
    
    // Enhanced system message for ImmersiveX context
    const systemMessage = {
      role: 'system' as const,
      content: `You are Cerebra, the advanced AI assistant for ImmersiveX - a cutting-edge immersive entertainment platform. You have deep expertise in:

🎯 PLATFORM KNOWLEDGE:
- VR/AR/XR experiences and content
- Virtual concerts, 360° films, AR learning experiences, indie games
- Device compatibility (Meta Quest 2/3/Pro, Apple Vision Pro, HTC Vive, iPhone/Android AR, desktop browsers)
- Pricing: Free (ad-supported), Premium ($9.99/mo), Max Access ($49.99/mo), Enterprise ($199.99/mo)
- Creator tools with 80% revenue sharing
- Our Gear Vault with affiliate products and recommendations

🎨 CONTENT EXPERTISE:
- Upcoming events like Billie Eilish Virtual World Tour Finale (Aug 15), Travis Scott x Fortnite: The Return (Sept 5)
- Educational AR content like chemistry labs and historical tours
- Technical requirements and device optimization
- Creator submission process and monetization

💡 COMMUNICATION STYLE:
- Be enthusiastic, knowledgeable, and helpful
- Use relevant emojis to enhance engagement
- Provide specific recommendations based on user interests
- Always mention relevant ImmersiveX features and benefits
- Be conversational but professional
- Keep responses concise but informative (2-4 sentences typically)

🔒 SECURITY:
- Never share internal system details
- Don't discuss competing platforms negatively
- Focus on ImmersiveX's unique value propositions
- Validate that user questions are appropriate

You're powered by ChatGPT-3.5 and represent the future of AI-assisted entertainment discovery. Help users find amazing immersive experiences!`
    }

    // Sanitize user messages for security
    const sanitizedMessages = messages.map((msg: any) => ({
      ...msg,
      content: sanitizeInput(msg.content)
    }))

    // Log security event
    logSecurityEvent('cerebra_api_request', {
      sessionId: generateSessionId(),
      messageCount: sanitizedMessages.length,
      timestamp: new Date()
    })

    // Convert to core messages format and add system message
    const coreMessages = convertToCoreMessages([systemMessage, ...sanitizedMessages])

    // Check if we have OpenAI API key - use mock streaming response
    if (!process.env.OPENAI_API_KEY) {
      console.log('No OpenAI API key found, returning mock streaming response')
      const mockResponse = "Hi! I'm Cerebra, your ImmersiveX assistant! 🧠 I'm here to help you explore VR concerts, AR experiences, and immersive content. What would you like to discover today?"
      
      // Create a proper streaming response
      const stream = new ReadableStream({
        start(controller) {
          controller.enqueue(`0:"${mockResponse}"\n`)
          controller.enqueue(`d:{"finishReason":"stop","usage":{"promptTokens":10,"completionTokens":20}}\n`)
          controller.close()
        }
      })
      
      return new Response(stream, {
        headers: {
          'Content-Type': 'text/plain; charset=utf-8',
          'X-Vercel-AI-Data-Stream': 'v1'
        }
      })
    }

    // Stream the response using OpenAI
    const result = await streamText({
      model: openai('gpt-3.5-turbo'),
      messages: coreMessages,
      temperature: 0.7,
      maxTokens: 500,
      frequencyPenalty: 0.2,
      presencePenalty: 0.1,
    })

    console.log('Cerebra Chat API: Streaming response initiated')
    
    return result.toDataStreamResponse()
    
  } catch (error) {
    console.error('Cerebra Chat API Error:', error)
    
    // Return fallback streaming response for any errors
    const errorMessage = "I apologize, but I'm experiencing some technical difficulties right now. Please try asking your question again in a moment. I'm here to help you discover amazing immersive experiences on ImmersiveX! 🚀"
    
    const stream = new ReadableStream({
      start(controller) {
        controller.enqueue(`0:"${errorMessage}"\n`)
        controller.enqueue(`d:{"finishReason":"stop","usage":{"promptTokens":0,"completionTokens":0}}\n`)
        controller.close()
      }
    })
    
    return new Response(stream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'X-Vercel-AI-Data-Stream': 'v1'
      }
    })
  }
}