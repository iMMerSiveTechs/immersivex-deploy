import { NextRequest, NextResponse } from 'next/server'

// Mock Airtable credentials - replace with real ones when ready
const AIRTABLE_API_KEY = process.env.AIRTABLE_API_KEY || 'mock_key'
const AIRTABLE_BASE_ID = process.env.AIRTABLE_BASE_ID || 'mock_base'
const AIRTABLE_TABLE_NAME = process.env.AIRTABLE_TABLE_NAME || 'AffiliateLinks'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    console.log('Affiliate submission received:', body)

    // Validate required fields
    if (!body.name || !body.url || !body.category) {
      return NextResponse.json(
        { success: false, message: 'Missing required fields' },
        { status: 400 }
      )
    }

    // If we have real Airtable credentials, submit to Airtable
    if (AIRTABLE_API_KEY !== 'mock_key' && AIRTABLE_BASE_ID !== 'mock_base') {
      console.log('Submitting to Airtable...')
      
      const airtableRes = await fetch(`https://api.airtable.com/v0/${AIRTABLE_BASE_ID}/${AIRTABLE_TABLE_NAME}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${AIRTABLE_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          fields: {
            Name: body.name,
            LINK: body.url,
            CATAGORY: body.category,
            IMAGE: body.image ? [{ url: body.image }] : []
          }
        })
      })

      if (!airtableRes.ok) {
        const error = await airtableRes.text()
        console.error('Airtable error:', error)
        return NextResponse.json(
          { success: false, message: 'Failed to submit to Airtable: ' + error },
          { status: 500 }
        )
      }

      const airtableData = await airtableRes.json()
      console.log('Airtable response:', airtableData)

      return NextResponse.json({
        success: true,
        message: 'Product submitted successfully to Airtable!',
        data: airtableData
      })
    } else {
      // Mock response for development
      console.log('Using mock response (no Airtable credentials)')
      
      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      return NextResponse.json({
        success: true,
        message: 'Product submitted successfully! (Mock response - configure Airtable credentials for real submission)',
        data: {
          id: 'mock_' + Date.now(),
          fields: body
        }
      })
    }
  } catch (error) {
    console.error('Affiliate submission error:', error)
    return NextResponse.json(
      { success: false, message: 'Internal server error: ' + (error as Error).message },
      { status: 500 }
    )
  }
}