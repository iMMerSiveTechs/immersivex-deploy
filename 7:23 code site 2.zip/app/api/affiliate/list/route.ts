import { NextResponse } from 'next/server'

const AIRTABLE_API_KEY = process.env.AIRTABLE_API_KEY || 'mock_key'
const AIRTABLE_BASE_ID = process.env.AIRTABLE_BASE_ID || 'mock_base'
const AIRTABLE_TABLE_NAME = process.env.AIRTABLE_TABLE_NAME || 'AffiliateLinks'

export async function GET() {
  try {
    console.log('Fetching affiliate products...')

    // If we have real Airtable credentials, fetch from Airtable
    if (AIRTABLE_API_KEY !== 'mock_key' && AIRTABLE_BASE_ID !== 'mock_base') {
      console.log('Fetching from Airtable...')
      
      const airtableRes = await fetch(
        `https://api.airtable.com/v0/${AIRTABLE_BASE_ID}/${AIRTABLE_TABLE_NAME}?sort%5B0%5D%5Bfield%5D=Name&sort%5B0%5D%5Bdirection%5D=asc`,
        {
          headers: {
            'Authorization': `Bearer ${AIRTABLE_API_KEY}`
          }
        }
      )

      if (!airtableRes.ok) {
        const error = await airtableRes.text()
        console.error('Airtable fetch error:', error)
        return NextResponse.json(
          { success: false, message: 'Failed to fetch from Airtable: ' + error },
          { status: 500 }
        )
      }

      const data = await airtableRes.json()
      console.log('Airtable data fetched:', data.records?.length || 0, 'records')
      
      return NextResponse.json({
        success: true,
        records: data.records || [],
        count: data.records?.length || 0
      })
    } else {
      // Return mock data for development
      console.log('Using mock data (no Airtable credentials)')
      
      const mockData = {
        success: true,
        records: [
          {
            id: 'mock_1',
            fields: {
              Name: 'Meta Quest 3 Elite Strap',
              LINK: 'https://example.com/meta-quest-3-elite-strap',
              CATAGORY: 'VR Accessories',
              IMAGE: [{ url: 'https://images.pexels.com/photos/7241304/pexels-photo-7241304.jpeg?auto=compress&cs=tinysrgb&w=400' }]
            }
          },
          {
            id: 'mock_2',
            fields: {
              Name: 'Haptic Feedback Gloves',
              LINK: 'https://example.com/haptic-gloves',
              CATAGORY: 'Haptics',
              IMAGE: [{ url: 'https://images.pexels.com/photos/7886853/pexels-photo-7886853.jpeg?auto=compress&cs=tinysrgb&w=400' }]
            }
          },
          {
            id: 'mock_3',
            fields: {
              Name: 'AR Smart Glasses',
              LINK: 'https://example.com/ar-glasses',
              CATAGORY: 'AR Glasses',
              IMAGE: [{ url: 'https://images.pexels.com/photos/7199194/pexels-photo-7199194.jpeg?auto=compress&cs=tinysrgb&w=400' }]
            }
          }
        ],
        count: 3
      }
      
      return NextResponse.json(mockData)
    }
  } catch (error) {
    console.error('Affiliate list error:', error)
    return NextResponse.json(
      { success: false, message: 'Internal server error: ' + (error as Error).message },
      { status: 500 }
    )
  }
}