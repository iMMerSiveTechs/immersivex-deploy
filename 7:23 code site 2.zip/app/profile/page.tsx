export default function ProfilePage() {
  return (
    <div style={{ 
      fontFamily: 'system-ui, -apple-system, sans-serif',
      background: 'linear-gradient(135deg, #764ba2 0%, #667eea 100%)',
      minHeight: '100vh',
      color: 'white',
      padding: '2rem'
    }}>
      <div style={{ maxWidth: '800px', margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <div style={{ 
            width: '120px', 
            height: '120px', 
            background: 'rgba(255,255,255,0.2)',
            borderRadius: '50%',
            margin: '0 auto 1rem auto',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '3rem'
          }}>
            👤
          </div>
          <h1 style={{ fontSize: '2.5rem', fontWeight: 'bold', marginBottom: '0.5rem' }}>
            Your Profile
          </h1>
          <p style={{ fontSize: '1.1rem', opacity: 0.9 }}>
            Manage your immersive identity
          </p>
        </div>

        <div style={{ 
          background: 'rgba(255,255,255,0.1)',
          backdropFilter: 'blur(10px)',
          borderRadius: '20px',
          padding: '2rem',
          border: '1px solid rgba(255,255,255,0.2)'
        }}>
          <div style={{ marginBottom: '2rem' }}>
            <h3 style={{ fontSize: '1.3rem', marginBottom: '1rem', fontWeight: 'bold' }}>
              Profile Stats
            </h3>
            <div style={{ 
              display: 'grid', 
              gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', 
              gap: '1rem' 
            }}>
              {[
                { label: "VR Hours", value: "127" },
                { label: "Events Joined", value: "23" },
                { label: "Friends", value: "45" },
                { label: "XP Level", value: "12" }
              ].map((stat, i) => (
                <div key={i} style={{
                  textAlign: 'center',
                  padding: '1rem',
                  background: 'rgba(255,255,255,0.1)',
                  borderRadius: '10px'
                }}>
                  <div style={{ fontSize: '2rem', fontWeight: 'bold' }}>{stat.value}</div>
                  <div style={{ fontSize: '0.9rem', opacity: 0.8 }}>{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 style={{ fontSize: '1.3rem', marginBottom: '1rem', fontWeight: 'bold' }}>
              Recent Activity
            </h3>
            {[
              "Joined VR Concert Experience",
              "Completed AI Art Gallery tour", 
              "Won Virtual Racing match",
              "Connected with 3 new friends"
            ].map((activity, i) => (
              <div key={i} style={{
                padding: '0.8rem',
                background: 'rgba(255,255,255,0.05)',
                borderRadius: '8px',
                marginBottom: '0.5rem',
                fontSize: '0.95rem'
              }}>
                • {activity}
              </div>
            ))}
          </div>
        </div>

        <div style={{ textAlign: 'center', marginTop: '2rem' }}>
          <div style={{
            padding: '1rem 2rem',
            background: 'rgba(255,255,255,0.2)',
            borderRadius: '30px',
            display: 'inline-block',
            fontSize: '1.1rem',
            fontWeight: 'bold'
          }}>
            ✅ Profile System Active
          </div>
        </div>
      </div>
    </div>
  )
}