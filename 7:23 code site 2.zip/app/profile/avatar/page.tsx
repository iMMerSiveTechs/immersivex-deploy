'use client'

import { useState } from 'react'
import Link from 'next/link'

export default function AvatarPage() {
  const [avatarFile, setAvatarFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string>('')
  const [minted, setMinted] = useState(false)
  const [uploading, setUploading] = useState(false)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setAvatarFile(file)
      const reader = new FileReader()
      reader.onload = (e) => {
        setPreviewUrl(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const mintNFT = async () => {
    if (!avatarFile) return
    
    setUploading(true)
    // Simulate NFT minting process
    setTimeout(() => {
      setMinted(true)
      setUploading(false)
    }, 3000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-purple-900 to-blue-900 pt-20">
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-all">
            ← Back to Home
          </Link>
        </div>

        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-pink-500 to-cyan-500 bg-clip-text text-transparent">
            Create Your Persona NFT
          </h1>
          <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Mint your unique digital identity for the immersive web and metaverse experiences
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-purple-500/30">
            <div className="text-center space-y-6">
              {!previewUrl ? (
                <div className="border-2 border-dashed border-purple-500/50 rounded-xl p-12">
                  <div className="text-6xl mb-4">🎭</div>
                  <h3 className="text-xl font-semibold text-white mb-2">Upload Your Avatar</h3>
                  <p className="text-gray-400 mb-4">Choose an image to create your persona NFT</p>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                    id="avatar-upload"
                  />
                  <label
                    htmlFor="avatar-upload"
                    className="inline-block bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 text-white font-semibold py-3 px-6 rounded-lg cursor-pointer transition-all duration-300"
                  >
                    Choose File
                  </label>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="relative">
                    <img
                      src={previewUrl}
                      alt="Avatar Preview"
                      className="w-64 h-64 object-cover rounded-xl mx-auto border-4 border-purple-500/50"
                    />
                    <div className="absolute -top-2 -right-2 bg-gradient-to-r from-purple-600 to-cyan-600 text-white text-xs px-2 py-1 rounded-full">
                      NFT Ready
                    </div>
                  </div>

                  {!minted ? (
                    <button
                      onClick={mintNFT}
                      disabled={uploading}
                      className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 text-white font-semibold py-3 px-8 rounded-lg transition-all duration-300 disabled:opacity-50"
                    >
                      {uploading ? '🔄 Minting NFT...' : '🚀 Mint as NFT'}
                    </button>
                  ) : (
                    <div className="space-y-4">
                      <div className="text-green-400 font-semibold text-lg">
                        ✅ NFT Successfully Minted!
                      </div>
                      <div className="bg-green-500/20 border border-green-500/50 rounded-lg p-4">
                        <p className="text-green-300 text-sm">
                          Your persona NFT has been created and stored on IPFS. 
                          This digital identity can now be used across the immersive web!
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          setPreviewUrl('')
                          setAvatarFile(null)
                          setMinted(false)
                        }}
                        className="border border-purple-500/50 text-purple-400 hover:bg-purple-500/10 font-semibold py-2 px-6 rounded-lg transition-all"
                      >
                        Create Another
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}