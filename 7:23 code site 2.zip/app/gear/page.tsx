'use client'

import { useState } from 'react'

export default function GearPage() {
  const [gear, setGear] = useState([
    { id: 1, name: 'Meta Quest 3', price: '$499', category: 'VR Headset', rating: '4.8/5' },
    { id: 2, name: 'HTC Vive Pro 2', price: '$799', category: 'VR Headset', rating: '4.6/5' },
    { id: 3, name: 'Magic Leap 2', price: '$3299', category: 'AR Glasses', rating: '4.4/5' },
    { id: 4, name: 'Haptic Gloves', price: '$199', category: 'Accessories', rating: '4.2/5' }
  ])

  return (
    <div style={{ 
      padding: '2rem', 
      fontFamily: 'system-ui',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      minHeight: '100vh',
      color: 'white'
    }}>
      <h1 style={{ fontSize: '3rem', textAlign: 'center', marginBottom: '2rem' }}>
        🧰 Gear Vault
      </h1>
      
      <div style={{ 
        maxWidth: '1000px', 
        margin: '0 auto',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: '1.5rem'
      }}>
        {gear.map(item => (
          <div key={item.id} style={{
            background: 'rgba(255,255,255,0.15)',
            borderRadius: '15px',
            padding: '1.5rem',
            backdropFilter: 'blur(10px)',
            transition: 'transform 0.3s ease'
          }}>
            <div style={{
              width: '100%',
              height: '200px',
              background: 'rgba(255,255,255,0.1)',
              borderRadius: '10px',
              marginBottom: '1rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '3rem'
            }}>
              🥽
            </div>
            
            <h3 style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>{item.name}</h3>
            <p style={{ opacity: 0.8, marginBottom: '0.5rem' }}>📦 {item.category}</p>
            <p style={{ opacity: 0.8, marginBottom: '0.5rem' }}>⭐ {item.rating}</p>
            <p style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#10b981', marginBottom: '1rem' }}>
              {item.price}
            </p>
            
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <button style={{
                flex: 1,
                padding: '0.75rem',
                background: '#8b5cf6',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer'
              }}>
                View Details
              </button>
              <button style={{
                flex: 1,
                padding: '0.75rem',
                background: '#f59e0b',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer'
              }}>
                Buy Now
              </button>
            </div>
          </div>
        ))}
      </div>
      
      <div style={{ textAlign: 'center', marginTop: '2rem' }}>
        <a href="/" style={{ color: 'white', textDecoration: 'underline' }}>← Back to Home</a>
      </div>
    </div>
  )
}