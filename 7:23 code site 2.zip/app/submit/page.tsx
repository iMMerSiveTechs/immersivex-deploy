"use client"

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Upload, Send, Sparkles, DollarSign, Users, CheckCircle, Shield, AlertTriangle } from 'lucide-react'
import GlassBackButton from '@/components/glass-back-button'
import { 
  sanitizeInput, 
  validateEmail, 
  validateURL, 
  validateFormData, 
  generateSessionId, 
  logSecurityEvent,
  filterContent
} from '@/lib/security'

const SubmitPage = () => {
  const [formData, setFormData] = useState({
    projectTitle: '',
    projectType: '',
    description: '',
    contactEmail: '',
    discordHandle: '',
    experienceLink: '',
    monetize: false,
    file: null as File | null
  })

  const [sessionId] = useState(() => generateSessionId())
  const [formErrors, setFormErrors] = useState<string[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [securityStatus, setSecurityStatus] = useState<'secure' | 'warning' | 'error'>('secure')

  console.log("SubmitPage rendered, formData:", formData)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    console.log(`Form field ${name} changed to:`, value?.substring(0, 50) + "...")
    
    // Security: Sanitize input in real-time
    const sanitizedValue = sanitizeInput(value)
    
    // Content filtering for description field
    if (name === 'description') {
      const { filtered, flagged } = filterContent(sanitizedValue)
      if (flagged) {
        setSecurityStatus('warning')
        console.log("Content flagged during input")
      } else {
        setSecurityStatus('secure')
      }
      
      setFormData(prev => ({
        ...prev,
        [name]: filtered
      }))
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: sanitizedValue
      }))
    }
    
    // Clear previous errors when user starts typing
    setFormErrors([])
  }

  const handleSelectChange = (value: string) => {
    console.log("Project type changed to:", value)
    setFormData(prev => ({
      ...prev,
      projectType: value
    }))
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null
    console.log("File selected:", file?.name)
    setFormData(prev => ({
      ...prev,
      file
    }))
  }

  const handleMonetizeChange = (checked: boolean) => {
    console.log("Monetize changed to:", checked)
    setFormData(prev => ({
      ...prev,
      monetize: checked
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setFormErrors([])
    
    console.log("Creator submission form submitted - validating...")
    
    // Security: Comprehensive form validation
    const validation = validateFormData(formData)
    
    if (!validation.isValid) {
      setFormErrors(validation.errors)
      setSecurityStatus('error')
      setIsSubmitting(false)
      logSecurityEvent('form_validation_failed', {
        sessionId,
        errors: validation.errors,
        formData: {
          projectTitle: formData.projectTitle?.substring(0, 50),
          projectType: formData.projectType,
          descriptionLength: formData.description?.length || 0
        }
      })
      return
    }
    
    // Additional security checks
    if (formData.experienceLink && !validateURL(formData.experienceLink)) {
      setFormErrors(['Invalid experience link URL'])
      setSecurityStatus('error')
      setIsSubmitting(false)
      return
    }
    
    if (!validateEmail(formData.contactEmail)) {
      setFormErrors(['Invalid email address'])
      setSecurityStatus('error')
      setIsSubmitting(false)
      return
    }
    
    // Content filtering
    const { filtered: filteredDescription, flagged } = filterContent(formData.description)
    
    if (flagged) {
      setFormErrors(['Content contains restricted terms. Please review your submission.'])
      setSecurityStatus('warning')
      setIsSubmitting(false)
      logSecurityEvent('content_flagged', {
        sessionId,
        projectTitle: formData.projectTitle?.substring(0, 50)
      })
      return
    }
    
    // Log successful submission
    logSecurityEvent('form_submitted_successfully', {
      sessionId,
      projectType: formData.projectType,
      descriptionLength: filteredDescription.length,
      hasFile: !!formData.file,
      monetize: formData.monetize
    })
    
    console.log("Security validation passed - processing submission")
    
    // Simulate processing delay
    setTimeout(() => {
      setIsSubmitting(false)
      setSecurityStatus('secure')
      alert('🚀 Thank you for your submission! Our security team will review your experience and get back to you within 48 hours. You\'ll receive a confirmation email shortly.')
    }, 2000)
  }

  const projectTypes = [
    { value: 'concert', label: 'Virtual Concert' },
    { value: 'film', label: 'VR Film/Documentary' },
    { value: 'vr-world', label: 'VR World/Environment' },
    { value: 'education', label: 'Educational Experience' },
    { value: 'game', label: 'Indie Game' },
    { value: 'art', label: 'Interactive Art Installation' },
    { value: 'other', label: 'Other' }
  ]

  const benefits = [
    {
      icon: DollarSign,
      title: "Revenue Sharing",
      description: "Keep 80% of your earnings with transparent monthly payouts"
    },
    {
      icon: Users,
      title: "Global Audience",
      description: "Reach millions of users across all XR/AR/VR platforms"
    },
    {
      icon: Sparkles,
      title: "Creative Freedom",
      description: "Full control over your content with minimal restrictions"
    }
  ]

  return (
    <div className="spatial-container min-h-screen bg-gradient-to-br from-deep-black via-space-blue to-electric-purple/20 pt-20 xr-enhanced">
      {/* Enhanced 3D Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiM2MzY2ZjEiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')] animate-float-3d" />
        
        {/* Quantum Grid */}
        <div 
          className="absolute inset-0 opacity-10 animate-neural-network"
          style={{
            backgroundImage: `
              linear-gradient(rgba(16, 255, 240, 0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(99, 102, 241, 0.3) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px'
          }}
        />
        
        {/* 3D Floating Orbs */}
        <div className="absolute top-1/4 left-1/6 w-12 h-12 rounded-full bg-gradient-radial from-cyber-mint/20 to-transparent animate-float-3d" style={{ animationDelay: '0s' }} />
        <div className="absolute top-3/4 right-1/4 w-8 h-8 rounded-full bg-gradient-radial from-electric-purple/25 to-transparent animate-float-3d" style={{ animationDelay: '2s' }} />
        <div className="absolute top-1/2 right-1/6 w-6 h-6 rounded-full bg-gradient-radial from-neon-pink/30 to-transparent animate-float-3d" style={{ animationDelay: '4s' }} />
      </div>

      <div className="relative z-10 container mx-auto px-4 lg:px-8 py-12">
        {/* Glass Back Button with 3D Effect */}
        <div className="mb-8 animate-fade-in-up">
          <GlassBackButton variant="default" label="Back to Home" href="/" />
        </div>

        {/* Enhanced Security Status Bar */}
        <div className="mb-6 animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
          <div className={`glass-3d-enhanced spatial-card p-4 rounded-xl border-2 transition-all duration-300 ${
            securityStatus === 'secure' ? 'border-green-400/30 bg-green-400/5' :
            securityStatus === 'warning' ? 'border-yellow-400/30 bg-yellow-400/5' :
            'border-red-400/30 bg-red-400/5'
          }`}>
            <div className="flex items-center gap-3">
              {securityStatus === 'secure' && <Shield className="w-5 h-5 text-green-400 animate-pulse-spatial" />}
              {securityStatus === 'warning' && <AlertTriangle className="w-5 h-5 text-yellow-400 animate-pulse-spatial" />}
              {securityStatus === 'error' && <AlertTriangle className="w-5 h-5 text-red-400 animate-pulse-spatial" />}
              
              <div>
                <p className={`font-medium ${
                  securityStatus === 'secure' ? 'text-green-400' :
                  securityStatus === 'warning' ? 'text-yellow-400' :
                  'text-red-400'
                }`}>
                  {securityStatus === 'secure' && 'Secure Connection'}
                  {securityStatus === 'warning' && 'Content Review Required'}
                  {securityStatus === 'error' && 'Validation Error'}
                </p>
                <p className="text-sm text-glass-white/60">
                  {securityStatus === 'secure' && 'Your submission is protected with enterprise-grade security'}
                  {securityStatus === 'warning' && 'Please review your content for restricted terms'}
                  {securityStatus === 'error' && 'Please correct the errors below'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Error Display */}
        {formErrors.length > 0 && (
          <div className="mb-6 animate-fade-in-up">
            <div className="glass-3d-enhanced p-4 rounded-xl border-2 border-red-400/30 bg-red-400/5">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-red-400 font-medium mb-2">Please fix the following errors:</h4>
                  <ul className="text-sm text-glass-white/80 space-y-1">
                    {formErrors.map((error, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-red-400 rounded-full" />
                        {error}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Enhanced Header */}
        <div className="text-center mb-16 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
          <h1 
            className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 hologram-text animate-float-3d"
            data-macaly="submit-title"
          >
            Submit Your{' '}
            <span className="hologram-text animate-hologram-glow">
              Experience
            </span>
          </h1>
          <p 
            className="text-lg md:text-xl text-glass-white/70 max-w-4xl mx-auto leading-relaxed"
            data-macaly="submit-subtitle"
          >
            Join the XR revolution! Share your immersive creations with a global audience and become part of the future of entertainment.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-12 max-w-7xl mx-auto">
          {/* Benefits Section */}
          <div className="space-y-8">
            <h2 
              className="text-2xl font-bold text-white mb-6"
              data-macaly="submit-benefits-title"
            >
              Why Submit to ImmersiveX?
            </h2>
            
            {benefits.map((benefit, index) => (
              <Card key={index} className="glass-3d-enhanced spatial-card border-electric-purple/20 hover:border-electric-purple/40 transition-all duration-300 animate-fade-in-up quantum-border" style={{ animationDelay: `${0.3 + index * 0.1}s` }}>
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-electric-purple to-cyber-mint flex items-center justify-center animate-neural-network">
                      <benefit.icon className="w-6 h-6 text-white animate-pulse-spatial" />
                    </div>
                    <div>
                      <h3 
                        className="text-lg font-semibold text-white mb-2 hologram-text"
                        data-macaly={`benefit-${index}-title`}
                      >
                        {benefit.title}
                      </h3>
                      <p 
                        className="text-glass-white/80 text-sm leading-relaxed"
                        data-macaly={`benefit-${index}-description`}
                      >
                        {benefit.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Stats */}
            <Card className="glass-dark border-electric-purple/30">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-white mb-4 text-center">Our Creator Community</h3>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-cyber-mint">150+</div>
                    <div className="text-xs text-glass-white/60">Active Creators</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-electric-purple">$2.3M</div>
                    <div className="text-xs text-glass-white/60">Paid Out</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-neon-pink">10M+</div>
                    <div className="text-xs text-glass-white/60">Views</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-cyber-mint">4.9★</div>
                    <div className="text-xs text-glass-white/60">Avg Rating</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Submission Form */}
          <div className="lg:col-span-2">
            <Card className="glass-dark border-electric-purple/30 hover:border-electric-purple/50 transition-all duration-500">
              <CardHeader>
                <CardTitle className="flex items-center text-white text-2xl">
                  <Sparkles className="w-6 h-6 mr-3 text-cyber-mint" />
                  Project Submission Form
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Project Title */}
                  <div className="space-y-2">
                    <Label htmlFor="projectTitle" className="text-white font-medium">
                      Project Title *
                    </Label>
                    <Input
                      id="projectTitle"
                      name="projectTitle"
                      placeholder="Enter your project title"
                      value={formData.projectTitle}
                      onChange={handleInputChange}
                      className="secure-input glass-3d-enhanced border-electric-purple/30 text-white placeholder:text-glass-white/60 focus:border-electric-purple transition-all duration-300"
                      data-macaly="submit-project-title-input"
                      required
                    />
                  </div>

                  {/* Project Type */}
                  <div className="space-y-2">
                    <Label className="text-white font-medium">
                      Project Type *
                    </Label>
                    <Select onValueChange={handleSelectChange} required>
                      <SelectTrigger 
                        className="bg-glass-100 border-electric-purple/30 text-white focus:border-electric-purple"
                        data-macaly="submit-project-type-select"
                      >
                        <SelectValue placeholder="Select project type" />
                      </SelectTrigger>
                      <SelectContent className="bg-space-blue border-electric-purple/30">
                        {projectTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value} className="text-white hover:bg-electric-purple/20">
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Description */}
                  <div className="space-y-2">
                    <Label htmlFor="description" className="text-white font-medium">
                      Description *
                    </Label>
                    <Textarea
                      id="description"
                      name="description"
                      placeholder="Describe your immersive experience, target audience, and unique features..."
                      value={formData.description}
                      onChange={handleInputChange}
                      rows={4}
                      className="bg-glass-100 border-electric-purple/30 text-white placeholder:text-glass-white/60 focus:border-electric-purple resize-none"
                      data-macaly="submit-description-input"
                      required
                    />
                  </div>

                  {/* File Upload */}
                  <div className="space-y-2">
                    <Label className="text-white font-medium">
                      Demo Video/Images
                    </Label>
                    <div className="border-2 border-dashed border-electric-purple/30 rounded-lg p-8 text-center hover:border-electric-purple/50 transition-colors duration-300">
                      <Upload className="w-12 h-12 mx-auto mb-4 text-glass-white/60" />
                      <p className="text-glass-white/80 mb-2">
                        Drop your files here or click to browse
                      </p>
                      <p className="text-glass-white/60 text-sm mb-4">
                        Support: MP4, MOV, JPG, PNG (Max 100MB)
                      </p>
                      <Input
                        type="file"
                        accept="video/*,image/*"
                        onChange={handleFileChange}
                        className="hidden"
                        id="file-upload"
                        data-macaly="submit-file-input"
                      />
                      <Button 
                        type="button"
                        variant="outline"
                        onClick={() => document.getElementById('file-upload')?.click()}
                        className="border-electric-purple/50 text-electric-purple hover:bg-electric-purple/10 hover:border-electric-purple"
                      >
                        Choose Files
                      </Button>
                      {formData.file && (
                        <p className="text-cyber-mint text-sm mt-2">
                          Selected: {formData.file.name}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Experience Link */}
                  <div className="space-y-2">
                    <Label htmlFor="experienceLink" className="text-white font-medium">
                      Link to Playable Experience
                    </Label>
                    <Input
                      id="experienceLink"
                      name="experienceLink"
                      type="url"
                      placeholder="https://your-experience-link.com"
                      value={formData.experienceLink}
                      onChange={handleInputChange}
                      className="bg-glass-100 border-electric-purple/30 text-white placeholder:text-glass-white/60 focus:border-electric-purple"
                      data-macaly="submit-experience-link-input"
                    />
                  </div>

                  {/* Contact Information */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="contactEmail" className="text-white font-medium">
                        Contact Email *
                      </Label>
                      <Input
                        id="contactEmail"
                        name="contactEmail"
                        type="email"
                        placeholder="your@email.com"
                        value={formData.contactEmail}
                        onChange={handleInputChange}
                        className="bg-glass-100 border-electric-purple/30 text-white placeholder:text-glass-white/60 focus:border-electric-purple"
                        data-macaly="submit-contact-email-input"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="discordHandle" className="text-white font-medium">
                        Discord Handle
                      </Label>
                      <Input
                        id="discordHandle"
                        name="discordHandle"
                        placeholder="username#1234"
                        value={formData.discordHandle}
                        onChange={handleInputChange}
                        className="bg-glass-100 border-electric-purple/30 text-white placeholder:text-glass-white/60 focus:border-electric-purple"
                        data-macaly="submit-discord-input"
                      />
                    </div>
                  </div>

                  {/* Monetization Option */}
                  <div className="flex items-center space-x-3">
                    <Checkbox
                      id="monetize"
                      checked={formData.monetize}
                      onCheckedChange={handleMonetizeChange}
                      className="border-electric-purple/50 data-[state=checked]:bg-electric-purple data-[state=checked]:border-electric-purple"
                      data-macaly="submit-monetize-checkbox"
                    />
                    <Label htmlFor="monetize" className="text-white font-medium">
                      I want this experience to be monetized (80% revenue share)
                    </Label>
                  </div>

                  {/* Submit Button */}
                  <Button 
                    type="submit"
                    size="lg"
                    disabled={isSubmitting}
                    className="w-full btn-3d-enhanced bg-gradient-to-r from-electric-purple to-cyber-mint hover:from-electric-purple/80 hover:to-cyber-mint/80 text-white font-semibold py-4 text-lg rounded-lg transition-all duration-300 shadow-neon quantum-border disabled:opacity-50 disabled:cursor-not-allowed"
                    data-macaly="submit-experience-btn"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="w-5 h-5 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent" />
                        Processing Securely...
                      </>
                    ) : (
                      <>
                        <Send className="w-5 h-5 mr-2 animate-pulse-spatial" />
                        Submit Experience
                      </>
                    )}
                  </Button>
                </form>

                {/* Additional Info */}
                <div className="mt-8 p-6 glass-dark rounded-lg border border-electric-purple/20">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-5 h-5 text-cyber-mint mt-0.5" />
                    <div>
                      <h4 className="text-white font-semibold mb-2">What happens next?</h4>
                      <ul className="text-glass-white/80 text-sm space-y-1">
                        <li>• Our team reviews your submission within 48 hours</li>
                        <li>• You'll receive feedback and next steps via email</li>
                        <li>• Approved experiences go live within 7 days</li>
                        <li>• Start earning immediately once published</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SubmitPage