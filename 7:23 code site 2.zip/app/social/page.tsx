export default function SocialPage() {
  return (
    <div style={{ 
      fontFamily: 'system-ui, -apple-system, sans-serif',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      minHeight: '100vh',
      color: 'white',
      padding: '2rem'
    }}>
      <div style={{ maxWidth: '1000px', margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <h1 style={{ fontSize: '3rem', fontWeight: 'bold', marginBottom: '1rem' }}>
            🌐 Social Hub
          </h1>
          <p style={{ fontSize: '1.2rem', opacity: 0.9 }}>
            Connect with the immersive community
          </p>
        </div>

        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: '1fr 1fr',
          gap: '2rem',
          '@media (max-width: 768px)': { gridTemplateColumns: '1fr' }
        }}>
          <div style={{
            background: 'rgba(255,255,255,0.1)',
            backdropFilter: 'blur(10px)',
            borderRadius: '15px',
            padding: '1.5rem',
            border: '1px solid rgba(255,255,255,0.2)'
          }}>
            <h3 style={{ fontSize: '1.3rem', marginBottom: '1rem', fontWeight: 'bold' }}>
              🏆 Community Feed
            </h3>
            {[
              { user: "Alex_VR", action: "completed Epic Quest", time: "2m ago" },
              { user: "Sarah_AR", action: "shared amazing screenshot", time: "5m ago" },
              { user: "Mike_XR", action: "reached Level 15", time: "12m ago" },
              { user: "Luna_AI", action: "created new experience", time: "1h ago" }
            ].map((post, i) => (
              <div key={i} style={{
                padding: '1rem',
                background: 'rgba(255,255,255,0.05)',
                borderRadius: '10px',
                marginBottom: '0.8rem'
              }}>
                <div style={{ fontWeight: 'bold', marginBottom: '0.3rem' }}>
                  {post.user} {post.action}
                </div>
                <div style={{ fontSize: '0.8rem', opacity: 0.7 }}>
                  {post.time}
                </div>
              </div>
            ))}
          </div>

          <div style={{
            background: 'rgba(255,255,255,0.1)',
            backdropFilter: 'blur(10px)',
            borderRadius: '15px',
            padding: '1.5rem',
            border: '1px solid rgba(255,255,255,0.2)'
          }}>
            <h3 style={{ fontSize: '1.3rem', marginBottom: '1rem', fontWeight: 'bold' }}>
              👥 Online Friends
            </h3>
            {[
              { name: "Alex_VR", status: "In VR Concert", online: true },
              { name: "Sarah_AR", status: "Exploring Gallery", online: true },
              { name: "Mike_XR", status: "Racing Tournament", online: true },
              { name: "Luna_AI", status: "Creating", online: false }
            ].map((friend, i) => (
              <div key={i} style={{
                display: 'flex',
                alignItems: 'center',
                padding: '0.8rem',
                background: 'rgba(255,255,255,0.05)',
                borderRadius: '10px',
                marginBottom: '0.5rem'
              }}>
                <div style={{
                  width: '12px',
                  height: '12px',
                  borderRadius: '50%',
                  backgroundColor: friend.online ? '#4ade80' : '#6b7280',
                  marginRight: '0.8rem'
                }}></div>
                <div>
                  <div style={{ fontWeight: 'bold' }}>{friend.name}</div>
                  <div style={{ fontSize: '0.8rem', opacity: 0.7 }}>
                    {friend.status}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ textAlign: 'center', marginTop: '3rem' }}>
          <div style={{
            padding: '1rem 2rem',
            background: 'rgba(255,255,255,0.2)',
            borderRadius: '30px',
            display: 'inline-block',
            fontSize: '1.1rem',
            fontWeight: 'bold'
          }}>
            ✅ Social Network Active
          </div>
        </div>
      </div>
    </div>
  )
}