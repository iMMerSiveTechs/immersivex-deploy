"use client"

import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Calendar, Clock, User, Mail, TrendingUp, Play, Eye } from 'lucide-react'
import GlassBackButton from '@/components/glass-back-button'

const UpdatesPage = () => {
  console.log("UpdatesPage component rendered")

  const posts = [
    {
      id: 1,
      title: "Meta Quest 3S Officially Announced: Everything You Need to Know",
      excerpt: "Meta unveils their most affordable mixed reality headset yet, targeting mainstream adoption with breakthrough price point.",
      content: "Full article content would go here...",
      featuredImage: "https://via.placeholder.com/800x400/6366F1/FFFFFF?text=Meta+Quest+3S",
      author: "Sarah Chen",
      date: "2025-07-22",
      readTime: "5 min read",
      tags: ["Product Drops", "VR", "Meta"],
      views: 15420,
      isFeatured: true
    },
    {
      id: 2,
      title: "Exclusive: Travis Scott's Next Virtual Concert Coming to ImmersiveX",
      excerpt: "The superstar announces his most ambitious virtual performance yet, featuring custom worlds and interactive elements.",
      content: "Full article content would go here...",
      featuredImage: "https://via.placeholder.com/800x400/10FFF0/000000?text=Travis+Scott+VR",
      author: "Alex Rodriguez",
      date: "2025-07-21",
      readTime: "3 min read",
      tags: ["Concerts", "Creator Spotlight", "Music"],
      views: 23851,
      isFeatured: false
    },
    {
      id: 3,
      title: "Apple Vision Pro Gets Major Update: New Hand Tracking Features",
      excerpt: "iOS 18.2 brings enhanced gesture recognition and improved spatial computing capabilities to Vision Pro users.",
      content: "Full article content would go here...",
      featuredImage: "https://via.placeholder.com/800x400/FF0080/FFFFFF?text=Vision+Pro+Update",
      author: "David Kim",
      date: "2025-07-20",
      readTime: "4 min read",
      tags: ["News", "Apple", "AR"],
      views: 18293,
      isFeatured: false
    },
    {
      id: 4,
      title: "How Indie Developers Are Revolutionizing VR Storytelling",
      excerpt: "From emotional narratives to interactive documentaries, indie creators are pushing the boundaries of immersive storytelling.",
      content: "Full article content would go here...",
      featuredImage: "https://via.placeholder.com/800x400/6366F1/FFFFFF?text=VR+Storytelling",
      author: "Maya Patel",
      date: "2025-07-19",
      readTime: "7 min read",
      tags: ["Creator Spotlight", "VR Films", "Indie"],
      views: 12067,
      isFeatured: false
    },
    {
      id: 5,
      title: "The Future of AR Learning: Stanford's Breakthrough Study",
      excerpt: "New research shows 340% improvement in retention rates when using AR for complex subjects like molecular biology.",
      content: "Full article content would go here...",
      featuredImage: "https://via.placeholder.com/800x400/10FFF0/000000?text=AR+Learning",
      author: "Dr. Emily Johnson",
      date: "2025-07-18",
      readTime: "6 min read",
      tags: ["Education", "AR", "Research"],
      views: 9834,
      isFeatured: false
    },
    {
      id: 6,
      title: "Weekly XR Market Roundup: $2.3B in New Funding",
      excerpt: "Venture capital continues pouring into XR startups, with spatial computing leading investment categories this quarter.",
      content: "Full article content would go here...",
      featuredImage: "https://via.placeholder.com/800x400/FF0080/FFFFFF?text=XR+Funding",
      author: "Marcus Thompson",
      date: "2025-07-17",
      readTime: "8 min read",
      tags: ["News", "Business", "Investment"],
      views: 14521,
      isFeatured: false
    }
  ]

  const topArticles = posts.slice(0, 3).map(post => ({
    title: post.title,
    views: post.views
  }))

  const allTags = ["All", "Concerts", "Product Drops", "Creator Spotlight", "News", "VR Films", "Education", "Business"]

  return (
    <div className="min-h-screen bg-space-blue pt-20">
      <div className="container mx-auto px-4 lg:px-8 py-12">
        {/* Glass Back Button */}
        <div className="mb-8">
          <GlassBackButton variant="default" label="Back to Home" href="/" />
        </div>
        {/* Newsletter Subscription Bar */}
        <Card className="glass-dark border-electric-purple/30 mb-12">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="text-center md:text-left">
                <h3 className="text-lg font-semibold text-white mb-1">📬 Weekly Immersive Updates</h3>
                <p className="text-glass-white/70 text-sm">Get the latest XR news, creator spotlights, and exclusive content delivered to your inbox</p>
              </div>
              <div className="flex gap-3 w-full md:w-auto">
                <Input
                  placeholder="Enter your email"
                  className="bg-glass-100 border-electric-purple/30 text-white placeholder:text-glass-white/60 focus:border-electric-purple min-w-[250px]"
                  data-macaly="newsletter-email-input"
                />
                <Button 
                  className="bg-gradient-to-r from-electric-purple to-cyber-mint hover:from-electric-purple/80 hover:to-cyber-mint/80 text-white font-semibold px-6 transition-all duration-300 shadow-neon whitespace-nowrap"
                  data-macaly="newsletter-subscribe-btn"
                >
                  <Mail className="w-4 h-4 mr-2" />
                  Subscribe
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Header */}
            <div className="mb-12">
              <h1 
                className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6"
                data-macaly="updates-title"
              >
                Weekly{' '}
                <span className="bg-gradient-to-r from-electric-purple to-cyber-mint bg-clip-text text-transparent">
                  Immersive Updates
                </span>
              </h1>
              <p 
                className="text-lg md:text-xl text-glass-white/70 leading-relaxed"
                data-macaly="updates-subtitle"
              >
                Stay ahead of the curve with the latest XR news, creator spotlights, and immersive content drops
              </p>
            </div>

            {/* Tag Filters */}
            <div className="flex flex-wrap gap-3 mb-8">
              {allTags.map((tag) => (
                <Button
                  key={tag}
                  variant="outline"
                  size="sm"
                  className="border-electric-purple/50 text-electric-purple hover:bg-electric-purple/10 hover:border-electric-purple transition-all duration-300"
                  data-macaly={`tag-filter-${tag.toLowerCase()}`}
                >
                  {tag}
                </Button>
              ))}
            </div>

            {/* Featured Post */}
            {posts.find(post => post.isFeatured) && (
              <Card className="glass-dark border-electric-purple/30 hover:border-electric-purple/50 transition-all duration-500 mb-12">
                <div className="relative overflow-hidden">
                  <img 
                    src={posts[0].featuredImage} 
                    alt={posts[0].title}
                    className="w-full h-64 md:h-80 object-cover"
                    data-macaly="featured-post-image"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-deep-black/80 via-transparent to-transparent" />
                  <Badge className="absolute top-4 left-4 bg-gradient-to-r from-neon-pink to-electric-purple text-white border-0">
                    Featured
                  </Badge>
                  <div className="absolute bottom-6 left-6 right-6">
                    <div className="flex flex-wrap gap-2 mb-3">
                      {posts[0].tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="border-cyber-mint/50 text-cyber-mint text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <h2 
                      className="text-2xl md:text-3xl font-bold text-white mb-2 leading-tight"
                      data-macaly="featured-post-title"
                    >
                      {posts[0].title}
                    </h2>
                    <p 
                      className="text-glass-white/80 mb-4"
                      data-macaly="featured-post-excerpt"
                    >
                      {posts[0].excerpt}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 text-sm text-glass-white/60">
                        <div className="flex items-center">
                          <User className="w-4 h-4 mr-1" />
                          {posts[0].author}
                        </div>
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {new Date(posts[0].date).toLocaleDateString()}
                        </div>
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          {posts[0].readTime}
                        </div>
                      </div>
                      <Button 
                        className="bg-glass-dark text-white hover:bg-electric-purple/20 border border-electric-purple/30 hover:border-electric-purple/50"
                        size="sm"
                        data-macaly="featured-post-read-btn"
                      >
                        <Play className="w-4 h-4 mr-2" />
                        Read More
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            )}

            {/* Regular Posts Grid */}
            <div className="space-y-8">
              {posts.slice(1).map((post) => (
                <Card key={post.id} className="glass-dark border-electric-purple/20 hover:border-electric-purple/40 transition-all duration-500 group">
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="relative overflow-hidden rounded-lg">
                      <img 
                        src={post.featuredImage} 
                        alt={post.title}
                        className="w-full h-48 md:h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        data-macaly={`post-${post.id}-image`}
                      />
                    </div>
                    
                    <div className="md:col-span-2 p-6">
                      <div className="flex flex-wrap gap-2 mb-3">
                        {post.tags.map((tag) => (
                          <Badge key={tag} variant="outline" className="border-electric-purple/50 text-electric-purple text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      
                      <h3 
                        className="text-xl md:text-2xl font-bold text-white mb-3 group-hover:text-cyber-mint transition-colors duration-300"
                        data-macaly={`post-${post.id}-title`}
                      >
                        {post.title}
                      </h3>
                      
                      <p 
                        className="text-glass-white/80 mb-4 leading-relaxed"
                        data-macaly={`post-${post.id}-excerpt`}
                      >
                        {post.excerpt}
                      </p>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 text-sm text-glass-white/60">
                          <div className="flex items-center">
                            <User className="w-4 h-4 mr-1" />
                            {post.author}
                          </div>
                          <div className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            {new Date(post.date).toLocaleDateString()}
                          </div>
                          <div className="flex items-center">
                            <Eye className="w-4 h-4 mr-1" />
                            {post.views.toLocaleString()}
                          </div>
                        </div>
                        
                        <Button 
                          variant="outline"
                          size="sm"
                          className="border-electric-purple/50 text-electric-purple hover:bg-electric-purple/10 hover:border-electric-purple"
                          data-macaly={`post-${post.id}-read-btn`}
                        >
                          Read More
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Top Articles */}
            <Card className="glass-dark border-electric-purple/30">
              <CardHeader>
                <h3 className="text-lg font-semibold text-white flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2 text-cyber-mint" />
                  Trending This Week
                </h3>
              </CardHeader>
              <CardContent className="space-y-4">
                {topArticles.map((article, index) => (
                  <div key={index} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-glass-100 transition-colors duration-300 cursor-pointer">
                    <div className="w-6 h-6 rounded-full bg-gradient-to-r from-electric-purple to-cyber-mint flex items-center justify-center text-white text-sm font-bold">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <h4 className="text-white text-sm font-medium leading-tight mb-1">{article.title}</h4>
                      <p className="text-xs text-glass-white/60 flex items-center">
                        <Eye className="w-3 h-3 mr-1" />
                        {article.views.toLocaleString()} views
                      </p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Newsletter CTA */}
            <Card className="glass-dark border-electric-purple/30">
              <CardContent className="p-6 text-center">
                <Mail className="w-12 h-12 mx-auto mb-4 text-cyber-mint" />
                <h3 className="text-lg font-semibold text-white mb-2">Stay Connected</h3>
                <p className="text-glass-white/70 text-sm mb-4">
                  Join 50,000+ immersive enthusiasts getting weekly updates
                </p>
                <Button 
                  size="sm"
                  className="w-full bg-gradient-to-r from-electric-purple to-cyber-mint hover:from-electric-purple/80 hover:to-cyber-mint/80 text-white font-semibold transition-all duration-300"
                  data-macaly="sidebar-newsletter-btn"
                >
                  Subscribe Now
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Bottom Newsletter CTA */}
        <Card className="glass-dark border-electric-purple/30 mt-16">
          <CardContent className="p-8 text-center">
            <h3 
              className="text-2xl font-bold text-white mb-4"
              data-macaly="bottom-newsletter-title"
            >
              Never Miss an Update
            </h3>
            <p 
              className="text-glass-white/70 mb-6 max-w-2xl mx-auto"
              data-macaly="bottom-newsletter-description"
            >
              Get exclusive insights, early access to content, and behind-the-scenes stories from the immersive entertainment world.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
              <Input
                placeholder="Your email address"
                className="bg-glass-100 border-electric-purple/30 text-white placeholder:text-glass-white/60 focus:border-electric-purple"
                data-macaly="bottom-newsletter-email-input"
              />
              <Button 
                className="bg-gradient-to-r from-electric-purple to-cyber-mint hover:from-electric-purple/80 hover:to-cyber-mint/80 text-white font-semibold px-8 transition-all duration-300 shadow-neon whitespace-nowrap"
                data-macaly="bottom-newsletter-subscribe-btn"
              >
                Subscribe
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default UpdatesPage